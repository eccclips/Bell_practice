import React, { useMemo } from 'react';

import { Typography } from '@mui/material';

import { getFixedNumber, getFormattedDateWithTime, typedMemo } from 'root-front/utils';

import { TableColumn, TableData } from '../../types';
import { BooleanContent, ChipContent, IconButtonsContent, LinkContent } from './content';
import { MenuContent } from './content/menu';

import styles from './TableCell.module.scss';

type TableCellProps<Data = any> = {
    row: TableData<Data>;
    column: TableColumn<TableData<Data>>;
    rowIndex: number;
    colIndex: number;
    paddingLeft?: number;
};

const TableCell = <Data,>(props: TableCellProps<Data>) => {
    const { row, column, rowIndex, colIndex, paddingLeft } = props;

    const renderContent = () => {
        const value = column.valueGetter
            ? column.valueGetter(row, { rowIndex, colIndex })
            : row[column.key];
        const defaultValue = typeof column.emptyValue === 'string' ? column.emptyValue : '';

        switch (column.type) {
            case 'menu':
                return (
                    <MenuContent
                        actions={column.actions}
                        row={row}
                        rowIndex={rowIndex}
                        colIndex={colIndex}
                    />
                );
            case 'icon-buttons':
                return (
                    <IconButtonsContent
                        actions={column.actions}
                        row={row}
                        rowIndex={rowIndex}
                        colIndex={colIndex}
                    />
                );
            case 'chip': {
                const color = column.chipColorGetter(row);

                return <ChipContent value={value} color={color} />;
            }
            case 'boolean':
                return <BooleanContent value={value} />;
            case 'date':
                return value
                    ? getFormattedDateWithTime(value, {
                          ignoreTimezone:
                              typeof column.ignoreTimezone === 'boolean'
                                  ? column.ignoreTimezone
                                  : true,
                      })
                    : defaultValue;
            case 'link': {
                const link = column.linkGetter(row);

                return value ? <LinkContent value={value} link={link} /> : defaultValue;
            }
            case 'amount': {
                return getFixedNumber(value) || defaultValue;
            }
            default:
                if (column.noWrap) {
                    return (
                        <Typography variant="inherit" noWrap>
                            {value || defaultValue}
                        </Typography>
                    );
                }
                return value || defaultValue;
        }
    };

    const textAlign = useMemo(() => {
        if (column.children?.length) {
            return 'center';
        }

        if (column.type === 'amount') {
            return 'right';
        }

        return column.align || 'left';
    }, [column]);

    return (
        <td
            style={{
                paddingLeft: paddingLeft ? `${paddingLeft}px` : undefined,
                width: column.noWrap ? '50px' : undefined,
                maxWidth: column.noWrap ? '50px' : undefined,
                textAlign,
            }}
        >
            <div className={styles.cell}>{renderContent()}</div>
        </td>
    );
};

export default typedMemo(TableCell);
