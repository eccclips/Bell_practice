import React from 'react';

import { Control, useWatch } from 'react-hook-form';

import { FormulaViewer } from '../../formula-viewer';
import { Formula } from '../../types';

type FormulaPreviewProps = {
    control: Control<{ formula: Formula }>;
    prefixName: string;
    hoveredOperand?: string;
    onHover?: (uid: string) => void;
    size?: 'small' | 'medium' | 'large';
};

const FormulaPreview = (props: FormulaPreviewProps) => {
    const { control, prefixName, hoveredOperand, onHover, size = 'small' } = props;
    const value = useWatch({ control, name: (prefixName as any) || undefined });

    return (
        <FormulaViewer
            formula={value}
            hoveredOperand={hoveredOperand}
            onHover={onHover}
            size={size}
        />
    );
};

export default React.memo(FormulaPreview);
