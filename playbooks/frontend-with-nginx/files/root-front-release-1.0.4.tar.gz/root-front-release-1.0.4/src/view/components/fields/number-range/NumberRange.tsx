import React, { useEffect, useMemo } from 'react';

import { TextFieldProps as TextFieldCoreProps } from '@mui/material/TextField/TextField';
import { UseControllerProps, UseFormTrigger, useWatch } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

import { TextField } from '../text-field';

import styles from './NumberRange.module.scss';

export type NumberRangeProps<T> = UseControllerProps<T> &
    TextFieldCoreProps & {
        debounced?: boolean;
        withStaticHelperText?: boolean;
        readOnly?: boolean;
        trigger?: UseFormTrigger<any>;
    };

const NumberRange = <T,>(props: NumberRangeProps<T>) => {
    const { control, name, placeholder, inputMode = 'decimal', trigger, ...textFieldProps } = props;

    const nameFrom = `${name}.from`;
    const nameTo = `${name}.to`;

    const valueFrom = useWatch({ control, name: nameFrom as any }) as number;
    const valueTo = useWatch({ control, name: nameTo as any }) as number;

    const { placeholderFrom, placeholderTo } = useMemo(
        () => ({
            placeholderFrom: placeholder ? `${placeholder} от` : 'От',
            placeholderTo: placeholder ? `${placeholder} до` : 'До',
        }),
        [placeholder]
    );

    useEffect(() => {
        trigger?.([nameFrom, nameTo]);
    }, [valueFrom, valueTo]);

    return (
        <div className={styles.container}>
            <TextField
                control={control}
                rules={{
                    max: { value: valueTo, message: 'Значение «От» превышает «До»' },
                }}
                name={nameFrom as any}
                id={nameFrom}
                type="number"
                placeholder={placeholderFrom}
                inputMode={inputMode}
                {...textFieldProps}
            />
            <span className={styles.splitter}>—</span>
            <TextField
                control={control}
                rules={{
                    min: { value: valueFrom, message: 'Значение «От» превышает «До»' },
                }}
                name={nameTo as any}
                id={nameTo}
                type="number"
                placeholder={placeholderTo}
                inputMode={inputMode}
                {...textFieldProps}
            />
        </div>
    );
};

export default typedMemo(NumberRange);
