export const REST_ROWS_SYMBOL = Symbol('REST_ROWS');
export const GROUP_ROW_DATA_SYMBOL = Symbol('GROUP_ROW_DATA');
