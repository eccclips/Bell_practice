import React from 'react';

import { IconButton, SvgIcon } from '@mui/material';
import { useWatch } from 'react-hook-form';

import { Icons } from 'root-front/icons';

import { Fields } from '../../../../fields';
import {
    ELEMENT_TYPE,
    ELEMENT_TYPE_OPTIONS,
    OPERANDS_LENGTH_FROM_OPERATOR_MAP,
    OPERATOR_OPTIONS,
} from '../../../constants';
import { FormulaConstructorOperandProps } from '../../../types';
import { FormulaPreview } from '../../formula-preview';

import styles from '../../FormulaConstructor.module.scss';

type Props = Pick<
    FormulaConstructorOperandProps,
    | 'control'
    | 'prefixName'
    | 'handleChangeElementType'
    | 'handleChangeOperatorType'
    | 'handleRemoveOperand'
    | 'handleAppendOperand'
    | 'deletable'
    | 'children'
>;

const Operator = (props: Props) => {
    const {
        control,
        prefixName,
        handleChangeElementType,
        handleChangeOperatorType,
        handleRemoveOperand,
        handleAppendOperand,
        deletable,
        children,
    } = props;

    const operandType = useWatch({
        control,
        name: `${prefixName}type` as 'formula.type',
        exact: true,
    });
    const operandOperator = useWatch({
        control,
        name: `${prefixName}operator` as 'formula.operator',
        exact: true,
    });
    const operandOperands = useWatch({
        control,
        name: `${prefixName}operands` as 'formula.operands',
        exact: true,
    });

    if (operandType !== ELEMENT_TYPE.OPERATOR) {
        return null;
    }

    const appendable =
        operandOperator &&
        operandOperands?.length < OPERANDS_LENGTH_FROM_OPERATOR_MAP[operandOperator].max;

    return (
        <div className={styles.row}>
            <div className={styles.row__start}>
                <Fields.Select
                    control={control}
                    name={`${prefixName}type` as any}
                    options={ELEMENT_TYPE_OPTIONS}
                    onChange={handleChangeElementType(prefixName)}
                    rules={{ required: 'Обязательно' }}
                    className={styles.row__field}
                />
                <Fields.Select
                    control={control}
                    name={`${prefixName}operator` as any}
                    options={OPERATOR_OPTIONS}
                    onChange={handleChangeOperatorType(prefixName, operandOperands)}
                    placeholder="Вид оператора"
                    rules={{ required: 'Обязательно' }}
                    className={styles.row__field}
                />
                {(deletable || appendable) && (
                    <div className={styles.row__actions}>
                        {deletable && (
                            <IconButton onClick={handleRemoveOperand(prefixName)}>
                                <SvgIcon>
                                    <Icons.Trash />
                                </SvgIcon>
                            </IconButton>
                        )}
                        {appendable && (
                            <IconButton onClick={handleAppendOperand(prefixName, operandOperands)}>
                                <SvgIcon>
                                    <Icons.Plus />
                                </SvgIcon>
                            </IconButton>
                        )}
                    </div>
                )}
            </div>
            <div className={styles.row__end}>
                {children || <FormulaPreview control={control} prefixName={prefixName} />}
            </div>
        </div>
    );
};

export default React.memo(Operator);
