export { default as TableSettings } from './TableSettings';
