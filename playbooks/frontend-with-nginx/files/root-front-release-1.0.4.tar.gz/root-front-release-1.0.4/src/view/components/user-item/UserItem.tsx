import React, { memo } from 'react';

import { Avatar } from '@mui/material';

import styles from './UserItem.module.scss';

enum SIZE {
    SMALL = 'SMALL',
    MIDDLE = 'MIDDLE',
    LARGE = 'LARGE',
}

const SIZES_MAP = {
    [SIZE.SMALL]: 32,
    [SIZE.MIDDLE]: 36,
    [SIZE.LARGE]: 40,
};

type UserItemProps = {
    fullName: string;
    source?: string;
    size?: SIZE;
};

const UserItem = (props: UserItemProps) => {
    const { fullName, source = '', size = SIZE.SMALL } = props;

    const sizeValue = SIZES_MAP[size];

    return (
        <div className={styles.container}>
            <Avatar alt={fullName} src={source} sx={{ width: sizeValue, height: sizeValue }} />
            <p>{fullName}</p>
        </div>
    );
};

export default memo(UserItem);
