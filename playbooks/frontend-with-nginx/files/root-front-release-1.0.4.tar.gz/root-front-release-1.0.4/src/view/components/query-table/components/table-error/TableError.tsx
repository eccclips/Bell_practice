import React, { PropsWithChildren, useMemo } from 'react';

import { Button } from '@mui/material';
import { flushSync } from 'react-dom';

import { ErrorBoundary } from '../../../error-boundary';

const ERROR_TEXT =
    'О нет! Что-то пошло не так.\nПопробуйте сбросить настройки таблицы или вернуться позднее';

type TableErrorProps = {
    onResetAll: () => void;
};

const TableError = (props: PropsWithChildren<TableErrorProps>) => {
    const { children, onResetAll } = props;

    const errorPageContent = useMemo(() => {
        return (
            <Button
                variant="contained"
                onClick={() => {
                    flushSync(onResetAll);

                    window.location.reload();
                }}
            >
                Сбросить
            </Button>
        );
    }, []);

    return (
        <ErrorBoundary errorPageText={ERROR_TEXT} errorPageContent={errorPageContent}>
            {children}
        </ErrorBoundary>
    );
};

export default React.memo(TableError);
