import React from 'react';

import { IconButton, IconButtonProps } from '@mui/material';
import { NavLink } from 'react-router-dom';

const LinkIconButton = (props: IconButtonProps<React.ElementType, { to?: string }>) => {
    return <IconButton {...props} LinkComponent={NavLink} />;
};

export default React.memo(LinkIconButton);
