import { BaseAuditedDTO } from 'root-front/interfaces';

import { NOTIFICATION_MESSAGE_CHANNEL, NOTIFICATION_TEMPLATE_STATUS } from '../constants';

export interface NotificationDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    userId: number;
    isRead: boolean;
    messageDate: string;
    messageTopic: string;
    messageBody: string;
    status: string;
}

export interface NotificationTemplateDTO extends BaseAuditedDTO {
    code: string;
    name: string;
    status: NOTIFICATION_TEMPLATE_STATUS;
    isRichText: boolean;
    messageTopic: string;
    messageBody: string;
    actorMessageChannels: NOTIFICATION_MESSAGE_CHANNEL[];
    receivers: string[];
}

export interface NotificationReceiverDTO extends BaseAuditedDTO {
    notificationTemplateId: number;
    receiver: string;
    deliveryChannel: NOTIFICATION_MESSAGE_CHANNEL;
}
