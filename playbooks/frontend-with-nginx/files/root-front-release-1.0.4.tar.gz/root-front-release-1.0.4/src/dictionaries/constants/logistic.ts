import { CHIP_COLORS } from 'root-front/components';

export enum TIMETABLE_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export enum ROUTE_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export enum WAREHOUSE_ROUTE_TIME_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export enum COUNTERPARTY_ROUTE_TIME_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export enum ROUTE_TYPE {
    BASIC = 'BASIC',
    B2B = 'B2B',
}

export enum ROUTE_RECEIVER_TYPE {
    COUNTERPARTY = 'COUNTERPARTY',
    WAREHOUSE = 'WAREHOUSE',
}

export const ROUTE_STATUS_MAP = {
    [ROUTE_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [ROUTE_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};

export const ROUTE_TYPE_MAP = {
    [ROUTE_TYPE.B2B]: { text: 'B2B' },
    [ROUTE_TYPE.BASIC]: { text: 'Основной' },
};

export const TIMETABLE_STATUS_MAP = {
    [TIMETABLE_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [TIMETABLE_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};

export const WAREHOUSE_ROUTE_TIME_STATUS_MAP = {
    [WAREHOUSE_ROUTE_TIME_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [WAREHOUSE_ROUTE_TIME_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};

export const COUNTERPARTY_ROUTE_TIME_STATUS_MAP = {
    [COUNTERPARTY_ROUTE_TIME_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [COUNTERPARTY_ROUTE_TIME_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};
