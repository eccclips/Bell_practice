import React from 'react';

import { typedMemo } from 'root-front/utils';

import SelectMultiple from './SelectMultiple';
import SelectSingle from './SelectSingle';
import { SelectMultipleProps, SelectProps, SelectSingleProps } from './types';

const Select = <T, Value, Multiple = false>(props: SelectProps<T, Value, Multiple>) => {
    const { multiple, ...rest } = props;
    return multiple ? (
        <SelectMultiple
            {...rest}
            onChange={rest.onChange as SelectMultipleProps<T, Value>['onChange']}
            multiple={true}
        />
    ) : (
        <SelectSingle
            {...rest}
            onChange={rest.onChange as SelectSingleProps<T, Value>['onChange']}
            multiple={false}
        />
    );
};

export default typedMemo(Select);
