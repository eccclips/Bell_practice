import { useInfiniteQuery, UseInfiniteQueryResult } from '@tanstack/react-query';
import { AxiosResponse } from 'axios';

import { api } from '../api/api';
import { SORT_DIRECTION } from '../constants/list';
import { ListRequestDTO, ResponseDTO, SortInstructionDTO } from '../interfaces';
import { QuerySelectFetchParams } from '../view/components/query-select/types';

const STALE_TIME = 3 * 60 * 1000;

type GetDictionaryQueryConfig<Params = Record<string, any>> = {
    /** URL для запроса */
    url: string;
    /** Массив ключей `queryKey` без `search` или функция-геттер этого массива на основе `params` */
    queryKey: any[] | ((params: QuerySelectFetchParams<Params>) => any[]);
    /**
     *  Ключ поля для поиска через search
     * @default 'search'
     */
    searchKey?: string;
    /**
     * Дополнительные параметры для запроса, которые передаются в тело запроса или функция-геттер этих параметров на основе `params`
     * @default {}
     */
    additionalParams?:
        | Record<string, any>
        | ((params: QuerySelectFetchParams<Params>) => Record<string, any>);
    /**
     * Сортировка
     * @default { field: 'id', direction: SORT_DIRECTION.ASC }
     */
    sort?: SortInstructionDTO;
};

/** Утилита для создания `useInfiniteQuery` хуков для QuerySelect */
export const getDictionaryQuery = <Result, Params = Record<string, any>>(
    config: GetDictionaryQueryConfig<Params>
): ((params: QuerySelectFetchParams<Params>) => UseInfiniteQueryResult<ResponseDTO<Result[]>>) => {
    return (params: QuerySelectFetchParams<Params>) => {
        const { url, queryKey, additionalParams = {}, searchKey = 'search', sort } = config;

        return useInfiniteQuery({
            queryKey: [
                ...(typeof queryKey === 'function' ? queryKey(params) : queryKey),
                params.search,
            ],
            queryFn: async ({ pageParam }) => {
                const result = await api.post<
                    ResponseDTO<Result[]>,
                    AxiosResponse<ResponseDTO<Result[]>>,
                    ListRequestDTO
                >(url, {
                    pageInfo: {
                        page: pageParam || 0,
                        size: 10,
                        sort: [
                            sort || {
                                field: 'id',
                                direction: SORT_DIRECTION.ASC,
                            },
                        ],
                    },
                    [searchKey]: params.search,
                    ...(typeof additionalParams === 'function'
                        ? additionalParams(params)
                        : additionalParams),
                });

                return result.data;
            },
            enabled: params.enabled,
            getNextPageParam: (lastPage) =>
                lastPage.page + 1 < lastPage.totalPages ? lastPage.page + 1 : undefined,
            staleTime: STALE_TIME,
        });
    };
};
