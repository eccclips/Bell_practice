import { SortInstructionDTO } from 'root-front/interfaces';

export type ListRequestParams<Filters = any, Params = any> = {
    page: number;
    size: number;
    sort: SortInstructionDTO;
    filters?: Filters;
    params?: Params;
    /** Необходим для принудительного обновления реестра, даже если фильтры или параметры не поменялись */
    timestamp?: number;
};
