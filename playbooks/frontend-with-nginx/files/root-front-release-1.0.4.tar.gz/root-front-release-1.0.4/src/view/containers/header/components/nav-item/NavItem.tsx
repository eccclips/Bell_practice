import React from 'react';

import { ButtonBase, SvgIcon } from '@mui/material';
import cn from 'classnames';

import { LinkButtonBase } from 'root-front/components';
import { Icons } from 'root-front/icons';

import styles from './NavItem.module.scss';

interface Props {
    text: string;
    to?: string;
    inner?: boolean;
    opened?: boolean;
    isActive?: boolean;
    isMobile?: boolean;
    hideRightIcon?: boolean;
    type: 'link' | 'button';
    Icon: React.FC<{ [key: string]: any }>;
    children?: React.ReactNode;
    className?: string;
    onClick?: React.MouseEventHandler<HTMLButtonElement>;
}

export const NavItem = React.memo((props: Props) => {
    const {
        text,
        to,
        inner,
        opened,
        isActive,
        isMobile,
        hideRightIcon = false,
        type,
        Icon,
        children,
        className,
        onClick,
    } = props;

    return type === 'link' ? (
        <LinkButtonBase
            to={to}
            variant="contained"
            className={cn(
                styles.button,
                {
                    [styles.button_inner]: inner,
                    [styles.button_mobile]: isMobile,
                },
                className
            )}
            focusRipple
        >
            <SvgIcon className={styles.button__leftIcon}>
                <Icon className={styles.button__svg} />
            </SvgIcon>
            <div className={styles.button__text}>{text}</div>
            {children}
        </LinkButtonBase>
    ) : (
        <ButtonBase
            className={cn(
                styles.button,
                {
                    [styles.button_withRightIcon]: !hideRightIcon,
                    [styles.button_active]: isActive,
                    [styles.button_mobile]: isMobile,
                },
                className
            )}
            onClick={onClick}
            focusRipple
        >
            <SvgIcon className={styles.button__leftIcon}>
                <Icon className={styles.button__svg} />
            </SvgIcon>
            <div className={styles.button__text}>{text}</div>
            {!hideRightIcon && (
                <SvgIcon
                    className={cn(styles.button__rightIcon, {
                        [styles.button__rightIcon_opened]: opened,
                    })}
                >
                    <Icons.ArrowRight className={styles.button__svg} />
                </SvgIcon>
            )}
            {children}
        </ButtonBase>
    );
});
