import React, { useMemo } from 'react';

import { SvgIcon } from '@mui/material';
import {
    DatePicker as DatePickerCore,
    DateValidationError,
    DateView,
    PickerChangeHandlerContext,
} from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { useController } from 'react-hook-form';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import { DateRangeProps } from './types';
import { getStringValueFrom, getStringValueTo } from './utils';

import commonStyles from '../Fields.module.scss';
import styles from './DateRange.module.scss';

const DEFAULT_VIEWS: DateView[] = ['year', 'month', 'day'];

const DateRange = <T,>(props: DateRangeProps<T>) => {
    const { views = DEFAULT_VIEWS, withStaticHelperText } = props;

    const { field: fieldFrom, fieldState: fieldFromState } = useController({
        ...props,
        name: `${props.name}.from` as any,
    });
    const { field: fieldTo, fieldState: fieldToState } = useController({
        ...props,
        name: `${props.name}.to` as any,
    });

    const fieldFromValue = fieldFrom.value as string;
    const fieldToValue = fieldTo.value as string;

    const handleChangeFrom = (
        value: dayjs.Dayjs,
        ctx: PickerChangeHandlerContext<DateValidationError>
    ) => {
        if (!value || !value.isValid()) {
            fieldFrom.onChange(null);
            return;
        }
        const stringValue = getStringValueFrom(value, views);

        const nextValue = { from: stringValue, to: fieldToValue || null };

        fieldFrom.onChange(nextValue.from);

        if (fieldToValue && dayjs(fieldToValue).isBefore(stringValue)) {
            fieldTo.onChange(getStringValueTo(value, views));
        } else {
            fieldTo.onChange(fieldToValue);
        }

        props.onChange?.(nextValue, ctx);
    };

    const handleChangeTo = (
        value: dayjs.Dayjs,
        ctx: PickerChangeHandlerContext<DateValidationError>
    ) => {
        if (!value || !value.isValid()) {
            fieldTo.onChange(null);
            return;
        }
        const stringValue = getStringValueTo(value, views);

        const nextValue = { from: fieldFromValue || null, to: stringValue };

        fieldTo.onChange(nextValue.to);

        if (fieldFromValue && dayjs(fieldFromValue).isAfter(stringValue)) {
            fieldFrom.onChange(getStringValueFrom(value, views));
        } else {
            fieldFrom.onChange(fieldFromValue);
        }

        props.onChange?.(nextValue, ctx);
    };

    const handleBlurFrom = () => {
        fieldFrom.onBlur();
    };

    const handleBlurTo = () => {
        fieldTo.onBlur();
    };

    const [valueFrom, valueTo] = useMemo(
        () => [
            fieldFromValue ? dayjs(fieldFromValue.slice(0, 10)) : '',
            fieldToValue ? dayjs(fieldToValue.slice(0, 10)) : '',
        ],
        [fieldFromValue, fieldToValue]
    );

    return (
        <div className={styles.container}>
            <DatePickerCore
                {...props}
                slotProps={{
                    calendarHeader: { className: styles.datepicker__header },
                    textField: {
                        helperText: fieldFromState.error ? (
                            <FormErrorHelper message={fieldFromState.error.message} />
                        ) : null,
                        FormHelperTextProps: {
                            className: withStaticHelperText && commonStyles.helperText_static,
                        },
                        onBlur: handleBlurFrom,
                        error: !!fieldFromState.error,
                        id: props.idFrom,
                        size: 'small',
                    },
                    actionBar: {
                        actions: ['clear'],
                    },
                }}
                slots={{
                    openPickerIcon: () => (
                        <SvgIcon>
                            <Icons.CalendarThin />
                        </SvgIcon>
                    ),
                    rightArrowIcon: () => (
                        <SvgIcon>
                            <Icons.ArrowRight />
                        </SvgIcon>
                    ),
                    leftArrowIcon: () => (
                        <SvgIcon>
                            <Icons.ArrowLeft />
                        </SvgIcon>
                    ),
                    switchViewIcon: (props) => (
                        <SvgIcon
                            {...props}
                            style={{
                                transition: 'transform 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
                            }}
                        >
                            <Icons.ArrowDown />
                        </SvgIcon>
                    ),
                }}
                onChange={handleChangeFrom}
                value={valueFrom}
                views={views}
                inputRef={fieldFrom.ref}
            />
            <span className={styles.splitter}>—</span>
            <DatePickerCore
                {...props}
                slotProps={{
                    calendarHeader: { className: styles.datepicker__header },
                    textField: {
                        helperText: fieldToState.error ? (
                            <FormErrorHelper message={fieldToState.error.message} />
                        ) : null,
                        FormHelperTextProps: {
                            className: withStaticHelperText && commonStyles.helperText_static,
                        },
                        onBlur: handleBlurTo,
                        error: !!fieldToState.error,
                        id: props.idTo,
                        size: 'small',
                    },
                    actionBar: {
                        actions: ['clear'],
                    },
                }}
                slots={{
                    openPickerIcon: () => (
                        <SvgIcon>
                            <Icons.CalendarThin />
                        </SvgIcon>
                    ),
                    rightArrowIcon: () => (
                        <SvgIcon>
                            <Icons.ArrowRight />
                        </SvgIcon>
                    ),
                    leftArrowIcon: () => (
                        <SvgIcon>
                            <Icons.ArrowLeft />
                        </SvgIcon>
                    ),
                    switchViewIcon: (props) => (
                        <SvgIcon
                            {...props}
                            style={{
                                transition: 'transform 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
                            }}
                        >
                            <Icons.ArrowDown />
                        </SvgIcon>
                    ),
                }}
                onChange={handleChangeTo}
                value={valueTo}
                views={views}
                inputRef={fieldTo.ref}
            />
        </div>
    );
};

export default typedMemo(DateRange);
