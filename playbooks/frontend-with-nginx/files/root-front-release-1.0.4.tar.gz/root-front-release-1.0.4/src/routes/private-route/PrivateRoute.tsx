import React from 'react';

import { Navigate, Outlet } from 'react-router-dom';

import {
    useAccessTokenState,
    useTokenPayloadState,
    useUserPermissionsState,
} from 'root-front/store';

export const PrivateRoute = () => {
    const token = useAccessTokenState();
    const permissions = useUserPermissionsState();
    const tokenPayload = useTokenPayloadState();

    if (!token || !tokenPayload || !Array.isArray(permissions)) {
        return <Navigate to="/auth" />;
    }

    return <Outlet />;
};
