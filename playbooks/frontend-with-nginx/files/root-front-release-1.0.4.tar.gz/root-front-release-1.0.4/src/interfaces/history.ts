import { UserInfoUDB } from './user';

export interface DocumentHistoryDTO {
    revisionId: number;
    revisionDate: string;
    lastModifiedBy: UserInfoUDB;
}
