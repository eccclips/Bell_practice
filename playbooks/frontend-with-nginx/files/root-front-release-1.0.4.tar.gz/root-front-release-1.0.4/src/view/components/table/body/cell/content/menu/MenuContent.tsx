import React, { useMemo } from 'react';

import { SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { MenuButton, MenuButtonOption } from '../../../../../menu-button';
import { ActionType, TableData } from '../../../../types';

import styles from './MenuContent.module.scss';

type MenuContentProps<Data = any> = {
    actions: ActionType[] | ((data: Data) => ActionType<Data>[]);
    row: TableData<Data>;
    rowIndex: number;
    colIndex: number;
};

const MenuContent = <Data,>(props: MenuContentProps<Data>) => {
    const { actions, row, rowIndex, colIndex } = props;
    const parsedActions = useMemo(
        () => (typeof actions === 'function' ? actions(row) : actions),
        [actions, row]
    );

    const menuOptions: MenuButtonOption[] = useMemo(
        () =>
            parsedActions.map(
                (action) =>
                    ({
                        text: action.name,
                        onClick: (closeMenu) => {
                            action.action(row, { rowIndex, colIndex });
                            closeMenu();
                        },
                        icon: <action.Icon />,
                        type: action.type,
                    }) as MenuButtonOption
            ),
        [parsedActions, row, rowIndex, colIndex]
    );

    if (!menuOptions.length) {
        return null;
    }

    return (
        <div className={styles.icons}>
            <MenuButton
                size="small"
                menuOptions={menuOptions}
                componentType="icon-button"
                stopPropagation
                aria-label="Действия"
            >
                <SvgIcon>
                    <Icons.MoreVertical />
                </SvgIcon>
            </MenuButton>
        </div>
    );
};

export default typedMemo(MenuContent);
