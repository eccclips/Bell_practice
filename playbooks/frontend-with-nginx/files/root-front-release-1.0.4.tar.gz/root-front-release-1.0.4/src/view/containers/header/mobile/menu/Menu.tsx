import React from 'react';

import { Drawer } from '@mui/material';

import { useIsMenuExpanded } from 'src/store/settings';

import { Nav } from './nav';

import styles from './Menu.module.scss';

export const Menu = React.memo(() => {
    const [isExpanded] = useIsMenuExpanded();

    return (
        <Drawer
            anchor="top"
            open={isExpanded}
            hideBackdrop
            className={styles.menu__paper}
            PaperProps={{ className: styles.menu__paper }}
        >
            <div className={styles.menu}>
                <Nav />
            </div>
        </Drawer>
    );
});
