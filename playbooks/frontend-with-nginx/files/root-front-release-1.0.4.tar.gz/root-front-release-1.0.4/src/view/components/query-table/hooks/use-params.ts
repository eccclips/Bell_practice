import { useCallback, useEffect, useMemo } from 'react';

import { useLocation, useSearchParams } from 'react-router-dom';

import { SortInstructionDTO } from 'root-front/interfaces';
import { useTableParamsState } from 'root-front/store';
import { useEvent } from 'root-front/utils';

import { SearchParams } from '../types';
import {
    getDefaultParams,
    getSearchParamsFromURLSearchParams,
    getURLSearchParamsFromSearchParams,
} from '../utils';

type Config = {
    name: string;
    defaultParams: SearchParams;
    saveParamsInURI: boolean;
    itemsPerPage: number[];
};

export const useParams = (config: Config) => {
    const { name, defaultParams, saveParamsInURI, itemsPerPage } = config;

    const location = useLocation();

    const [tableParamsState, setTableParams] = useTableParamsState(name);

    const fullDefaultParams = useMemo(
        () => ({ ...getDefaultParams(itemsPerPage), ...defaultParams }),
        [defaultParams, itemsPerPage]
    );

    const urlSearchParamsInitialValue = useMemo(
        () =>
            new URLSearchParams([
                ['page', fullDefaultParams.page.toString()],
                ['size', fullDefaultParams.size.toString()],
                [
                    'sort',
                    `${
                        fullDefaultParams.sort.field
                    }_${fullDefaultParams.sort.direction.toLowerCase()}`,
                ],
            ]),
        []
    );

    const [urlSearchParams, setUrlSearchParams] = useSearchParams(urlSearchParamsInitialValue);

    const searchParams = getSearchParamsFromURLSearchParams(urlSearchParams, fullDefaultParams);

    const initialParams = saveParamsInURI ? searchParams : fullDefaultParams;

    const tableParams = tableParamsState || initialParams;

    const { page, size, sort } = tableParams;

    const handleSetParams = useEvent(
        (value: SearchParams | ((prevValue: SearchParams) => SearchParams)) => {
            const nextParams = typeof value === 'function' ? value(tableParams) : value;

            setTableParams(nextParams);
            if (saveParamsInURI) {
                setUrlSearchParams(
                    getURLSearchParamsFromSearchParams(nextParams, fullDefaultParams),
                    {
                        replace: true,
                        state: location.state,
                    }
                );
            }
        }
    );

    const onPageChange = useCallback((page: number) => {
        handleSetParams((prevParams) => ({ ...prevParams, page }));
    }, []);

    const onSizeChange = useCallback((size: number) => {
        handleSetParams((prevParams) => ({ ...prevParams, size }));
    }, []);

    const onSortChange = useCallback((sort: SortInstructionDTO) => {
        handleSetParams((prevParams) => ({ ...prevParams, sort }));
    }, []);

    useEffect(() => {
        if (!tableParamsState) {
            setTableParams(initialParams);
        }

        return () => {
            setTableParams(null);
        };
    }, []);

    return {
        page,
        size,
        sort,
        onPageChange,
        onSizeChange,
        onSortChange,
        handleSetParams,
        fullDefaultParams,
    } as const;
};
