export const resetTableSettings = () => {
    Object.keys(localStorage).forEach((key) => {
        if (key.startsWith('tableSettings@')) {
            localStorage.removeItem(key);
        }
    });

    window.location.reload();
};
