import React from 'react';

import { CircularProgress } from '@mui/material';

import styles from './PageLoader.module.scss';

const PageLoader = () => {
    return (
        <div className={styles.page}>
            <CircularProgress />
        </div>
    );
};

export default React.memo(PageLoader);
