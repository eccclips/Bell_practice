import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const AdminPanelMFE = React.lazy(() =>
    loadModule(process.env.MFE_ADMIN_PANEL_HOST, './AdminPanel')
);

export function AdminPanelRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <AdminPanelMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
