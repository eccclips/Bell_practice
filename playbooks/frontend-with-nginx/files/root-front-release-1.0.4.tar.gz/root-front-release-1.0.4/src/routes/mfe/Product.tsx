import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const ProductMFE = React.lazy(() => loadModule(process.env.MFE_PRODUCT_HOST, './Product'));

export function ProductRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <ProductMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
