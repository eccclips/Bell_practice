import { getMonthNameByNumber } from 'root-front/utils';

export const MONTHS_SELECT_OPTIONS = Array(12)
    .fill(0)
    .map((_, index) => {
        const monthName = getMonthNameByNumber(index);

        return { label: monthName, value: index, key: `${monthName}${index}` };
    });
