import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const CounterpartyMFE = React.lazy(() =>
    loadModule(process.env.MFE_COUNTERPARTY_HOST, './Counterparty')
);

export function CounterpartyRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <CounterpartyMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
