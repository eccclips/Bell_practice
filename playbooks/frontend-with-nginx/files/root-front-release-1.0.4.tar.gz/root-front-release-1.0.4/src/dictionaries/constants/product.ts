import { CHIP_COLORS } from 'root-front/components';

export enum PRODUCT_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
}

export const PRODUCT_STATUS_MAP = {
    [PRODUCT_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [PRODUCT_STATUS.CLOSED]: { text: 'Не действует', color: CHIP_COLORS.NEUTRAL },
    [PRODUCT_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};

export enum DELIVERY_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export const DELIVERY_STATUS_MAP = {
    [DELIVERY_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [DELIVERY_STATUS.DELETED]: { text: 'Деактивирован', color: CHIP_COLORS.ERROR },
};

export enum PRODUCT_ATTRIBUTE {
    WHOLESALE_OPERATOR = 'WHOLESALE_OPERATOR',
    AVAILABILITY_DEALER = 'AVAILABILITY_DEALER',
    AVAILABILITY_RENAULT = 'AVAILABILITY_RENAULT',
    AVAILABILITY_NISSAN = 'AVAILABILITY_NISSAN',
    NOMENCLATURE_RAW = 'NOMENCLATURE_RAW',
    COLOR = 'COLOR',
    SOFTWARE = 'SOFTWARE',
}

export const PRODUCT_ATTRIBUTE_MAP = {
    [PRODUCT_ATTRIBUTE.WHOLESALE_OPERATOR]: { text: 'Заявочник Оптовых операторов' },
    [PRODUCT_ATTRIBUTE.AVAILABILITY_DEALER]: { text: 'Заявочник Дилеров' },
    [PRODUCT_ATTRIBUTE.AVAILABILITY_RENAULT]: { text: 'Заявочник Рено' },
    [PRODUCT_ATTRIBUTE.AVAILABILITY_NISSAN]: { text: 'Заявочник NISSAN' },
    [PRODUCT_ATTRIBUTE.NOMENCLATURE_RAW]: { text: 'Номенклатура давальческого сырья' },
    [PRODUCT_ATTRIBUTE.COLOR]: { text: 'Признак цвета' },
    [PRODUCT_ATTRIBUTE.SOFTWARE]: { text: 'Признак наличия ПО' },
};

export enum PRODUCT_GROUP {
    CONTROL_PRODUCT = 'CONTROL_PRODUCT',
    OTHER_PRODUCT = 'OTHER_PRODUCT',
}

export const PRODUCT_GROUP_MAP = {
    [PRODUCT_GROUP.CONTROL_PRODUCT]: { text: 'Контрольная номенклатура' },
    [PRODUCT_GROUP.OTHER_PRODUCT]: { text: 'Прочая номенклатура' },
};
