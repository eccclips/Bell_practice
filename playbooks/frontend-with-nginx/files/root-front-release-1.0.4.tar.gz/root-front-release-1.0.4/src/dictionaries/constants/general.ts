import { CHIP_COLORS } from 'root-front/components';

export enum BASE_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
    CLOSED = 'CLOSED',
}

export const BASE_STATUS_MAP = {
    [BASE_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [BASE_STATUS.DRAFT]: { text: 'Черновик', color: CHIP_COLORS.DRAFT },
    [BASE_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
    [BASE_STATUS.CLOSED]: { text: 'Не действует', color: CHIP_COLORS.NEUTRAL },
};

export const BASE_STATUS_MAP_OPTIONS = [
    {
        key: BASE_STATUS.ACTIVE,
        value: BASE_STATUS.ACTIVE,
        label: BASE_STATUS_MAP[BASE_STATUS.ACTIVE].text,
    },
    {
        key: BASE_STATUS.DRAFT,
        value: BASE_STATUS.DRAFT,
        label: BASE_STATUS_MAP[BASE_STATUS.DRAFT].text,
    },
    {
        key: BASE_STATUS.DELETED,
        value: BASE_STATUS.DELETED,
        label: BASE_STATUS_MAP[BASE_STATUS.DELETED].text,
    },
    {
        key: BASE_STATUS.CLOSED,
        value: BASE_STATUS.CLOSED,
        label: BASE_STATUS_MAP[BASE_STATUS.CLOSED].text,
    },
];
