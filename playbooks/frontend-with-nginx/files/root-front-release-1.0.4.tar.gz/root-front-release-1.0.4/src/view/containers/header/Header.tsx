import React from 'react';

import { LAYOUT, useLayoutState } from 'src/store/settings';

import { DesktopHeader } from './desktop';
import { MobileHeader } from './mobile';

const Header = () => {
    const layout = useLayoutState();

    return layout === LAYOUT.DESKTOP || layout === LAYOUT.TABLET ? (
        <DesktopHeader />
    ) : (
        <MobileHeader />
    );
};

export default React.memo(Header);
