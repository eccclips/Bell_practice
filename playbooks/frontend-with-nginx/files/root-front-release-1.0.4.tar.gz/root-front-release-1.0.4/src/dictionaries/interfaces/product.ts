import { BaseAuditedDTO } from 'root-front/interfaces';

import { DELIVERY_STATUS, PRODUCT_STATUS } from '../constants/product';
import { CounterpartyDTO, ReferenceDTO, WarehouseDTO } from './index';

export interface ProductGroupDTO extends BaseAuditedDTO {
    externalId: string;
    name: string;
}

export interface ProductDTO extends BaseAuditedDTO {
    externalId: string;
    productGroupCode: string;
    productGroupName: string;
    article: string;
    name?: string;
    reference?: string;
    unit: ReferenceDTO;
    characteristics?: { [key: string]: string };
    characteristic: string;
    serialCount?: boolean;
    weight?: number;
    volume?: number;
    quantity?: number;
    minPackingRate?: number;
    transPackingRate?: number;
    packingRateSmallWholesale?: number;
    packingRateLargeWholesale?: number;
    packingRateRetail?: number;
    availabilityRu?: boolean;
    availabilityPsss?: boolean;
    availabilityRenault?: boolean;
    availabilityNissan?: boolean;
    brand?: string;
    promo?: string;
    note?: string;
    colorAttribute?: boolean;
    softwareAttribute?: boolean;
    vinAttribute?: boolean;
    nomenclatureSrk?: boolean;
    nomenclatureRaw?: boolean;
    importBrand?: boolean;
    status?: PRODUCT_STATUS;
    startDate?: number;
    endDate?: number;
    family?: string;
    analogs?: string[];
    warehouseId?: string;
    warehouse?: WarehouseDTO;
    supplierDto?: CounterpartyDTO;
    signDelivery?: SignDeliveryDTO;
    group?: ProductGroupDTO;
}

export interface SupplyPropertyDTO extends BaseAuditedDTO {
    externalId: number;
    name: string;
}

export interface SignDeliveryDTO extends BaseAuditedDTO {
    externalId: number;
    article: string;
    productName: string;
    isShipment: SupplyPropertyDTO;
    responsible: string;
    status: DELIVERY_STATUS;
}

export interface SubcontractModelDTO extends BaseAuditedDTO {
    externalId: string;
    article: string;
    characteristic: string;
    counterpartyId: string;
    counterparty: CounterpartyDTO;
    status: PRODUCT_STATUS;
    modelStart: string;
    modelEnd: string;
    product: ProductDTO;
}

export interface SubcontractModelItemDTO extends BaseAuditedDTO {
    externalId: string;
    article: string;
    characteristic: string;
    quantity: number;
    status: PRODUCT_STATUS;
    modelId: number;
    product: ProductDTO;
    counterparty: CounterpartyDTO;
}
