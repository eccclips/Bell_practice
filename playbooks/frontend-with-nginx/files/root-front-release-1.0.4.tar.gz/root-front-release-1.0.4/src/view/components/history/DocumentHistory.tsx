import React, { useCallback, useMemo } from 'react';

import { useNavigate, useParams } from 'react-router-dom';

import { DocumentHistoryDTO } from 'root-front/interfaces';
import { defaultStyles } from 'root-front/styles';

import { Breadcrumb, Breadcrumbs } from '../breadcrumbs';
import { DocumentTitle } from '../document-title';
import { QueryTable } from '../query-table';
import { useDocumentHistoryList } from './api';
import { COLUMNS, DEFAULT_PARAMS } from './constants';

type Props = {
    /** URL для получения списка ревизий
     *
     * Конструкция `{id}` внутри строки будет заменена на `id` из `params`
     * @example
     * // useParams()[paramsIdKey] === 10
     * `${MS_WAREHOUSE_URL}/warehouse/{id}/revision` // => '/ms-warehouse/warehouse/10/revision'
     */
    historyUrl: string;
    breadcrumbs?: Breadcrumb[];
    paramsIdKey?: string;
    navigateTo?: string | ((id: string) => string);
};

const DocumentHistory = (props: Props) => {
    const { historyUrl, breadcrumbs, paramsIdKey = 'id', navigateTo = '..' } = props;

    const params = useParams();

    const id = params[paramsIdKey];

    const navigate = useNavigate();

    const parsedUrl = useMemo(() => historyUrl.replace('{id}', id), [historyUrl, id]);

    const queryParams = useMemo(() => ({ url: parsedUrl }), [parsedUrl]);

    const handleRowClick = useCallback(
        (row: DocumentHistoryDTO) => {
            const historyRecordString = encodeURI(
                `?history_record=${row.revisionId}@${row.revisionDate}`
            );
            const navigateToValue = typeof navigateTo === 'function' ? navigateTo(id) : navigateTo;

            navigate(`${navigateToValue}${historyRecordString}`);
        },
        [id, navigateTo]
    );

    return (
        <div className={defaultStyles.content}>
            {breadcrumbs && <Breadcrumbs breadcrumbs={breadcrumbs} />}
            <div className={defaultStyles.header}>
                <DocumentTitle title="Журнал истории" withBookmark={false} withHistory={false} />
            </div>
            <div className={defaultStyles.table}>
                <QueryTable
                    query={useDocumentHistoryList}
                    columns={COLUMNS}
                    onRowClick={handleRowClick}
                    queryParams={queryParams}
                    defaultParams={DEFAULT_PARAMS}
                />
            </div>
        </div>
    );
};

export default React.memo(DocumentHistory);
