import { SORT_DIRECTION } from 'root-front/constants';
import { DocumentHistoryDTO } from 'root-front/interfaces';

import { SearchParams } from '../query-table';
import { TableColumn } from '../table';

export const COLUMNS: TableColumn<DocumentHistoryDTO>[] = [
    {
        key: 'revisionId',
        name: '№ записи',
    },
    {
        key: 'revisionDate',
        type: 'date',
        name: 'Дата и время',
    },
    {
        key: 'lastModifiedBy',
        name: 'Автор',
        valueGetter: (data) => data.lastModifiedBy?.fullName,
    },
];

export const DEFAULT_PARAMS: SearchParams = {
    sort: {
        direction: SORT_DIRECTION.DESC,
        field: 'revisionDate',
    },
};
