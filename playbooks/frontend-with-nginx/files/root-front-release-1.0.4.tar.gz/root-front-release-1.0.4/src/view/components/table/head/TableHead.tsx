import React, { useCallback, useMemo } from 'react';

import { Checkbox } from '@mui/material';
import cn from 'classnames';

import { SORT_DIRECTION } from 'root-front/constants';
import { SortInstructionDTO } from 'root-front/interfaces';
import { typedMemo } from 'root-front/utils';

import { getColumnsGrid, getMaxColumnsDepth } from '../simple-table/utils';
import { TABLE_VIEW_MODE, TableColumn, TableData, TableGroupModel, TableViewMode } from '../types';
import { TableHeadCell } from './cell';

import styles from './TableHead.module.scss';

type TableHeadProps<Data = any> = {
    columns: TableColumn<TableData<Data>>[];
    viewMode?: TableViewMode;
    sort?: SortInstructionDTO;
    checkboxSelection?: boolean;
    isAllRowsSelected?: boolean;
    isIndeterminate?: boolean;
    expandable?: boolean;
    groupModel?: TableGroupModel<Data>;
    onSelectRow?: (data: TableData<Data>, checked: boolean) => void;
    onSortChange?: (sort: SortInstructionDTO) => void;
    onSelectAll?: () => void;
    onColumnResize?: (key: string, width: number) => void;
};

const TableHead = <Data,>(props: TableHeadProps<Data>) => {
    const {
        columns,
        viewMode,
        sort,
        checkboxSelection,
        isAllRowsSelected,
        isIndeterminate,
        expandable,
        groupModel,
        onSortChange,
        onSelectAll,
        onColumnResize,
    } = props;

    const handleSortChange = useCallback(
        (field: string) => {
            const isAsc = sort?.field === field && sort?.direction === SORT_DIRECTION.ASC;

            onSortChange?.({ field, direction: isAsc ? SORT_DIRECTION.DESC : SORT_DIRECTION.ASC });
        },
        [onSortChange, sort]
    );

    const createSortHandler = useCallback(
        (field: string) => () => {
            handleSortChange(field);
        },
        [handleSortChange]
    );

    const getSortDirection = useCallback(
        (key: string) => {
            if (sort?.field === key) {
                return sort?.direction === SORT_DIRECTION.ASC ? 'asc' : 'desc';
            }

            return 'asc';
        },
        [sort]
    );

    const isScrollable = viewMode === TABLE_VIEW_MODE.INNER_SCROLL;
    const isSortable = !!onSortChange;
    const isDefaultColumnsWidth = useMemo(() => {
        const check = (columns: TableColumn[]) => {
            return columns.every((column) => {
                if (column.resizeWidth) {
                    return false;
                }

                if (column.children?.length) {
                    return check(column.children);
                }

                return true;
            });
        };

        return check(columns);
    }, [columns]);

    const maxColumnsDepth = useMemo(() => getMaxColumnsDepth(columns), [columns]);

    const isColumnsGrouped = maxColumnsDepth > 1;

    const columnsGrid = useMemo(
        () =>
            isColumnsGrouped
                ? getColumnsGrid(columns)
                : [columns.map((column) => ({ colSpan: 1, rowSpan: 1, isGroup: false, column }))],
        [columns, isColumnsGrouped]
    );

    return (
        <thead className={cn(styles.head, isScrollable && styles.head_scroll)}>
            {columnsGrid.map((row, index) => (
                <tr
                    key={index}
                    className={cn(
                        styles.row,
                        isScrollable && styles.row_scroll,
                        isColumnsGrouped && styles.row_grouped
                    )}
                >
                    {index === 0 && expandable && (
                        <th
                            key="@@EXPAND-ROWS"
                            rowSpan={maxColumnsDepth}
                            className={styles.expandCell}
                        ></th>
                    )}
                    {index === 0 && checkboxSelection && (
                        <th
                            key="@@SELECT-ALL"
                            rowSpan={maxColumnsDepth}
                            className={styles.checkboxCell}
                        >
                            <Checkbox
                                checked={isAllRowsSelected}
                                indeterminate={isIndeterminate}
                                onClick={onSelectAll}
                            />
                        </th>
                    )}
                    {index === 0 && groupModel && (
                        <th key="@@GROUP" rowSpan={maxColumnsDepth} className={styles.groupCell}>
                            {groupModel.groupColumnName}
                        </th>
                    )}
                    {row.map((columnData) => (
                        <TableHeadCell
                            key={columnData.column.key}
                            column={columnData.column}
                            sort={sort}
                            isSortable={isSortable}
                            isDefaultColumnsWidth={isDefaultColumnsWidth}
                            colSpan={columnData.colSpan}
                            rowSpan={columnData.rowSpan}
                            isGroup={columnData.isGroup}
                            getSortDirection={getSortDirection}
                            createSortHandler={createSortHandler}
                            onColumnResize={onColumnResize}
                        />
                    ))}
                    <th key="@@RESIZE-FILLER"></th>
                </tr>
            ))}
        </thead>
    );
};

export default typedMemo(TableHead);
