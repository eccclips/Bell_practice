import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { TextField as TextFieldCore, TextFieldProps as TextFieldCoreProps } from '@mui/material';
import { debounce } from 'lodash';
import { useController, UseControllerProps } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';

import styles from '../Fields.module.scss';

export type TextFieldProps<T> = UseControllerProps<T> &
    TextFieldCoreProps & {
        debounced?: boolean;
        withStaticHelperText?: boolean;
        readOnly?: boolean;
    };

const TextField = <T,>(props: TextFieldProps<T>) => {
    const { debounced, withStaticHelperText, readOnly, ...rest } = props;

    const { field, fieldState } = useController(props);

    const [inputValue, setInputValue] = useState(() => field.value?.toString() || '');

    const onChangeDebounced = useCallback(
        debounce(
            (
                e: React.ChangeEvent<HTMLInputElement>,
                value: string | number,
                onChangeProp: TextFieldCoreProps['onChange']
            ) => {
                field.onChange(value);
                onChangeProp?.(e);
            },
            500,
            {
                maxWait: 1000,
            }
        ),
        []
    );

    const isManualSetRef = useRef(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let value: string | number = e.target.value;
        let inputValue = e.target.value;

        if (props.type === 'number') {
            if (props.inputMode === 'decimal') {
                value = value.replace(/[^0-9]/g, '');
                value = value === '' ? null : +value;
                inputValue = value?.toString() || '';
            } else if (props.inputMode === 'numeric') {
                const isValid = /^[+-]?[0-9]*[.]?[0-9]*$/.test(value);

                if (!isValid) {
                    return;
                }
                const number = Number.isNaN(+value) ? null : +value;
                value = value === '' ? null : number;
            }
        }

        setInputValue(inputValue);
        isManualSetRef.current = true;

        if (debounced) {
            onChangeDebounced(e, value, props.onChange);
        } else {
            field.onChange(value);
            props.onChange?.(e);
        }
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        if (props.type === 'number') {
            if (Number.isNaN(+field.value)) {
                field.onChange(null);
                setInputValue('');
                isManualSetRef.current = true;
                props.onChange?.(e);
            }
        }
        field.onBlur();
        props.onBlur?.(e);
    };

    const inputProps = useMemo(
        () => ({
            readOnly,
            ...(props.inputProps || {}),
            ...(props.inputMode === 'decimal'
                ? { inputMode: 'decimal' as const, pattern: `[0-9]*` }
                : {}),
        }),
        [props.inputProps, props.inputMode, readOnly]
    );

    useEffect(() => {
        if (isManualSetRef.current) {
            isManualSetRef.current = false;
            return;
        }
        setInputValue(field.value?.toString() || '');
    }, [field.value]);

    return (
        <TextFieldCore
            {...rest}
            inputProps={inputProps}
            type={props.type === 'number' ? 'text' : props.type}
            size={props.size || 'small'}
            helperText={
                fieldState.error ? <FormErrorHelper message={fieldState.error.message} /> : null
            }
            FormHelperTextProps={{ className: withStaticHelperText && styles.helperText_static }}
            error={!!fieldState.error}
            onChange={handleChange}
            onBlur={handleBlur}
            value={inputValue}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(TextField);
