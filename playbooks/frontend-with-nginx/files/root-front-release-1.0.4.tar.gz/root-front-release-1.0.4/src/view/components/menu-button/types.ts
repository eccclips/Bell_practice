import { ReactNode } from 'react';

import { RequireAtLeastOne } from 'root-front/types';

export type MenuButtonOption = RequireAtLeastOne<
    {
        text?: string | number;
        icon?: ReactNode;
        onClick?: (closeMenu: () => void) => void;
        renderItem?: (closeMenu: () => void) => ReactNode;
        type?: 'danger';
    },
    'text' | 'renderItem'
>;
