import React from 'react';

import { IconButton, Skeleton, SvgIcon } from '@mui/material';

import { ErrorPage } from 'root-front/components';
import { NotificationDTO } from 'root-front/dictionaries';
import { Icons } from 'root-front/icons';
import { defaultStyles } from 'root-front/styles';

import { ContentSkeleton } from './skeleton';

import styles from './Content.module.scss';

type Props = {
    notification: NotificationDTO;
    handleCloseNotification: () => void;
    isMobile?: boolean;
    isLoading?: boolean;
    isError?: boolean;
};

const Content = (props: Props) => {
    const { notification, handleCloseNotification, isMobile, isLoading, isError } = props;

    return (
        <div className={styles.container}>
            <div className={styles.container__inner}>
                <div className={styles.container__content}>
                    <div className={defaultStyles.content}>
                        <div className={styles.container__header}>
                            {isMobile && (
                                <IconButton
                                    onClick={handleCloseNotification}
                                    size="small"
                                    className={styles.container__close}
                                >
                                    <SvgIcon fontSize="small">
                                        <Icons.ArrowLeft />
                                    </SvgIcon>
                                </IconButton>
                            )}
                            {isLoading ? (
                                <Skeleton width="90%" height={40}></Skeleton>
                            ) : (
                                <h1>{notification.messageTopic}</h1>
                            )}
                        </div>

                        {isLoading ? (
                            <ContentSkeleton />
                        ) : (
                            <div
                                className={styles.content}
                                dangerouslySetInnerHTML={{
                                    __html: notification.messageBody,
                                }}
                            />
                        )}

                        {isError && <ErrorPage />}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default React.memo(Content);
