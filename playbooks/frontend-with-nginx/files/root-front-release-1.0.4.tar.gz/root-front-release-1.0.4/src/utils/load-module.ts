/* eslint-disable no-console */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/ban-ts-comment */
const loadScope = (url: string, scope: string) => {
    const element: any = document.createElement('script');
    const promise = new Promise((resolve, reject) => {
        element.src = url;
        element.type = 'text/javascript';
        element.async = true;
        element.onload = () => resolve(window[scope]);
        element.onerror = reject;
    });
    document.head.appendChild(element);
    promise.finally(() => document.head.removeChild(element));
    return promise;
};

export const loadModule = async (path: string, module: string) => {
    try {
        const startTime = performance.now();
        const [scope, url] = path.split('@');
        const container = await loadScope(url, scope);
        // @ts-ignore
        await __webpack_init_sharing__('default');
        // @ts-ignore
        await container.init(__webpack_share_scopes__.default);
        // @ts-ignore
        const factory = await container.get(module);
        const result = factory();
        const endTime = performance.now();

        setTimeout(() => {
            console.log(
                `%cLoaded module ${module}: ${
                    result?.default?.version || 'unknown version'
                }, load time: ${Math.round(endTime - startTime)}ms`,
                'color: #40a642; font-size: 14px; font-weight: bold; font-family: monospace'
            );
            // @ts-ignore
            window.versions = {
                // @ts-ignore
                ...(window.versions || {}),
                [module]: result?.default?.version,
            };
        }, 0);

        return result;
    } catch (error) {
        console.error(`Error loading module ${module}:`, error);
        throw error;
    }
};
