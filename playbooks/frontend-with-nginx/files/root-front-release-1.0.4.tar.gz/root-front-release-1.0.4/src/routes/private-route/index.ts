export { PrivateRoute } from './PrivateRoute';
