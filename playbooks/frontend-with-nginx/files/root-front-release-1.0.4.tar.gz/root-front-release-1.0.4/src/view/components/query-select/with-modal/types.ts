import { SelectOption } from '../../fields';
import { QuerySelectModalProps } from '../select-modal';

export type QuerySelectWithModalProps<
    Data,
    QueryParams extends Record<string, any>,
    Multiple extends boolean = false,
> = Omit<
    QuerySelectModalProps<Data, QueryParams, Multiple>,
    'opened' | 'onClose' | 'name' | 'title'
> & {
    getOptionFromData: (value: Data) => SelectOption<Data>;
    modalTableName: string;
    modalTitle?: string;
    name?: string;
    placeholder?: string;
    id?: string;
    labelId?: string;
    disabled?: boolean;
    /**
     * Определяет количество отображаемых выбранных значений при `multiple: true`.
     *
     * Чтобы убрать ограничение и отображать все, передайте `-1`
     *
     * @default 5
     */
    limit?: number;
    onChange?: (value: Multiple extends true ? Data[] : Data) => void;
    onBlur?: React.FocusEventHandler;
    error?: boolean;
    inputRef?: React.Ref<any>;
    helperText?: React.ReactNode;
    className?: string;
};
