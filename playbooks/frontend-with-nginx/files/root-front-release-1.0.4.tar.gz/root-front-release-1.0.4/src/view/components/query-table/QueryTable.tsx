import React, { useCallback, useEffect, useMemo } from 'react';

import { useLocation } from 'react-router-dom';

import { typedMemo, useEvent } from 'root-front/utils';

import { DEFAULT_ITEMS_PER_PAGE, Table, TableData } from '../table';
import { TableError } from './components';
import { useColumns, useFilters, useParams, useSavedFilters, useSettings } from './hooks';
import { QueryTableProps } from './types';

const QueryTable = <D, P, Data extends TableData<D>, ParsedData extends TableData<P>, Params>(
    props: QueryTableProps<D, P, Data, ParsedData, Params>
) => {
    const location = useLocation();

    const {
        query,
        getData,
        columns,
        filters,
        saveParamsInURI = true,
        getRequestFilters,
        name = location.pathname,
        dataKey = 'id',
        defaultParams,
        defaultFilters = null,
        itemsPerPage = DEFAULT_ITEMS_PER_PAGE,
        queryParams,
        allowColumnSettings,
        allowSavedFilters = true,
        isLoading: isLoadingProp,
        pageable = true,
        ...rest
    } = props;

    const { settings, onColumnsSettingsChange, onColumnsSettingsReset, onColumnResize } =
        useSettings({ name, columns });

    const {
        page,
        size,
        sort,
        onPageChange,
        onSizeChange,
        onSortChange,
        handleSetParams,
        fullDefaultParams,
    } = useParams({ name, defaultParams, saveParamsInURI, itemsPerPage });

    const {
        filterValues,
        filterValuesState,
        requestFilters,
        isFiltersChanged,
        allowResetFiltersToDefault,
        filterTimestamp,
        onFiltersChange,
        onFiltersReset,
        setFilterValues,
    } = useFilters({ name, filters, defaultFilters, getRequestFilters });

    const savedFilters = useSavedFilters({
        tableName: name,
        allowSavedFilters,
        appliedFilter: filterValuesState?.appliedFilter,
        setFilterValues,
    });

    const { displayedColumns, extendedColumns, isColumnsChanged } = useColumns({
        columns,
        settings,
    });

    const { data, isFetching, isError, refetch } = query({
        page: pageable ? page : 0,
        size: pageable ? size : 1000,
        sort,
        params: queryParams,
        filters: requestFilters,
        timestamp: filterTimestamp,
    });

    const parsedData = useMemo(() => {
        if (data) {
            return (getData?.(data) || data.data) as ParsedData[];
        }

        return null;
    }, [data]);

    const { total, totalPages } = data || {};

    const isEmpty = !isFetching && !isError && parsedData?.length === 0;

    const handleRefresh = useCallback(() => {
        refetch();
    }, []);

    const handleResetAll = useEvent(() => {
        onColumnsSettingsReset?.();
        onFiltersReset?.(true);
        handleSetParams(fullDefaultParams);
    });

    useEffect(() => {
        if (data?.totalPages <= page) {
            onPageChange(0);
        }
    }, [data?.totalPages, page]);

    return (
        <TableError onResetAll={handleResetAll}>
            <Table
                {...rest}
                data={parsedData}
                columns={displayedColumns}
                extendedColumns={extendedColumns}
                dataKey={dataKey}
                page={page}
                size={size}
                sort={sort}
                itemsPerPage={itemsPerPage}
                totalElements={total}
                totalPages={totalPages}
                isLoading={isLoadingProp || isFetching}
                isEmpty={isEmpty}
                isError={isError}
                filters={filters}
                filterValues={filterValues}
                isFiltersChanged={isFiltersChanged}
                hideFooter={!pageable}
                onPageChange={onPageChange}
                onSizeChange={onSizeChange}
                onSortChange={onSortChange}
                onColumnsSettingsChange={onColumnsSettingsChange}
                onColumnsSettingsReset={onColumnsSettingsReset}
                onColumnResize={onColumnResize}
                onFiltersChange={onFiltersChange}
                onFiltersReset={onFiltersReset}
                onRefresh={handleRefresh}
                savedFilters={savedFilters}
                isColumnsChanged={isColumnsChanged}
                allowColumnSettings={allowColumnSettings}
                allowResetFiltersToDefault={allowResetFiltersToDefault}
            />
        </TableError>
    );
};

export default typedMemo(QueryTable);
