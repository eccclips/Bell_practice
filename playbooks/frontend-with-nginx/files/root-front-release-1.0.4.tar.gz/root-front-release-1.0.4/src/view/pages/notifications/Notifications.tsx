import React, { useCallback, useMemo } from 'react';

import { Tab, Tabs } from '@mui/material';

import { EmptyPage, LoaderOverlay, LoadingButton } from 'root-front/components';
import { defaultStyles } from 'root-front/styles';

import { useActions } from './actions';
import { useNotifications } from './api';
import { FILTER_TABS } from './constants';
import { NotificationItem, NotificationListSkeleton } from './notification-item';
import { NotificationPage } from './notification-page';
import { NotificationsHeader } from './notifications-header';

import styles from './Notifications.module.scss';

const Notifications = () => {
    const {
        selected,
        currentTab,
        setTab,
        setSelected,
        searchText,
        setSearchText,
        filterTab,
        setFilterTab,
        handleReadCurrentNotification,
        actions,
        openNotification,
        openNotificationId,
        isOpen,
    } = useActions();

    const {
        data,
        isFetching,
        isPreviousData,
        isLoading,
        isRefetching,
        refetch,
        fetchNextPage,
        isFetchingNextPage,
        hasNextPage,
    } = useNotifications({
        tab: currentTab,
        filterTab,
        search: searchText,
    });

    const handleRefetch = useCallback(() => {
        refetch();
    }, []);

    const parsedData = useMemo(() => data?.pages?.flatMap((page) => page.data) || [], [data]);

    return (
        <div className={defaultStyles.content}>
            <div className={styles.container}>
                <div className={styles.notifications}>
                    <NotificationsHeader
                        data={parsedData}
                        selected={selected}
                        currentTab={currentTab}
                        setSelected={setSelected}
                        setSearchText={setSearchText}
                        setTab={setTab}
                        actions={actions}
                        handleRefetch={handleRefetch}
                    />

                    <Tabs
                        value={filterTab}
                        onChange={(_, value) => setFilterTab(value as FILTER_TABS)}
                        className={styles.tabs}
                        variant="scrollable"
                        scrollButtons="auto"
                    >
                        <Tab label="ВСЕ" value={FILTER_TABS.ALL} className={styles.tabs__item} />
                        <Tab
                            label="НЕПРОЧИТАННЫЕ"
                            value={FILTER_TABS.UNREAD}
                            className={styles.tabs__item}
                        />
                        <Tab
                            label="ПРОЧИТАННЫЕ"
                            value={FILTER_TABS.READ}
                            className={styles.tabs__item}
                        />
                    </Tabs>

                    <div className={styles.list}>
                        <div className={styles.list__inner}>
                            {isLoading ? (
                                <NotificationListSkeleton />
                            ) : (
                                parsedData.map((notification) => (
                                    <NotificationItem
                                        key={notification.id}
                                        notification={notification}
                                        openNotificationId={openNotificationId}
                                        checked={
                                            !!selected.find((item) => item.id === notification.id)
                                        }
                                        showCheckbox={!!selected.length}
                                        setSelected={setSelected}
                                        handleOpenNotification={openNotification}
                                    />
                                ))
                            )}
                            {hasNextPage && (
                                <LoadingButton
                                    fullWidth
                                    className={styles.list__loadMore}
                                    isLoading={isFetchingNextPage}
                                    onClick={() => fetchNextPage()}
                                >
                                    Показать еще
                                </LoadingButton>
                            )}
                        </div>

                        {isRefetching && isPreviousData && <LoaderOverlay />}
                        {!isFetching && !parsedData.length && (
                            <EmptyPage text="Уведомлений нет" className={styles.list__empty} />
                        )}
                    </div>
                </div>

                <NotificationPage
                    notificationId={openNotificationId}
                    opened={isOpen}
                    handleReadCurrentNotification={handleReadCurrentNotification}
                />
            </div>
        </div>
    );
};

export default React.memo(Notifications);
