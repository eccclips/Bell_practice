import React, { useCallback, useEffect, useMemo, useState } from 'react';

import { Collapse, Stack } from '@mui/material';
import { resolvePath, useLocation } from 'react-router-dom';

import { NavTab } from 'src/routes';
import { useIsMenuExpanded } from 'src/store/settings';

import { NavItem } from '../nav-item';

import styles from './CollapsableList.module.scss';

interface Props {
    tab: NavTab;
    isMobile?: boolean;
}

export const CollapsableList = React.memo(({ tab, isMobile }: Props) => {
    const location = useLocation();

    const [opened, setOpened] = useState(false);
    const [isExpanded, setIsExpanded] = useIsMenuExpanded();

    const isActive = useMemo(() => {
        return tab.children.some((child) =>
            location.pathname.startsWith(resolvePath(child.path, '/').pathname)
        );
    }, [location.pathname, tab]);

    const handleOpen = useCallback(() => {
        setOpened((isOpened) => {
            if (!isOpened) {
                setIsExpanded(true);
            }

            return !isOpened;
        });
    }, []);

    useEffect(() => {
        if (!isExpanded) {
            setOpened(false);
        }
    }, [isExpanded]);

    return (
        <li className={styles.element}>
            <NavItem
                text={tab.name}
                Icon={tab.Icon}
                type="button"
                onClick={handleOpen}
                isActive={isActive}
                opened={opened}
                isMobile={isMobile}
            />
            <Collapse in={opened} mountOnEnter unmountOnExit>
                <Stack gap="4px" className={styles.list} component="ul">
                    {tab.children.map((child) => (
                        <li key={child.name} className={styles.element}>
                            <NavItem
                                text={child.name}
                                type="link"
                                to={child.path}
                                Icon={child.Icon}
                                inner
                                isMobile={isMobile}
                            />
                        </li>
                    ))}
                </Stack>
            </Collapse>
        </li>
    );
});
