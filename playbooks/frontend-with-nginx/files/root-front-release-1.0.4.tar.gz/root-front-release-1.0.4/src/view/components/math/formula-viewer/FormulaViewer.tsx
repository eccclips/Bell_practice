import React, { useMemo } from 'react';

import { ClickAwayListener } from '@mui/material';
import cn from 'classnames';

import { FormulaViewerProps } from '../types';
import { renderFormula } from './render-formula';

import styles from './FormulaViewer.module.scss';

const FormulaViewer = (props: FormulaViewerProps) => {
    const { formula, hoveredOperand, onHover, size = 'medium', error } = props;

    const onMouseOver = (
        e: React.MouseEvent<HTMLSpanElement> | React.MouseEvent<HTMLSpanElement>
    ) => {
        onHover?.((e.target as HTMLElement).getAttribute('data-uid'));
    };

    const onMouseLeave = () => {
        onHover?.(null);
    };

    const content = useMemo(
        () =>
            renderFormula({
                formula,
                depth: 0,
                hoveredOperand,
                onHover: onHover ? onMouseOver : undefined,
            }),
        [formula, hoveredOperand]
    );

    return (
        <ClickAwayListener onClickAway={onMouseLeave}>
            <span
                className={cn(
                    styles.formula,
                    styles[`formula_${size}`],
                    error && styles.formula_error
                )}
                onMouseOver={onHover ? onMouseOver : undefined}
                onMouseLeave={onHover ? onMouseLeave : undefined}
                onClick={onHover ? onMouseOver : undefined}
            >
                {formula ? content : '—'}
            </span>
        </ClickAwayListener>
    );
};

export default React.memo(FormulaViewer);
