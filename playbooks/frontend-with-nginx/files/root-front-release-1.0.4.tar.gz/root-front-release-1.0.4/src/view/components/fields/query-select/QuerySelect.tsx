import React from 'react';

import { useController, UseControllerProps } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import { QuerySelect as QuerySelectCore, QuerySelectProps } from '../../query-select';

export type QuerySelectFieldProps<
    T,
    Data,
    Value,
    Multiple extends boolean = false,
> = UseControllerProps<T> & Omit<QuerySelectProps<Data, Value, Multiple>, 'value'>;

const QuerySelect = <T, Data, Value, Multiple extends boolean = false>(
    props: QuerySelectFieldProps<T, Data, Value, Multiple>
) => {
    const { field, fieldState } = useController(props);

    const handleChange = (value: Multiple extends true ? Value[] : Value) => {
        field.onChange(value);
        props.onChange?.(value);
    };

    const handleBlur = (e: React.FocusEvent<HTMLDivElement>) => {
        field.onBlur();
        props.onBlur?.(e);
    };

    return (
        <QuerySelectCore
            {...props}
            helperText={
                fieldState.error ? <FormErrorHelper message={fieldState.error.message} /> : null
            }
            error={!!fieldState.error}
            onChange={handleChange}
            onBlur={handleBlur}
            value={field.value as any}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(QuerySelect);
