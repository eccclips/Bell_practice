import React, { useMemo } from 'react';

import { SvgIcon } from '@mui/material';
import {
    DatePicker as DatePickerCore,
    DatePickerProps as DatePickerCoreProps,
    DateValidationError,
    DateView,
    PickerChangeHandlerContext,
} from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { useController, UseControllerProps } from 'react-hook-form';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import { getStringValueFrom } from '../daterange/utils';

import styles from './DatePicker.module.scss';

const DEFAULT_VIEWS: DateView[] = ['year', 'month', 'day'];

export type DatePickerProps<T> = UseControllerProps<T> &
    DatePickerCoreProps<dayjs.Dayjs> & {
        id?: string;
    };

const DatePicker = <T,>(props: DatePickerProps<T>) => {
    const { views = DEFAULT_VIEWS } = props;

    const { field, fieldState } = useController(props);

    const handleChange = (
        value: dayjs.Dayjs,
        ctx: PickerChangeHandlerContext<DateValidationError>
    ) => {
        if (!value || !value.isValid()) {
            field.onChange(null);
            return;
        }
        const stringValue = getStringValueFrom(value, views);

        field.onChange(stringValue);
        props.onChange?.(value, ctx);
    };

    const handleBlur = () => {
        field.onBlur();
    };

    const value = useMemo(
        () => (field.value ? dayjs((field.value as string).slice(0, 10)) : ''),
        [field.value]
    );

    return (
        <DatePickerCore
            {...props}
            slotProps={{
                calendarHeader: { className: styles.datepicker__header },
                textField: {
                    helperText: fieldState.error ? (
                        <FormErrorHelper message={fieldState.error.message} />
                    ) : null,
                    onBlur: handleBlur,
                    error: !!fieldState.error,
                    id: props.id,
                    size: 'small',
                },
                actionBar: {
                    actions: ['clear'],
                },
            }}
            slots={{
                openPickerIcon: () => (
                    <SvgIcon>
                        <Icons.CalendarThin />
                    </SvgIcon>
                ),
                rightArrowIcon: () => (
                    <SvgIcon>
                        <Icons.ArrowRight />
                    </SvgIcon>
                ),
                leftArrowIcon: () => (
                    <SvgIcon>
                        <Icons.ArrowLeft />
                    </SvgIcon>
                ),
                switchViewIcon: (props) => (
                    <SvgIcon
                        {...props}
                        style={{
                            transition: 'transform 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
                        }}
                    >
                        <Icons.ArrowDown />
                    </SvgIcon>
                ),
            }}
            onChange={handleChange}
            value={value}
            views={views}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(DatePicker);
