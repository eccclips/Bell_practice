import { useMemo } from 'react';

import { PERMISSIONS, useUserPermissionsState } from '../store/permissions';

type PermissionsType = (PERMISSIONS | PermissionsType)[];

const deepFlatArray = (array: PermissionsType): PERMISSIONS[] => {
    const result: PERMISSIONS[] = [];

    array.forEach((el) => {
        if (Array.isArray(el)) {
            result.push(...deepFlatArray(el as PermissionsType));
            return;
        }
        result.push(el);
    });

    return result;
};

export const hasPermissions = (
    userPermissions: PERMISSIONS[],
    permissions: PermissionsType,
    method: 'some' | 'every' = 'some'
) => {
    if (userPermissions.includes(PERMISSIONS.SUPER_ADMIN)) {
        return true;
    }

    const flatPermissions = deepFlatArray(permissions);

    if (method === 'some') {
        const hasSomePermission = flatPermissions.some((permission) =>
            userPermissions.includes(permission)
        );

        return hasSomePermission;
    } else {
        const hasEveryPermission = flatPermissions.every((permission) =>
            userPermissions.includes(permission)
        );

        return hasEveryPermission;
    }
};

export const useHasPermission = (permission: PERMISSIONS) => {
    const userPermissions = useUserPermissionsState();

    const hasPermission = useMemo(
        () => hasPermissions(userPermissions, [permission], 'some'),
        [userPermissions, permission]
    );

    return hasPermission;
};
