import React from 'react';

import { Chip as ChipCore, ChipProps as ChipCoreProps } from '@mui/material';
import cn from 'classnames';

import styles from './Chip.module.scss';

export enum CHIP_COLORS {
    SUCCESS = 'success',
    ERROR = 'error',
    NEUTRAL = 'neutral',
    DRAFT = 'draft',
    DISABLED = 'disabled',
}

type ChipProps = Omit<ChipCoreProps, 'color'> & {
    color?: CHIP_COLORS;
};

const Chip = (props: ChipProps) => {
    const { color = CHIP_COLORS.NEUTRAL, ...rest } = props;

    return <ChipCore {...rest} className={cn(styles.chip, styles[`chip_${color}`])} />;
};

export default React.memo(Chip);
