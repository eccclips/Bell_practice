import React, { useMemo } from 'react';

import { Checkbox, Typography } from '@mui/material';
import cn from 'classnames';
import dayjs from 'dayjs';

import { NotificationDTO } from 'root-front/dictionaries';

import styles from './NotificationItem.module.scss';

interface Props {
    notification: NotificationDTO;
    openNotificationId: number;
    checked: boolean;
    showCheckbox: boolean;
    handleOpenNotification: (id: number) => void;
    setSelected: React.Dispatch<React.SetStateAction<NotificationDTO[]>>;
}

const NotificationItem = (props: Props) => {
    const {
        notification,
        openNotificationId,
        checked,
        showCheckbox,
        setSelected,
        handleOpenNotification,
    } = props;

    const textPreview = useMemo(() => {
        const el = document.createElement('div');
        el.innerHTML = notification.messageBody;
        const text = el.textContent || el.innerText || '';

        return text.slice(0, 40).replace(/\n+/g, ' ').replace(/\s+/g, ' ');
    }, [notification?.messageBody]);

    return (
        <div
            key={notification.id}
            className={cn(
                styles.item,
                !notification.isRead && styles.item_unread,
                openNotificationId === notification.id && styles.item_opened,
                showCheckbox && styles.item_checkboxVisible
            )}
            tabIndex={0}
            role="button"
            onClick={() => handleOpenNotification(notification.id)}
            onKeyDown={(e) => {
                if (e.code === 'Enter') {
                    handleOpenNotification(notification.id);
                }
            }}
        >
            <div className={styles.item__checkboxContainer}>
                <Checkbox
                    className={styles.item__checkbox}
                    size="small"
                    checked={checked}
                    onClick={(e) => {
                        e.stopPropagation();
                        if (checked) {
                            setSelected((prevSelected) =>
                                prevSelected.filter((item) => item.id !== notification.id)
                            );
                        } else {
                            setSelected((prevSelected) => [...prevSelected, notification]);
                        }
                    }}
                />
            </div>
            <div className={styles.item__start}>
                <Typography noWrap className={styles.item__title}>
                    {notification.messageTopic}
                </Typography>
                <Typography noWrap className={styles.item__preview} variant="h3">
                    {textPreview}
                </Typography>
            </div>
            <div className={styles.item__end}>
                <div className={styles.item__date}>
                    {dayjs(notification.messageDate).format('DD.MM.YYYY')}
                </div>
                <div className={styles.item__date}>
                    {dayjs(notification.messageDate).format('HH:mm')}
                </div>
            </div>
        </div>
    );
};

export default React.memo(NotificationItem);
