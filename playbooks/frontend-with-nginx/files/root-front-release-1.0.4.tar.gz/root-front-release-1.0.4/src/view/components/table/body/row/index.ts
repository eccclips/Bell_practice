export { default as TableRow, type TableRowProps } from './TableRow';
