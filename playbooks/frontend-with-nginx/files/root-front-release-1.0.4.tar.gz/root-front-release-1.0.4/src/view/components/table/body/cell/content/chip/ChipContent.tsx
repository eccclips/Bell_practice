import React, { memo } from 'react';

import { Chip, CHIP_COLORS } from '../../../../../chip';
import { BooleanContent } from '../boolean';

type ChipContentProps = {
    value: boolean;
    color: CHIP_COLORS;
};

const ChipContent = (props: ChipContentProps) => {
    const { value, color = CHIP_COLORS.NEUTRAL } = props;

    return value ? (
        <Chip label={value} color={color} size="small" />
    ) : (
        <BooleanContent value={false} />
    );
};

export default memo(ChipContent);
