import React from 'react';

import cn from 'classnames';
import { useWatch } from 'react-hook-form';

import { ELEMENT_TYPE, OPERANDS_LENGTH_FROM_OPERATOR_MAP } from '../../constants';
import { FormulaConstructorOperandProps } from '../../types';
import { getOperandTitle } from '../../utils';
import { Argument } from './argument';
import { Operator } from './operator';

import styles from '../FormulaConstructor.module.scss';

const Operand = (props: FormulaConstructorOperandProps) => {
    const {
        prefixName,
        control,
        hoveredOperand,
        title,
        handleChangeElementType,
        handleChangeOperatorType,
        handleChangeArgumentType,
        handleAppendOperand,
        handleRemoveOperand,
        additionalArguments,
        deletable,
        children,
    } = props;

    const operandUid = useWatch({
        control,
        name: `${prefixName}uid` as 'formula.uid',
        exact: true,
    });

    const operandType = useWatch({
        control,
        name: `${prefixName}type` as 'formula.type',
        exact: true,
    });
    const operandOperator = useWatch({
        control,
        name: `${prefixName}operator` as 'formula.operator',
        exact: true,
    });
    const operandOperands = useWatch({
        control,
        name: `${prefixName}operands` as 'formula.operands',
        exact: true,
    });

    if (!operandUid) {
        return null;
    }

    return (
        <div
            className={cn(styles.operand, hoveredOperand === operandUid && styles.operand_hovered)}
            key={operandUid}
        >
            {title && <div>{title}</div>}
            {operandType === ELEMENT_TYPE.OPERATOR ? (
                <>
                    <Operator
                        control={control}
                        prefixName={prefixName}
                        handleChangeElementType={handleChangeElementType}
                        handleChangeOperatorType={handleChangeOperatorType}
                        handleRemoveOperand={handleRemoveOperand}
                        handleAppendOperand={handleAppendOperand}
                        deletable={deletable}
                    >
                        {children}
                    </Operator>
                    {operandOperands?.map((value, index) => {
                        const name = `${prefixName}operands.${index}.`;

                        return (
                            <Operand
                                key={`${value.uid}_${index}`}
                                prefixName={name}
                                control={control}
                                hoveredOperand={hoveredOperand}
                                title={getOperandTitle(operandOperator, index)}
                                handleChangeElementType={handleChangeElementType}
                                handleChangeOperatorType={handleChangeOperatorType}
                                handleChangeArgumentType={handleChangeArgumentType}
                                handleAppendOperand={handleAppendOperand}
                                handleRemoveOperand={handleRemoveOperand}
                                additionalArguments={additionalArguments}
                                deletable={
                                    operandOperator &&
                                    operandOperands?.length >
                                        OPERANDS_LENGTH_FROM_OPERATOR_MAP[operandOperator].min &&
                                    operandOperands?.length <
                                        OPERANDS_LENGTH_FROM_OPERATOR_MAP[operandOperator].max
                                }
                            />
                        );
                    })}
                </>
            ) : (
                <Argument
                    control={control}
                    prefixName={prefixName}
                    handleChangeArgumentType={handleChangeArgumentType}
                    handleChangeElementType={handleChangeElementType}
                    handleRemoveOperand={handleRemoveOperand}
                    additionalArguments={additionalArguments}
                    deletable={deletable}
                >
                    {children}
                </Argument>
            )}
        </div>
    );
};

export default React.memo(Operand);
