import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const SupplyMFE = React.lazy(() => loadModule(process.env.MFE_SUPPLY_HOST, './Supply'));

export function SupplyRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <SupplyMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
