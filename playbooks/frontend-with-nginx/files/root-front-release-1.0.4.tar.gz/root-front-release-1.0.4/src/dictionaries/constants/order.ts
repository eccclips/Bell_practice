import { CHIP_COLORS } from 'root-front/components';

export enum ORDER_STATUS {
    PROCESSING = 'PROCESSING',
    NO_RESERVATION = 'NO_RESERVATION',
    NO_ZNO = 'NO_ZNO',
    NO_PROCESSING = 'NO_PROCESSING',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
    DRAFT = 'DRAFT',
    NEW = 'NEW',
    DELAY = 'DELAY',
    EXCLUDED = 'EXCLUDED',
    DONE = 'DONE',
    FINISHED = 'FINISHED',
}

export const ORDER_STATUS_MAP = {
    [ORDER_STATUS.PROCESSING]: {
        text: 'В обработке',
        color: CHIP_COLORS.SUCCESS,
    },
    [ORDER_STATUS.DONE]: {
        text: 'Обработка завершена',
        color: CHIP_COLORS.SUCCESS,
    },
    [ORDER_STATUS.FINISHED]: {
        text: 'Исполнен',
        color: CHIP_COLORS.DISABLED,
    },
    [ORDER_STATUS.NO_RESERVATION]: {
        text: 'Запрет на резервирование',
        color: CHIP_COLORS.DISABLED,
    },
    [ORDER_STATUS.NO_ZNO]: {
        text: 'Запрет на ЗнО',
        color: CHIP_COLORS.DISABLED,
    },
    [ORDER_STATUS.NO_PROCESSING]: {
        text: 'Запрет на обработку',
        color: CHIP_COLORS.DISABLED,
    },
    [ORDER_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
    [ORDER_STATUS.CLOSED]: {
        text: 'Закрыт',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ORDER_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
    [ORDER_STATUS.NEW]: {
        text: 'К выполнению',
        color: CHIP_COLORS.DRAFT,
    },
    [ORDER_STATUS.DELAY]: {
        text: 'Отложен',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ORDER_STATUS.EXCLUDED]: {
        text: 'Исключён из обработки',
        color: CHIP_COLORS.ERROR,
    },
};

export enum ORDER_TYPE {
    MOVEMENT = 'MOVEMENT',
    REQUEST = 'REQUEST',
    SALE = 'SALE',
}

export const ORDER_TYPE_MAP = {
    [ORDER_TYPE.MOVEMENT]: {
        text: 'Перемещение',
    },
    [ORDER_TYPE.REQUEST]: {
        text: 'Заявка',
    },
    [ORDER_TYPE.SALE]: {
        text: 'Продажа',
    },
};

export enum ORDER_ITEM_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
    FINISHED = 'FINISHED',
    CLOSED = 'CLOSED',
}

export const ORDER_ITEM_STATUS_MAP = {
    [ORDER_ITEM_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [ORDER_ITEM_STATUS.FINISHED]: { text: 'Исполнен', color: CHIP_COLORS.DISABLED },
    [ORDER_ITEM_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
    [ORDER_ITEM_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
};

export enum PROVISION_SOURCE {
    FROM_STOCK = 'FROM_STOCK',
    FROM_TRANSIT = 'FROM_TRANSIT',
    FROM_SCHEDULED_DELIVERY = ' FROM_SCHEDULED_DELIVERY',
    NOT_AVAILABLE = 'NOT_AVAILABLE',
}

export const PROVISION_SOURCE_MAP = {
    [PROVISION_SOURCE.FROM_STOCK]: {
        text: 'Из запаса',
    },
    [PROVISION_SOURCE.FROM_TRANSIT]: {
        text: 'Из пути',
    },
    [PROVISION_SOURCE.FROM_SCHEDULED_DELIVERY]: {
        text: 'Из графика поставки',
    },
    [PROVISION_SOURCE.NOT_AVAILABLE]: {
        text: 'Отсутствует',
    },
};

export enum SUPPLY_CHAIN_REPROCESSING_TASK_STATUS {
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    PROCESSING_ERROR = 'PROCESSING_ERROR',
    NEW = 'NEW',
}

export const SUPPLY_CHAIN_REPROCESSING_TASK_STATUS_MAP = {
    [SUPPLY_CHAIN_REPROCESSING_TASK_STATUS.COMPLETED]: {
        text: 'Выполнен',
        color: CHIP_COLORS.SUCCESS,
    },
    [SUPPLY_CHAIN_REPROCESSING_TASK_STATUS.IN_PROGRESS]: {
        text: 'В процессе',
        color: CHIP_COLORS.DRAFT,
    },
    [SUPPLY_CHAIN_REPROCESSING_TASK_STATUS.PROCESSING_ERROR]: {
        text: 'Ошибка обработки',
        color: CHIP_COLORS.ERROR,
    },
    [SUPPLY_CHAIN_REPROCESSING_TASK_STATUS.NEW]: {
        text: 'Новый',
        color: CHIP_COLORS.NEUTRAL,
    },
};

export enum ORDER_REPRIORITIZING_TASK_STATUS {
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    PROCESSING_ERROR = 'PROCESSING_ERROR',
    NEW = 'NEW',
}

export const ORDER_REPRIORITIZING_TASK_STATUS_MAP = {
    [ORDER_REPRIORITIZING_TASK_STATUS.COMPLETED]: {
        text: 'Выполнен',
        color: CHIP_COLORS.SUCCESS,
    },
    [ORDER_REPRIORITIZING_TASK_STATUS.IN_PROGRESS]: {
        text: 'В процессе',
        color: CHIP_COLORS.DRAFT,
    },
    [ORDER_REPRIORITIZING_TASK_STATUS.PROCESSING_ERROR]: {
        text: 'Ошибка обработки',
        color: CHIP_COLORS.ERROR,
    },
    [ORDER_REPRIORITIZING_TASK_STATUS.NEW]: {
        text: 'Новый',
        color: CHIP_COLORS.NEUTRAL,
    },
};

export enum SERVICE_RATE_STATUS {
    FIRST = 'FIRST',
    SECOND = 'SECOND',
    THIRD = 'THIRD',
}

export const SERVICE_RATE_STATUS_MAP = {
    [SERVICE_RATE_STATUS.FIRST]: {
        text: 'Первый',
    },
    [SERVICE_RATE_STATUS.SECOND]: {
        text: 'Второй',
    },
    [SERVICE_RATE_STATUS.THIRD]: {
        text: 'Третий',
    },
};

export enum REPROCESSING_HISTORY_STATE {
    BEFORE = 'BEFORE',
    AFTER = 'AFTER',
}

export const REPROCESSING_HISTORY_STATE_MAP = {
    [REPROCESSING_HISTORY_STATE.BEFORE]: {
        text: 'До обработки',
    },
    [REPROCESSING_HISTORY_STATE.AFTER]: {
        text: 'После обработки',
    },
};

export enum TASK_WSO_REASON_TYPE {
    SCHEDULE = 'SCHEDULE',
    MANUAL = 'MANUAL',
    CHANGE_SET_WAREHOUSES = 'CHANGE_SET_WAREHOUSES',
    CHANGE_CALC_FORMULA = 'CHANGE_CALC_FORMULA',
    CORRECTION = 'CORRECTION',
}

export const TASK_WSO_REASON_TYPE_MAP = {
    [TASK_WSO_REASON_TYPE.SCHEDULE]: { text: 'По расписанию' },
    [TASK_WSO_REASON_TYPE.CHANGE_CALC_FORMULA]: { text: 'Изменение формул расчета' },
    [TASK_WSO_REASON_TYPE.CHANGE_SET_WAREHOUSES]: {
        text: 'Изменение списка складов',
    },
    [TASK_WSO_REASON_TYPE.MANUAL]: { text: 'Ручное обновление' },
    [TASK_WSO_REASON_TYPE.CORRECTION]: { text: 'Корректировка' },
};

export enum CALC_TASK_WSO_STATUS {
    NEW = 'NEW',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    CANCELED = 'CANCELED',
    ERROR = 'ERROR',
}

export const CALC_TASK_WSO_STATUS_MAP = {
    [CALC_TASK_WSO_STATUS.NEW]: {
        text: 'Запланировано',
        color: CHIP_COLORS.NEUTRAL,
    },
    [CALC_TASK_WSO_STATUS.IN_PROGRESS]: {
        text: 'В работе',
        color: CHIP_COLORS.DRAFT,
    },
    [CALC_TASK_WSO_STATUS.COMPLETED]: {
        text: 'Завершено',
        color: CHIP_COLORS.SUCCESS,
    },
    [CALC_TASK_WSO_STATUS.CANCELED]: {
        text: 'Отменено',
        color: CHIP_COLORS.ERROR,
    },
    [CALC_TASK_WSO_STATUS.ERROR]: {
        text: 'Ошибка',
        color: CHIP_COLORS.ERROR,
    },
};

export enum WSO_PARTY_STATUS {
    TO_EXECUTE = 'TO_EXECUTE',
    RESERVATION = 'RESERVATION',
    FORBIDDEN_RESERVATION = 'FORBIDDEN_RESERVATION',
    CLOSED = 'CLOSED',
    FINISHED = 'FINISHED',
}

export const WSO_PARTY_STATUS_MAP = {
    [WSO_PARTY_STATUS.TO_EXECUTE]: {
        text: 'К выполнению',
        color: CHIP_COLORS.DRAFT,
    },
    [WSO_PARTY_STATUS.RESERVATION]: {
        text: 'Передана в резервирование',
        color: CHIP_COLORS.SUCCESS,
    },
    [WSO_PARTY_STATUS.FORBIDDEN_RESERVATION]: {
        text: 'Запрет на резервирование',
        color: CHIP_COLORS.DISABLED,
    },
    [WSO_PARTY_STATUS.CLOSED]: {
        text: 'Закрыт',
        color: CHIP_COLORS.NEUTRAL,
    },
    [WSO_PARTY_STATUS.FINISHED]: {
        text: 'Исполнен',
        color: CHIP_COLORS.NEUTRAL,
    },
};

export enum WSO_PARTY_ITEM_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
    FINISHED = 'FINISHED',
    CLOSED = 'CLOSED',
}

export const WSO_PARTY_ITEM_STATUS_MAP = {
    [WSO_PARTY_ITEM_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [WSO_PARTY_ITEM_STATUS.FINISHED]: { text: 'Исполнен', color: CHIP_COLORS.DISABLED },
    [WSO_PARTY_ITEM_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
    [WSO_PARTY_ITEM_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
};

export enum CALC_TASK_WSO_STAGE {
    DISTRIBUTE_ORDERS = 'DISTRIBUTE_ORDERS',
    ASSIGN_PRIORITIES = 'ASSIGN_PRIORITIES',
    SUPPLY_FOR_ITEM = 'SUPPLY_FOR_ITEM',
    SELECTION_FOR_SALES_PLAN = 'SELECTION_FOR_SALES_PLAN',
}

export const CALC_TASK_WSO_STAGE_MAP = {
    [CALC_TASK_WSO_STAGE.DISTRIBUTE_ORDERS]: {
        text: 'Распределение заказов',
    },
    [CALC_TASK_WSO_STAGE.ASSIGN_PRIORITIES]: {
        text: 'Присвоение приоритетов',
    },
    [CALC_TASK_WSO_STAGE.SUPPLY_FOR_ITEM]: {
        text: 'Подбор обеспечения',
    },
    [CALC_TASK_WSO_STAGE.SELECTION_FOR_SALES_PLAN]: {
        text: 'Подбор под план продаж',
    },
};

export enum WSO_ADJUSTMENT_REASON_TYPE {
    CHANGE_IN_SHIPPING_PLAN = 'CHANGE_IN_SHIPPING_PLAN',
    CHANGE_IN_ORDER_STATUSES = 'CHANGE_IN_ORDER_STATUSES',
    OTHER_CHANGES = 'OTHER_CHANGES',
}

export const WSO_ADJUSTMENT_REASON_TYPE_MAP = {
    [WSO_ADJUSTMENT_REASON_TYPE.CHANGE_IN_SHIPPING_PLAN]: {
        text: 'Значимое изменение плана отгрузки на планируемый период',
    },
    [WSO_ADJUSTMENT_REASON_TYPE.CHANGE_IN_ORDER_STATUSES]: {
        text: 'Значимое изменение статусов неотгруженных заказов покупателей',
    },
    [WSO_ADJUSTMENT_REASON_TYPE.OTHER_CHANGES]: { text: 'Прочие значимые изменения' },
};
