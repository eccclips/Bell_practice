import React, { useEffect, useMemo, useState } from 'react';

import { Button, Drawer, IconButton, SvgIcon, Tab, Tabs } from '@mui/material';
import { useForm } from 'react-hook-form';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { TableProps } from '../../types';
import { TableFiltersForm } from './filter-form';
import { TableSavedFilters } from './saved-filters';
import { getDefaultValues } from './utils';

import styles from './TableFilters.module.scss';

type TableFiltersProps<Data> = Pick<
    TableProps<Data>,
    | 'filters'
    | 'filterValues'
    | 'allowResetFiltersToDefault'
    | 'onFiltersChange'
    | 'onFiltersReset'
    | 'savedFilters'
>;

const TableFilters = <Data,>(props: TableFiltersProps<Data>) => {
    const {
        filters,
        filterValues,
        allowResetFiltersToDefault,
        onFiltersChange,
        onFiltersReset,
        savedFilters,
    } = props;

    const [opened, setOpened] = useState(false);

    const [currentTab, setCurrentTab] = useState<'filters' | 'saved-filters'>('filters');

    const defaultValues: Record<string, any> = useMemo(
        () => filterValues || getDefaultValues(filters),
        [filterValues]
    );

    const { control, setValue, handleSubmit, formState, trigger, reset, getValues } = useForm({
        defaultValues,
        shouldFocusError: true,
        reValidateMode: 'onChange',
    });

    const onSubmit = (data) => {
        onFiltersChange?.(data);
        setOpened(false);
    };

    const handleTabChange = (e: any, value: any) => {
        setCurrentTab(value);
    };

    const handleOpen = () => {
        setOpened(true);
    };

    const handleClose = () => {
        setOpened(false);
        reset(defaultValues);
    };

    const handleResetFilters = () => {
        onFiltersReset?.(false);
        handleClose();
    };

    const handleResetFiltersToDefault = () => {
        onFiltersReset?.(true);
        handleClose();
    };

    const handleTransitionEnd = () => {
        setCurrentTab('filters');
    };

    useEffect(() => {
        reset({ ...getDefaultValues(filters), ...defaultValues });
    }, [filterValues]);

    return (
        <>
            <Button
                startIcon={
                    <SvgIcon>
                        <Icons.Filters />
                    </SvgIcon>
                }
                variant="outlined"
                color="secondary"
                size="small"
                onClick={handleOpen}
            >
                Фильтры
            </Button>

            <Drawer
                anchor="right"
                open={opened}
                PaperProps={{ className: styles.paper }}
                onClose={handleClose}
                onTransitionExited={handleTransitionEnd}
            >
                <form className={styles.container} onSubmit={handleSubmit(onSubmit)}>
                    <div className={styles.container__header}>
                        <h3>Фильтры</h3>
                        <IconButton onClick={handleClose}>
                            <SvgIcon>
                                <Icons.Close />
                            </SvgIcon>
                        </IconButton>
                    </div>
                    {savedFilters && (
                        <div className={styles.container__header}>
                            <Tabs
                                value={currentTab}
                                onChange={handleTabChange}
                                variant="scrollable"
                                scrollButtons="auto"
                                aria-label="nav tabs"
                                className={styles.container__tabs}
                            >
                                <Tab label="ВЫБОР ФИЛЬТРОВ" value="filters" />
                                <Tab label="СОХРАНЕННЫЕ ФИЛЬТРЫ" value="saved-filters" />
                            </Tabs>
                        </div>
                    )}

                    {(currentTab === 'filters' || !savedFilters) && (
                        <TableFiltersForm
                            filters={filters}
                            control={control}
                            formState={formState}
                            setValue={setValue}
                            trigger={trigger}
                            allowResetFiltersToDefault={allowResetFiltersToDefault}
                            onResetFilters={handleResetFilters}
                            onResetFiltersToDefault={handleResetFiltersToDefault}
                            savedFilters={savedFilters}
                            getValues={getValues}
                            setOpenedFilterModal={setOpened}
                            hasFilters={formState.isDirty || !!filterValues}
                        />
                    )}

                    {currentTab === 'saved-filters' && savedFilters && (
                        <TableSavedFilters
                            savedFilters={savedFilters}
                            setOpenedFilterModal={setOpened}
                        />
                    )}
                </form>
            </Drawer>
        </>
    );
};

export default typedMemo(TableFilters);
