import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const UserMFE = React.lazy(() => loadModule(process.env.MFE_USER_HOST, './User'));

export function UserRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <UserMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
