import { atomFamily, useRecoilState } from 'recoil';

import { SearchParams } from 'root-front/components';
import { localStorageEffect } from 'root-front/utils';

import { TableSettings } from '../types/table-settings';

export const tableSettingsState = atomFamily<TableSettings, string>({
    key: '@root/tableSettings',
    default: null,
    effects: (tableName) => [localStorageEffect(`tableSettings@${tableName}`)],
});

export const useTableSettingsState = (tableName: string) => {
    return useRecoilState(tableSettingsState(tableName));
};

export type TableFiltersState = {
    filters: Record<string, any>;
    isDefault?: boolean;
    appliedFilter?: {
        uid: string;
        name: string;
    };
};

export const tableFiltersState = atomFamily<TableFiltersState, string>({
    key: '@root/tableFilters',
    default: { filters: null, isDefault: true, appliedFilter: null },
});

export const useTableFiltersState = (tableName: string) => {
    return useRecoilState(tableFiltersState(tableName));
};

export const tableParamsState = atomFamily<SearchParams, string>({
    key: '@root/tableParams',
    default: null,
});

export const useTableParamsState = (tableName: string) => {
    return useRecoilState(tableParamsState(tableName));
};
