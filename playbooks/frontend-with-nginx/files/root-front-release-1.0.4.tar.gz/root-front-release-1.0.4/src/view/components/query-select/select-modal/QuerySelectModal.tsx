import React, { useCallback, useEffect, useMemo, useState } from 'react';

import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    SvgIcon,
    TextField,
} from '@mui/material';
import cn from 'classnames';
import debounce from 'lodash/debounce';

import { Icons } from 'root-front/icons';
import { LAYOUT, useLayoutState } from 'root-front/store';
import { typedMemo, useEvent } from 'root-front/utils';

import { LoadingButton } from '../../loading-button';
import { QueryTable } from '../../query-table';
import { QuerySelectModalProps, SELECT_MODE } from './types';

import styles from './QuerySelectModal.module.scss';

const QuerySelectModal = <Data, QueryParams, Multiple extends boolean = false>(
    props: QuerySelectModalProps<Data, QueryParams, Multiple>
) => {
    const {
        opened,
        value,
        name,
        title,
        query,
        multiple,
        columns,
        queryParams,
        defaultParams,
        slots,
        pageable = true,
        dataKey = 'id',
        searchable = true,
        searchPlaceholder = 'Поиск',
        mode = SELECT_MODE.SELECT,
        isSubmitting,
        isSubmitDisabled,
        onClose,
        onChange,
        onExited,
        getRowSelectionDisabled,
        modalPaperClassName,
    } = props;

    const layout = useLayoutState();

    const isFullscreen = layout === LAYOUT.MOBILE;

    const [selectedRows, setSelectedRows] = useState<Data[]>([]);

    const [searchText, setSearchText] = useState('');
    const [searchTextDebounce, setSearchTextDebounce] = useState('');

    const setDebounced = useCallback(
        debounce((value: string) => setSearchTextDebounce(value), 500, {
            maxWait: 1000,
        }),
        []
    );

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setDebounced(e.target.value);
        setSearchText(e.target.value);
    };

    const handleInputClear = () => {
        setSearchText('');
        setSearchTextDebounce('');
    };

    const params = useMemo(
        () =>
            ({
                ...(queryParams || {}),
                ...(searchable ? { search: searchTextDebounce } : {}),
            }) as QueryParams,
        [queryParams, searchTextDebounce, searchable]
    );

    const handleSelectedRowsChange = useCallback(
        (rows: Data[]) => {
            setSelectedRows(rows);
        },
        [dataKey]
    );

    const handleChange = useCallback(
        (row: Data) => {
            onChange(row as Multiple extends true ? Data[] : Data);
        },
        [onChange]
    );

    const handleChangeMultiple = () => {
        if (multiple) {
            onChange(selectedRows as Multiple extends true ? Data[] : Data);
        }
    };

    const getRowHighlight = useCallback(
        (row: Data) => {
            return row?.[dataKey] === value?.[dataKey];
        },
        [value, dataKey]
    );

    const getSelectionDisabled = useCallback(
        (row: Data) => {
            if (getRowSelectionDisabled) {
                return getRowSelectionDisabled(row);
            }

            return !!(value as Data[]).find((item) => item[dataKey] === row[dataKey]);
        },
        [value, getRowSelectionDisabled]
    );

    const handleClose = () => {
        onClose();
    };

    const handleExited = useEvent(() => {
        if (multiple) {
            setSelectedRows([...(value as Data[])]);
        }
        setSearchText('');
        setSearchTextDebounce('');
        onExited?.();
    });

    useEffect(() => {
        if (multiple) {
            setSelectedRows([...(value as Data[])]);
        }
    }, [value, multiple]);

    const isSubmitMultipleDisabled =
        (mode === SELECT_MODE.APPEND
            ? selectedRows.length <= (value as Data[])?.length
            : !selectedRows.length) && isSubmitDisabled;

    const submitMultipleText =
        mode === SELECT_MODE.APPEND
            ? `Добавить${
                  isSubmitMultipleDisabled || !selectedRows.length
                      ? ''
                      : ` (${selectedRows.length - (value as Data[]).length})`
              }`
            : 'Выбрать';

    const tableSlots = useMemo(() => ({ settingsStart: slots?.settingsStart }), [slots]);

    return (
        <Dialog
            maxWidth="xl"
            fullWidth
            fullScreen={isFullscreen}
            open={opened}
            PaperProps={{
                className: cn(styles.modal, modalPaperClassName),
            }}
            onClose={onClose}
            TransitionProps={{ onExited: handleExited }}
        >
            {title && <DialogTitle>{title}</DialogTitle>}
            <DialogContent className={styles.modal__content}>
                {slots?.filterBlock}
                {!slots?.filterBlock && (searchable || slots?.filters) && (
                    <div className={styles.modal__filters}>
                        {searchable && (
                            <TextField
                                size="small"
                                placeholder={searchPlaceholder}
                                value={searchText}
                                onChange={handleInputChange}
                                InputProps={{
                                    endAdornment: searchText && (
                                        <IconButton size="small" onClick={handleInputClear}>
                                            <SvgIcon fontSize="small">
                                                <Icons.Close />
                                            </SvgIcon>
                                        </IconButton>
                                    ),
                                }}
                            />
                        )}
                        {slots?.filters}
                    </div>
                )}
                <div className={styles.modal__table}>
                    <QueryTable
                        name={name}
                        query={query}
                        columns={columns}
                        defaultParams={defaultParams}
                        viewMode="inner-scroll"
                        allowColumnSettings={false}
                        saveParamsInURI={false}
                        checkboxSelection={multiple}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={handleSelectedRowsChange}
                        onRowClick={!multiple ? handleChange : null}
                        getRowSelectionDisabled={
                            multiple && mode === SELECT_MODE.APPEND ? getSelectionDisabled : null
                        }
                        slots={tableSlots}
                        getRowHighlight={!multiple ? getRowHighlight : null}
                        queryParams={params}
                        dataKey={dataKey}
                        pageable={pageable}
                    />
                </div>
            </DialogContent>
            <DialogActions>
                <Button type="button" variant="outlined" color="secondary" onClick={handleClose}>
                    Отмена
                </Button>
                {multiple && (
                    <LoadingButton
                        type="button"
                        variant="contained"
                        onClick={handleChangeMultiple}
                        disabled={isSubmitMultipleDisabled}
                        isLoading={isSubmitting}
                    >
                        {submitMultipleText}
                    </LoadingButton>
                )}
            </DialogActions>
        </Dialog>
    );
};

export default typedMemo(QuerySelectModal);
