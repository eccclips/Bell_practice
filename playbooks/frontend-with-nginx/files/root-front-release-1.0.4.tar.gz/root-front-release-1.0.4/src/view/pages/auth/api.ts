import { useMutation, UseMutationOptions } from '@tanstack/react-query';
import { AxiosError } from 'axios';

import { api } from 'root-front/api';
import { MS_USER_URL } from 'root-front/dictionaries';

import { AuthDataDTO, ResponseDTO, ResponseErrorDTO } from '../../../interfaces/api';
import { LoginDTO } from './interfaces';

export const useLoginMutation = (
    config: UseMutationOptions<ResponseDTO<AuthDataDTO>, AxiosError<ResponseErrorDTO>, LoginDTO>
) => {
    return useMutation({
        mutationKey: ['@root/login'],
        mutationFn: async (data) => {
            const result = await api.post<ResponseDTO<AuthDataDTO>>(
                `${MS_USER_URL}/auth/login`,
                data
            );

            return result.data;
        },
        ...config,
    });
};
