/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const Dotenv = require('dotenv-webpack');
const webpack = require('webpack');

require('dotenv').config();

const { ModuleFederationPlugin } = webpack.container;

const deps = require('./package.json').dependencies;

const isProduction = process.env.NODE_ENV === 'production';

function getProxyConfig() {
    const json = fs.readFileSync('./proxy.json');
    return JSON.parse(json);
}

module.exports = {
    entry: './src/index',
    mode: isProduction ? 'production' : 'development',
    target: process.env.NODE_ENV === 'development' ? 'web' : 'browserslist',
    devtool: isProduction ? 'source-map' : 'eval',
    devServer: {
        port: 8000,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
            'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization',
        },
        ...(process.env.PROXY ? { proxy: getProxyConfig() } : {}),
        historyApiFallback: true,
        liveReload: true,
        allowedHosts: 'all',
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'assets/js/[name].[chunkhash].js',
        publicPath: '/',
        crossOriginLoading: 'anonymous',
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.jsx'],
        alias: {
            public: path.resolve(__dirname, 'public/'),
            src: path.resolve('src/'),
        },
    },
    module: {
        rules: [
            {
                test: /\.m?js/,
                resolve: {
                    fullySpecified: false,
                },
            },
            {
                test: /\.tsx?$/,
                loader: 'ts-loader',
            },
            {
                test: /\.(png|jpe?g|gif)$/i,
                type: 'asset/resource',
                generator: {
                    filename: 'assets/images/[name]-[hash].[ext]',
                },
            },
            {
                test: /\.svg$/i,
                type: 'asset/resource',
                resourceQuery: /url/,
            },
            {
                test: /\.svg$/i,
                issuer: /\.[jt]sx?$/,
                resourceQuery: { not: [/url/] },
                use: ['@svgr/webpack'],
            },
            {
                test: /\.(woff|woff2|eot|ttf|otf)$/i,
                type: 'asset/resource',
                generator: {
                    filename: 'assets/fonts/[hash][ext][query]',
                },
            },
            {
                test: /\.scss|\.css$/,
                use: [
                    {
                        loader: 'style-loader',
                    },
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                auto: /\.module\.\w+$/i,
                                localIdentName: isProduction
                                    ? '[hash:base64]'
                                    : '[local]__[name]--[hash:base64:5]',
                            },
                            sourceMap: !isProduction,
                        },
                    },
                    {
                        loader: 'sass-loader',
                        options: {
                            sourceMap: !isProduction,
                        },
                    },
                ],
            },
        ],
    },
    plugins: [
        new ModuleFederationPlugin({
            name: 'root_front',
            filename: 'remoteEntry.js',
            exposes: {
                './store': './src/store',
                './api': './src/api',
                './utils': './src/utils',
                './components': './src/view/components',
                './types': './src/types/index.ts',
                './styles': './src/styles/index.ts',
                './icons': './src/view/icons',
                './interfaces': './src/interfaces/index.ts',
                './constants': './src/constants/index.ts',
                './dictionaries': './src/dictionaries/index.ts',
            },
            remotes: {
                'root-front': process.env.ROOT_FRONT_HOST,
            },
            shared: {
                ...Object.entries(deps).reduce((acc, [name, value]) => {
                    acc[name] = { singleton: true, requiredVersion: value };
                    return acc;
                }, {}),
                'react/jsx-runtime': { singleton: true, requiredVersion: deps['react'] },
            },
        }),
        new ForkTsCheckerWebpackPlugin({
            // Отключает ошибки, связанные с импортом из других MFE
            ...(isProduction
                ? {
                      issue: {
                          exclude: [
                              {
                                  code: 'TS2307',
                                  severity: 'error',
                              },
                              {
                                  code: 'TS2305',
                                  severity: 'error',
                              },
                          ],
                      },
                  }
                : {}),
        }),
        new HtmlWebpackPlugin({
            template: './public/index.html',
            manifest: 'public/manifest.json',
        }),
        new CopyWebpackPlugin({
            patterns: [
                { from: 'public/favicons/*', to: '[name][ext]' },
                { from: 'public/*.jpeg', to: '[name][ext]' },
            ],
        }),
        new Dotenv({
            allowEmptyValues: true,
            systemvars: true,
            path: './.env',
        }),
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV),
        }),
    ].filter(Boolean),
};
