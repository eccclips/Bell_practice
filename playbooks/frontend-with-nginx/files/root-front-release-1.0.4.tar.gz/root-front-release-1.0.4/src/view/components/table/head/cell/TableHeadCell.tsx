import React, { DragEvent, useCallback, useEffect, useRef } from 'react';

import { TableSortLabel } from '@mui/material';
import cn from 'classnames';

import { SortInstructionDTO } from 'root-front/interfaces';
import { typedMemo } from 'root-front/utils';

import { TableColumn, TableData } from '../../types';

import styles from './TableHeadCell.module.scss';

type TableHeadCellProps<Data = any> = {
    sort: SortInstructionDTO;
    column: TableColumn<TableData<Data>>;
    isSortable: boolean;
    isDefaultColumnsWidth: boolean;
    colSpan?: number;
    rowSpan?: number;
    isGroup?: boolean;
    getSortDirection: (key: string) => 'asc' | 'desc';
    createSortHandler: (key: string) => () => void;
    onColumnResize?: (key: string, width: number) => void;
};

const TableHeadCell = <Data,>(props: TableHeadCellProps<Data>) => {
    const {
        column,
        sort,
        isSortable,
        isDefaultColumnsWidth,
        colSpan,
        rowSpan,
        isGroup = false,
        getSortDirection,
        createSortHandler,
        onColumnResize,
    } = props;

    const headCellRef = useRef<HTMLTableCellElement>(null);
    const drag = useRef<{ mouse: number; size: number } | null>();

    const { sortable = true, resizable = true } = column;
    const isSortableCell = isSortable && sortable;

    useEffect(() => {
        const { width } = headCellRef.current.getBoundingClientRect();
        const initialWidth = column.resizeWidth || column.initialWidth || Math.ceil(width);

        if (!isGroup) {
            headCellRef.current.style.width = `${initialWidth}px`;
        } else {
            headCellRef.current.style.width = 'auto';
        }
        headCellRef.current.style.minWidth = column.minWidth ? `${column.minWidth}px` : undefined;
    }, []);

    const handleResetWidth = useCallback(() => {
        headCellRef.current.style.width = 'auto';

        requestAnimationFrame(() => {
            if (!headCellRef.current) {
                return;
            }
            const { width } = headCellRef.current.getBoundingClientRect();
            const initialWidth = column.initialWidth || Math.ceil(width);

            if (!isGroup) {
                headCellRef.current.style.width = `${initialWidth}px`;
            } else {
                headCellRef.current.style.width = 'auto';
            }
            headCellRef.current.style.minWidth = column.minWidth
                ? `${column.minWidth}px`
                : undefined;
        });
    }, []);

    useEffect(() => {
        if (isDefaultColumnsWidth && resizable) {
            handleResetWidth();
        }
    }, [isDefaultColumnsWidth, resizable]);

    const handleDrag = useCallback((event: MouseEvent | TouchEvent) => {
        const clientX =
            event.type === 'mousemove'
                ? (event as MouseEvent).clientX
                : (event as TouchEvent).touches[0].clientX;
        if (drag && clientX > 0) {
            const initMouse = drag.current.mouse;
            const initSize = drag.current.size;
            const endMouse = clientX;
            const endSize = initSize + (endMouse - initMouse);

            headCellRef.current.style.width = `${endSize}px`;
        }
    }, []);

    const handleMouseDown = useCallback(
        (event: DragEvent<HTMLDivElement>) => {
            const initMouse = event.clientX;
            const initSize = headCellRef.current?.getBoundingClientRect().width;

            drag.current = {
                mouse: initMouse,
                size: initSize,
            };

            document.addEventListener('mousemove', handleDrag);
            document.addEventListener(
                'mouseup',
                () => {
                    document.removeEventListener('mousemove', handleDrag);
                    onColumnResize?.(column.key, headCellRef.current.getBoundingClientRect().width);

                    drag.current = null;
                },
                { once: true }
            );
        },
        [handleDrag, onColumnResize]
    );

    const handleTouchStart = useCallback(
        (event: React.TouchEvent<HTMLDivElement>) => {
            const initMouse = event.touches[0].clientX;
            const initSize = headCellRef.current?.getBoundingClientRect().width;

            drag.current = {
                mouse: initMouse,
                size: initSize,
            };

            document.addEventListener('touchmove', handleDrag);
            document.addEventListener(
                'touchend',
                () => {
                    document.removeEventListener('touchmove', handleDrag);
                    onColumnResize?.(column.key, headCellRef.current.getBoundingClientRect().width);

                    drag.current = null;
                },
                { once: true }
            );
        },
        [handleDrag, onColumnResize]
    );

    return (
        <th
            ref={headCellRef}
            key={column.key}
            style={{
                textAlign: !isGroup ? column.align || 'left' : 'center',
                maxWidth: !isGroup && column.maxWidth ? `${column.maxWidth}px` : 'none',
                minWidth: !isGroup && column.minWidth ? `${column.minWidth}px` : 'max-content',
            }}
            className={styles.headCell}
            colSpan={colSpan}
            rowSpan={rowSpan}
        >
            <div className={cn(styles.cell, isGroup && styles.cell__group)}>
                {isSortableCell && !isGroup ? (
                    <TableSortLabel
                        active={sort?.field === column.key}
                        direction={getSortDirection(column.key)}
                        onClick={createSortHandler(column.key)}
                        className={styles.sort}
                    >
                        <span className={styles.sort__text}>{column.name}</span>
                    </TableSortLabel>
                ) : (
                    column.name
                )}
            </div>
            {resizable && !isGroup && (
                <div
                    className={styles.dragger}
                    onMouseDown={handleMouseDown}
                    onTouchStart={handleTouchStart}
                    onDoubleClick={handleResetWidth}
                />
            )}
        </th>
    );
};

export default typedMemo(TableHeadCell);
