import React from 'react';

import cn from 'classnames';

import { LinkIconButton } from 'root-front/components';
import { Icons } from 'root-front/icons';
import { useIsMenuExpanded } from 'root-front/store';

import { useUnreadNotificationsCount } from '../../api/notifications';
import { NavItem } from '../../components/nav-item';

import styles from './Notifications.module.scss';

type NotificationsProps = {
    mode: 'desktop' | 'mobile';
};

const Notifications = (props: NotificationsProps) => {
    const { mode } = props;

    const [isExpanded] = useIsMenuExpanded();
    const { data } = useUnreadNotificationsCount();

    const count = data?.data?.count;

    const hasUnreadNotifications = !!count;

    if (mode === 'desktop') {
        return (
            <div className={styles.notifications}>
                <NavItem
                    text="Уведомления"
                    type="link"
                    to="/notifications"
                    Icon={Icons.Notifications}
                    hideRightIcon
                    inner
                    className={styles.button}
                >
                    {hasUnreadNotifications && (
                        <div className={cn(styles.badge, !isExpanded && styles.badge_collapsed)}>
                            {count}
                        </div>
                    )}
                </NavItem>
            </div>
        );
    }

    if (mode === 'mobile') {
        return (
            <LinkIconButton to="/notifications">
                {hasUnreadNotifications && (
                    <div className={cn(styles.badge, styles.badge_collapsed, styles.badge_mobile)}>
                        {count}
                    </div>
                )}
                <Icons.Notifications />
            </LinkIconButton>
        );
    }

    return null;
};

export default React.memo(Notifications);
