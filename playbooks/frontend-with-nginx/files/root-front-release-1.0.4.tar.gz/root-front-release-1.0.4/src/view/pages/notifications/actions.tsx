import React, { useMemo, useState } from 'react';

import { useSearchParams } from 'react-router-dom';

import { BASE_STATUS, NotificationDTO } from 'root-front/dictionaries';
import { Icons } from 'root-front/icons';
import { useEvent } from 'root-front/utils';

import { useChangeNotificationStatus, useDeleteNotifications, useMarkNotifications } from './api';
import { FILTER_TABS, MARK_NOTIFICATION_ACTION, NotificationAction, TABS } from './constants';

export const useActions = () => {
    const [searchParams, setSearchParams] = useSearchParams();

    const [selected, setSelected] = useState<NotificationDTO[]>([]);

    const [filterTab, setFilterTab] = useState(FILTER_TABS.ALL);

    const currentTab = useMemo(() => {
        const value = searchParams.get('tab');
        return TABS[value?.toUpperCase?.()] || TABS.INBOX;
    }, [searchParams]);

    const [searchText, setSearchText] = useState('');

    const openNotificationId = useMemo(() => {
        const value = searchParams.get('notificationId');

        if (!value || Number.isNaN(+value)) {
            return null;
        }

        return +value;
    }, [searchParams]);

    const isOpen = typeof openNotificationId === 'number';

    const openNotification = useEvent((id: number) => {
        setSearchParams((prevSearchParams) => {
            const nextSearchParams = new URLSearchParams(prevSearchParams.toString());
            nextSearchParams.set('notificationId', id.toString());

            return nextSearchParams;
        });
    });

    const setTab = useEvent((tab: TABS) => {
        setSelected([]);
        setFilterTab(FILTER_TABS.ALL);
        setSearchParams((prevSearchParams) => {
            const nextSearchParams = new URLSearchParams(prevSearchParams.toString());
            nextSearchParams.set('tab', tab);

            return nextSearchParams;
        });
    });

    const { mutate: markNotifications } = useMarkNotifications();

    const { mutate: deleteNotifications } = useDeleteNotifications();

    const { mutate: changeNotificationsStatus } = useChangeNotificationStatus();

    const handleMarkAsRead = useEvent(() => {
        markNotifications({
            ids: selected.map(({ id }) => id),
            action: MARK_NOTIFICATION_ACTION.READ,
            tab: currentTab,
            filterTab,
            search: searchText,
        });

        setSelected([]);
    });

    const handleMarkAsUnread = useEvent(() => {
        markNotifications({
            ids: selected.map(({ id }) => id),
            action: MARK_NOTIFICATION_ACTION.UNREAD,
            tab: currentTab,
            filterTab,
            search: searchText,
        });

        setSelected([]);
    });

    const handleReadCurrentNotification = useEvent(() => {
        markNotifications({
            ids: [openNotificationId],
            action: MARK_NOTIFICATION_ACTION.READ,
            tab: currentTab,
            filterTab,
            search: searchText,
        });
    });

    const handleDeleteNotifications = useEvent(() => {
        deleteNotifications({
            ids: selected.map(({ id }) => id),
            action: MARK_NOTIFICATION_ACTION.UNREAD,
            tab: currentTab,
        });

        setSelected([]);
    });

    const handleSendToArchive = useEvent(() => {
        changeNotificationsStatus({
            ids: selected.map(({ id }) => id),
            status: BASE_STATUS.CLOSED,
        });

        setSelected([]);
    });

    const handleRemoveFromArchive = useEvent(() => {
        changeNotificationsStatus({
            ids: selected.map(({ id }) => id),
            status: BASE_STATUS.ACTIVE,
        });

        setSelected([]);
    });

    const actions = useMemo<NotificationAction[]>(() => {
        const result: NotificationAction[] = [];

        if (selected.some((notification) => !notification.isRead)) {
            result.push({
                title: 'Отметить как прочитанные',
                icon: <Icons.ReadMail />,
                onAction: handleMarkAsRead,
            });
        } else {
            result.push({
                title: 'Отметить как непрочитанные',
                icon: <Icons.UnreadMail />,
                onAction: handleMarkAsUnread,
            });
        }

        if (currentTab === TABS.INBOX) {
            result.push({
                title: 'Отправить в архив',
                icon: <Icons.Archive />,
                onAction: handleSendToArchive,
            });
        } else {
            result.push(
                {
                    title: 'Вернуть из архива',
                    icon: <Icons.Unarchive />,
                    onAction: handleRemoveFromArchive,
                },
                {
                    title: 'Удалить',
                    icon: <Icons.Trash />,
                    onAction: handleDeleteNotifications,
                }
            );
        }

        return result;
    }, [selected, currentTab]);

    return {
        selected,
        currentTab,
        setTab,
        setSelected,
        searchText,
        setSearchText,
        filterTab,
        setFilterTab,
        handleMarkAsRead,
        handleMarkAsUnread,
        handleDeleteNotifications,
        handleReadCurrentNotification,
        actions,
        openNotification,
        openNotificationId,
        isOpen,
    };
};
