import { DateView } from '@mui/x-date-pickers';
import dayjs from 'dayjs';

import { TableFilter } from 'root-front/components';

export const clearObject = (obj: Record<string, any>) => {
    const newObj = {};

    Object.entries(obj).forEach(([key, value]) => {
        if (Array.isArray(value)) {
            if (value.length) {
                newObj[key] = value;
            }
            return;
        }

        if (value !== null && typeof value === 'object') {
            const nestedObject = clearObject(value);
            if (nestedObject) {
                newObj[key] = nestedObject;
            }
            return;
        }

        if (value !== null && value !== undefined && value !== '') {
            newObj[key] = value;
            return;
        }
    });

    if (Object.keys(newObj).length === 0) {
        return null;
    }

    return newObj;
};

export const getDateFromFilterValue = (value: string, datePickerView: DateView) => {
    if (!value) {
        return null;
    }

    return dayjs(value)
        .startOf(datePickerView || 'day')
        .format();
};

export const getDateToFilterValue = (value: string, datePickerView: DateView) => {
    if (!value) {
        return null;
    }

    return dayjs(value)
        .endOf(datePickerView || 'day')
        .format();
};

export const getFilterValuesForRequest = (
    filterValues: Record<string, any>,
    filters: TableFilter[]
) => {
    if (!filterValues) {
        return null;
    }

    const requestFilters = { ...filterValues };

    // Превращаем dayjs объект в объект вида { from: '2023-09-29T00:00:00', to: '2023-09-29T23:59:59' }
    filters.forEach((filter) => {
        if (filter.type === 'date' && requestFilters[filter.name]) {
            requestFilters[filter.name] = {
                from: getDateFromFilterValue(requestFilters[filter.name], filter.datePickerView),
                to: getDateToFilterValue(requestFilters[filter.name], filter.datePickerView),
            };
        }

        if (filter.type === 'date-range') {
            if (!requestFilters[filter.name]?.from && !requestFilters[filter.name]?.to) {
                return (requestFilters[filter.name] = null);
            }

            requestFilters[filter.name] = {
                from: getDateFromFilterValue(
                    requestFilters[filter.name].from,
                    filter.datePickerView
                ),
                to: getDateToFilterValue(requestFilters[filter.name].to, filter.datePickerView),
            };
        }
    });

    // Применяем getRequestFilter
    const filtersWithGetRequestFilter = filters.filter((filter) => !!filter.getRequestFilter);

    filtersWithGetRequestFilter.forEach(({ name, getRequestFilter }) => {
        const value = requestFilters[name];
        if (
            value === null ||
            value === undefined ||
            value === '' ||
            (Array.isArray(value) && !value.length)
        ) {
            return;
        }

        requestFilters[name] = getRequestFilter(value);
    });

    // Очищаем объект
    return clearObject(requestFilters);
};
