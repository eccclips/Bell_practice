import React from 'react';

import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { RecoilRoot } from 'recoil';

import 'dayjs/locale/ru';

import { AuthRoute, PrivateRoute, ROUTES } from './routes';
import { Layout } from './view/pages/layout';
import { QueryClientProvider, SnackbarProvider, ThemeProvider } from './view/providers';

import './styles.scss';

import { DocumentHistoryEffect, SessionTimeoutEffect } from './view/effects';

export const App = () => {
    return (
        <RecoilRoot>
            <ThemeProvider>
                <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="ru">
                    <SnackbarProvider>
                        <QueryClientProvider>
                            <BrowserRouter>
                                <DocumentHistoryEffect />
                                <SessionTimeoutEffect />
                                <Routes>
                                    <Route path="/auth" element={<AuthRoute />} />
                                    <Route element={<PrivateRoute />}>
                                        <Route path="*" element={<Layout />}>
                                            {ROUTES}
                                        </Route>
                                    </Route>
                                </Routes>
                            </BrowserRouter>
                        </QueryClientProvider>
                    </SnackbarProvider>
                </LocalizationProvider>
            </ThemeProvider>
        </RecoilRoot>
    );
};
