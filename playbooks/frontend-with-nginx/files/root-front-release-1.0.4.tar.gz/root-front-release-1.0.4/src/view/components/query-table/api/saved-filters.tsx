import { useMutation, UseMutationOptions, useQuery, useQueryClient } from '@tanstack/react-query';

import { UsersDTO } from 'root-front/dictionaries';
import { randomUUID } from 'root-front/utils';

import { SavedFilter } from '../../table';

export const useSavedFilters = (tableName: string) => {
    return useQuery({
        queryKey: ['@root/savedFilters', tableName],
        queryFn: async () => {
            const result = await new Promise<SavedFilter[]>((resolve) =>
                setTimeout(() => {
                    const savedFilters = localStorage.getItem(`savedFilters@${tableName}}`);
                    resolve((savedFilters ? JSON.parse(savedFilters) : []) as SavedFilter[]);
                }, 200)
            );

            return result;
        },
    });
};

export const getUseUserSavedFilters = (tableName: string) => {
    return (user: UsersDTO) => {
        return useQuery({
            queryKey: ['@root/savedFilters', tableName, user],
            queryFn: async () => {
                const result = await new Promise<SavedFilter[]>((resolve) =>
                    setTimeout(() => {
                        resolve(
                            Array.from({ length: 10 }).map((_, index) => ({
                                ...testFilter,
                                uid: randomUUID(),
                                name: `Фильтр пользователя ${user.fio} ${index + 1}`,
                            })) as SavedFilter[]
                        );
                    }, 200)
                );

                return result;
            },
            enabled: !!user,
        });
    };
};

export const getUseSaveFilterMutation = (tableName: string) => {
    return (config: UseMutationOptions<SavedFilter[], any, { filter: SavedFilter }> = {}) => {
        const queryClient = useQueryClient();
        return useMutation({
            mutationKey: ['@root/saveFilter', tableName],
            mutationFn: async ({ filter }) => {
                const savedFilters = localStorage.getItem(`savedFilters@${tableName}}`);
                const newSavedFilters = savedFilters
                    ? [filter, ...JSON.parse(savedFilters)]
                    : [filter];

                return await new Promise<SavedFilter[]>((resolve) =>
                    setTimeout(() => {
                        localStorage.setItem(
                            `savedFilters@${tableName}}`,
                            JSON.stringify(newSavedFilters)
                        );
                        resolve(newSavedFilters);
                    }, 200)
                );
            },
            ...config,
            onSettled: (...args) => {
                config.onSettled?.(...args);
                queryClient.invalidateQueries(['@root/savedFilters', tableName]);
            },
        });
    };
};

export const getUseDeleteFilterMutation = (tableName: string) => {
    return (config: UseMutationOptions<SavedFilter[], any, { filterUid: string }> = {}) => {
        const queryClient = useQueryClient();

        return useMutation({
            mutationKey: ['@root/saveFilter', tableName],
            mutationFn: async ({ filterUid }) => {
                const savedFilters = localStorage.getItem(`savedFilters@${tableName}}`);
                const newSavedFilters = savedFilters
                    ? JSON.parse(savedFilters).filter(
                          (filter: SavedFilter) => filter.uid !== filterUid
                      )
                    : [];

                return await new Promise<SavedFilter[]>((resolve) =>
                    setTimeout(() => {
                        localStorage.setItem(
                            `savedFilters@${tableName}}`,
                            JSON.stringify(newSavedFilters)
                        );
                        resolve(newSavedFilters);
                    }, 200)
                );
            },
            ...config,
            onSettled: (...args) => {
                config.onSettled?.(...args);
                queryClient.invalidateQueries(['@root/savedFilters', tableName]);
            },
        });
    };
};

const testFilter: SavedFilter = {
    name: 'Фильтр тест',
    values: {
        statuses: ['ACTIVE'],
    },
    uid: 'C4NWaqxU',
};

export const getUseImportUserSavedFilters = (tableName: string) => {
    return (config: UseMutationOptions<SavedFilter[], any, { filters: SavedFilter[] }> = {}) => {
        const queryClient = useQueryClient();

        return useMutation({
            mutationKey: ['@root/importUserSavedFilters', tableName],
            mutationFn: async (data) => {
                const savedFilters = localStorage.getItem(`savedFilters@${tableName}}`);
                const newSavedFilters = savedFilters
                    ? [...data.filters, ...JSON.parse(savedFilters)]
                    : [...data.filters];

                return await new Promise<SavedFilter[]>((resolve) =>
                    setTimeout(() => {
                        localStorage.setItem(
                            `savedFilters@${tableName}}`,
                            JSON.stringify(newSavedFilters)
                        );
                        resolve(newSavedFilters);
                    }, 200)
                );
            },
            ...config,
            onSettled: (...args) => {
                config.onSettled?.(...args);
                queryClient.invalidateQueries(['@root/savedFilters', tableName]);
            },
        });
    };
};
