import { ListRequestDTO } from 'root-front/interfaces';
import { ListRequestParams } from 'root-front/types';

export const getPaginationFromRequestParams = (
    requestParams: ListRequestParams
): ListRequestDTO => {
    return {
        pageInfo: {
            page: requestParams?.page,
            size: requestParams?.size,
            sort: [
                {
                    field: requestParams?.sort?.field,
                    direction: requestParams?.sort?.direction,
                },
            ],
        },
    };
};
