import { ReactNode } from 'react';

import { CHIP_COLORS } from '../chip';

type AutoListItem<DataType> = {
    type?: 'auto';
    valueGetter?: (data: DataType) => string | number | boolean | ReactNode | undefined;
};

type ChipListItem<DataType> = {
    type: 'chip';
    chipColorGetter: (data: DataType) => CHIP_COLORS;
    valueGetter?: (data: DataType) => string;
};

type DateListItem<DataType> = {
    type: 'date';
    valueGetter?: (data: DataType) => string | number;
};

type BooleanListItem<DataType> = {
    type: 'boolean';
    valueGetter?: (data: DataType) => boolean;
};

type LinkListItem<DataType> = {
    type: 'link';
    valueGetter?: (data: DataType) => string | number | boolean | ReactNode | undefined;
    linkGetter?: (data: DataType) => string;
};

type AmountListItem<DataType> = {
    type: 'amount';
    valueGetter?: (data: DataType) => string | number | undefined;
};

type ListValueConfig<DataType> =
    | DateListItem<DataType>
    | ChipListItem<DataType>
    | AutoListItem<DataType>
    | BooleanListItem<DataType>
    | LinkListItem<DataType>
    | AmountListItem<DataType>;

export type ListItemConfig<DataType> = {
    key: string;
    label: string;
} & ListValueConfig<DataType>;

export type InfoGridConfig<DataType> = {
    title: string;
    itemsConfig: ListItemConfig<DataType>[] | ((data: DataType) => ListItemConfig<DataType>[]);
}[][];
