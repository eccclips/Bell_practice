import { DropEvent } from 'react-dropzone';

export type Format = '.png' | '.jpeg' | '.jpg' | '.xls' | '.xlsx';

export type DropzoneProps = {
    name: string;
    maxFileSize?: number | null;
    formats?: Format[];
    multiple?: boolean;
    disabled?: boolean;
    isLoading?: boolean;
    onDropAccepted?: (files: File[], event: DropEvent) => void;
};
