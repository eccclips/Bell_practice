import {
    BusinessDomainDTO,
    CALC_TASK_AVAILABILITY_REASON_TYPE,
    CALC_TASK_AVAILABILITY_STATUS,
    CALC_TASK_B2B_STATUS,
    CALC_TASK_OPT_STATUS,
    CounterpartyDTO,
    DOCUMENT_RESOURCE_WAREHOUSE_STATUS,
    OrderDTO,
    PRODUCT_ATTRIBUTE,
    ProductDTO,
    SupplyPropertyDTO,
    WarehouseDocumentDTO,
    WarehouseDTO,
    WHOLESALE_DEMAND_TYPE,
} from 'root-front/dictionaries';
import { BaseAuditedDTO } from 'root-front/interfaces';

import { Formula } from '../../view/components/math/types';
import {
    ACCESSIBLE_RESOURCE_TYPE,
    AVAILABILITY_CATEGORY_STATUS,
    AVAILABILITY_CATEGORY_TYPE,
    BASE_STATUS,
    EXTERNAL_ACCESSIBLE_RESOURCE_STATUS,
    FORMULA_TYPE,
    GUARANTEED_RESERVE_CALC_STATUS,
    GUARANTEED_RESERVE_TASK_TYPE,
    INTERNAL_ACCESSIBLE_RESOURCE_STATUS,
    PRODUCT_GROUP,
    PRODUCT_SETTINGS_OPT,
    RESOURCE_OPT_TYPE,
    RESOURCES_EXCLUDE_STATUS,
    RESOURCES_EXCLUDE_TYPE,
} from '../constants';

export interface GuaranteedReserveCalcDto extends BaseAuditedDTO {
    externalId: string;
    number: number;
    paramId: number;
    status: GUARANTEED_RESERVE_CALC_STATUS;
    responsible: string;
}

export interface GuaranteedReserveCalcResultDto extends BaseAuditedDTO {
    externalId: string;
    product: ProductDTO;
    counterparty: CounterpartyDTO;
    quantity: number;
    expertAssessmentQuantity: number;
    correctedQuantity: number;
    averageExpenseYar: number;
    averageExpenseMonth: number;
    averageWarranty: number;
    deliverySignCoef: number;
    supplierCoef: number;
    productGroupCoef: number;
}

export interface GuaranteedReserveAdjustmentDTO extends BaseAuditedDTO {
    warehouse: WarehouseDTO;
    product: ProductDTO;
    quantity: number;
    taskType: GUARANTEED_RESERVE_TASK_TYPE;
}

export interface AvailabilityCategoryDTO extends BaseAuditedDTO {
    formula: Formula;
    expectedFormula: Formula;
    name: string;
    type: AVAILABILITY_CATEGORY_TYPE;
    status: AVAILABILITY_CATEGORY_STATUS;
}

export interface DocumentResourceWarehouseDTO extends BaseAuditedDTO {
    dateStart: string;
    status: DOCUMENT_RESOURCE_WAREHOUSE_STATUS;
    comment?: string;
}

export interface ResourceCalcGroupDTO {
    id: number;
    isDeleted: boolean;
    name: string;
}

export interface ResourceWarehouseDTO extends BaseAuditedDTO {
    parentWarehouse: WarehouseDTO;
    warehouse: WarehouseDTO;
    status: BASE_STATUS;
    resourceCalcWarehouseSettings: DocumentResourceWarehouseDTO;
}

export interface SalesForecastItemDTO extends BaseAuditedDTO {
    product: ProductDTO;
    quantity: number;
}

export interface SalesForecastDTO extends BaseAuditedDTO {
    number: string;
    month: string;
    businessDomain: BusinessDomainDTO;
    warehouse: WarehouseDTO;
    lastUpdatedDate: string;
    status: BASE_STATUS;
    items: SalesForecastItemDTO[];
}

export interface CalcParamsB2BDTO extends BaseAuditedDTO {
    externalId: string;
    status: BASE_STATUS;
    comment: string;
}

export interface SupplyPropertyMiniDTO {
    id: number;
    name: string;
}

export interface SettingSupplyPropertyB2BDTO extends BaseAuditedDTO {
    externalId: string;
    calcParamsB2b: CalcParamsB2BDTO;
    supplyProperty: SupplyPropertyMiniDTO;
    calculateB2b: boolean;
    calculateB2bSelf: boolean;
}

export interface SettingProductAttributeB2BDTO extends BaseAuditedDTO {
    externalId: string;
    calcParamsB2b: CalcParamsB2BDTO;
    productAttribute: PRODUCT_ATTRIBUTE;
    calculateB2b: boolean;
    calculateB2bSelf: boolean;
}

export interface SettingForecastCoefB2bDTO extends BaseAuditedDTO {
    externalId: string;
    calcParamsB2b: CalcParamsB2BDTO;
    productGroup: PRODUCT_GROUP;
    coef: string;
}

export interface SettingFormulaCalcB2BDTO extends BaseAuditedDTO {
    calcParamsB2b: CalcParamsB2BDTO;
    formula?: Formula;
    type: FORMULA_TYPE;
    name: string;
    status: AVAILABILITY_CATEGORY_STATUS;
}

export interface CalcTaskB2BDTO extends BaseAuditedDTO {
    externalId: string;
    params: CalcParamsB2BDTO;
    responsible: string;
    hasError: boolean;
    status: CALC_TASK_B2B_STATUS;
}

export interface StockBalanceCoefDto extends BaseAuditedDTO {
    product: ProductDTO;
    coef: number;
    b2bExcluded: boolean;
    b2bExcludedSelf: boolean;
    b2bExcludedSelfImport: boolean;
    sourceCreatedDate: string;
    sourceLastModifiedDate: string;
    status: RESOURCES_EXCLUDE_STATUS;
}

export interface ResourceOptTypeDTO extends BaseAuditedDTO {
    externalId: string;
    code: RESOURCE_OPT_TYPE;
    description: string;
}

export interface SettingSupplyPropertyOptDTO extends BaseAuditedDTO {
    externalId: string;
    supplyProperty: SupplyPropertyDTO;
}

export interface SettingFormulaCalcOptTypeDTO extends BaseAuditedDTO {
    code: string;
    name: string;
    description: string;
}

export interface SettingFormulaCalcOptDTO extends BaseAuditedDTO {
    externalId: string;
    name: string;
    type: FORMULA_TYPE;
    formula: Formula;
    formulaType: SettingFormulaCalcOptTypeDTO;
}

export interface SettingCounterpartyOptDTO extends BaseAuditedDTO {
    externalId: string;
    counterparty: CounterpartyDTO;
}

export interface SettingSubcontractOptDTO extends BaseAuditedDTO {
    externalId: string;
    counterparty: CounterpartyDTO;
}

export interface SettingProductOptDTO extends BaseAuditedDTO {
    externalId: string;
    product: ProductDTO;
}

export interface SpecificationTypeDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    code: string;
    name: string;
}

export interface CalcParamsOptDTO extends BaseAuditedDTO {
    mainId: number;
    externalId: string;
    number1c: string;
    type: ACCESSIBLE_RESOURCE_TYPE;
    month: string;
    dateCalcFrom: string;
    dateCalcTo: string;
    calcForTotalNeed: boolean;
    productAttribute: PRODUCT_ATTRIBUTE;
    internalStatus: INTERNAL_ACCESSIBLE_RESOURCE_STATUS;
    externalStatus: EXTERNAL_ACCESSIBLE_RESOURCE_STATUS;
    resourceOptType: ResourceOptTypeDTO;
    specificationType: SpecificationTypeDTO;
    onlineResource: boolean;
    supplyProperties: SettingSupplyPropertyOptDTO[];
    formulas: SettingFormulaCalcOptDTO[];
    counterparties: SettingCounterpartyOptDTO[];
    subcontracts: SettingSubcontractOptDTO[];
    transitSupplier: boolean;
    transitWarehouse: WarehouseDTO;
    products: SettingProductOptDTO[];
    productSettings?: PRODUCT_SETTINGS_OPT;
    spm: boolean;
}

export interface CalcTaskOptDTO extends BaseAuditedDTO {
    status: CALC_TASK_OPT_STATUS;
    paramsId: number;
    type: ACCESSIBLE_RESOURCE_TYPE;
    resourceOptType: ResourceOptTypeDTO;
    wholesaleDemandId: number;
    month: string;
    dateCalcFrom: string;
    dateCalcTo: string;
}

export interface DocumentWarehouseChangeItemDTO extends BaseAuditedDTO {
    product: ProductDTO;
    warehouse: WarehouseDTO;
    quantity: number;
}

export interface DocumentWarehouseChangeDTO extends BaseAuditedDTO {
    sourceCreatedDate: string;
    period: string;
    source: string;
    status: BASE_STATUS;
    items: DocumentWarehouseChangeItemDTO[];
}

export interface WholesaleDemandItemDTO extends BaseAuditedDTO {
    externalId: string;
    article: string;
    quantity: number;
    status: BASE_STATUS;
}

export interface WholesaleDemandDTO extends BaseAuditedDTO {
    externalId: string;
    month: string;
    businessDomain: BusinessDomainDTO;
    type: WHOLESALE_DEMAND_TYPE;
    number: string;
    specificationType: SpecificationTypeDTO;
    status: BASE_STATUS;
    items: WholesaleDemandItemDTO[];
}

export interface CalcTaskAvailabilityScheduleDTO extends BaseAuditedDTO {
    externalId: string;
    warehouseDocument: WarehouseDocumentDTO;
    order: OrderDTO;
    reasonType: CALC_TASK_AVAILABILITY_REASON_TYPE;
    availabilityType: AVAILABILITY_CATEGORY_TYPE;
    status: CALC_TASK_AVAILABILITY_STATUS;
    startDate: string;
    hasError: boolean;
}

export interface ResourcesExcludeDTO extends BaseAuditedDTO {
    article: string;
    productName: string;
    month: string;
    excludeType: RESOURCES_EXCLUDE_TYPE;
    sourceLastModifiedDate: string;
    product: ProductDTO;
}
