import { CHIP_COLORS } from 'root-front/components';

export enum COUNTERPARTY_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
}

export const COUNTERPARTY_STATUS_MAP = {
    [COUNTERPARTY_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [COUNTERPARTY_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [COUNTERPARTY_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
};

export enum FINANCIAL_LIMIT_TYPE {
    AGREEMENT = 'AGREEMENT',
    COUNTERPARTY = 'COUNTERPARTY',
    CONTRACT = 'CONTRACT',
}

export const FINANCIAL_LIMIT_TYPE_MAP = {
    [FINANCIAL_LIMIT_TYPE.AGREEMENT]: {
        text: 'Соглашение',
    },
    [FINANCIAL_LIMIT_TYPE.COUNTERPARTY]: {
        text: 'Контрагент',
    },
    [FINANCIAL_LIMIT_TYPE.CONTRACT]: {
        text: 'Договор',
    },
};

export enum FINANCIAL_TYPE {
    ZNO = 'ZNO',
    ORDER = 'ORDER',
}

export const FINANCIAL_TYPE_MAP = {
    [FINANCIAL_TYPE.ORDER]: {
        text: 'На формирование заказа',
    },
    [FINANCIAL_TYPE.ZNO]: {
        text: 'На формирование ЗнО',
    },
};

export enum ACTIVITIES_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
}

export const ACTIVITIES_STATUS_MAP = {
    [ACTIVITIES_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [ACTIVITIES_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ACTIVITIES_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
};

export enum AGREEMENT_TYPE_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
}

export const AGREEMENT_TYPE_STATUS_MAP = {
    [AGREEMENT_TYPE_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [AGREEMENT_TYPE_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [AGREEMENT_TYPE_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
};

export enum CONTRACTOR_AGREEMENT_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
}

export const CONTRACTOR_AGREEMENT_STATUS_MAP = {
    [CONTRACTOR_AGREEMENT_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [CONTRACTOR_AGREEMENT_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [CONTRACTOR_AGREEMENT_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
};

export enum FINANCIAL_LIMIT_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export const FINANCIAL_LIMIT_STATUS_MAP = {
    [FINANCIAL_LIMIT_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [FINANCIAL_LIMIT_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
};

export enum RECEIVER_WAREHOUSE_TYPE {
    WAREHOUSE = 'WAREHOUSE',
    GROUP = 'GROUP',
}

export const RECEIVER_WAREHOUSE_TYPE_MAP = {
    [RECEIVER_WAREHOUSE_TYPE.WAREHOUSE]: {
        text: 'Склад',
    },
    [RECEIVER_WAREHOUSE_TYPE.GROUP]: {
        text: 'Группа складов',
    },
};
