import { useQuery } from '@tanstack/react-query';
import { AxiosResponse } from 'axios';

import { api } from 'root-front/api';
import { MS_NOTIFICATION_URL } from 'root-front/dictionaries';
import { ResponseDTO } from 'root-front/interfaces';

export const useUnreadNotificationsCount = () => {
    return useQuery({
        queryKey: ['@root/unread-notifications-count'],
        queryFn: async () => {
            const result = await api.get<
                ResponseDTO<{ count: number }>,
                AxiosResponse<ResponseDTO<{ count: number }>>
            >(`${MS_NOTIFICATION_URL}/notification/unread-count`);

            return result.data;
        },
        refetchInterval: 20000,
        meta: {
            disableDefaultErrorHandler: true,
        },
    });
};
