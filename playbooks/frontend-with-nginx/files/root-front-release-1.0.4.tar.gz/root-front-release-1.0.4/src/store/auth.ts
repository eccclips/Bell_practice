import jwtDecode from 'jwt-decode';
import { atom, selector, useRecoilValue } from 'recoil';

import { TokenPayloadDTO } from 'root-front/interfaces';
import { localStorageEffect } from 'root-front/utils';

export interface AuthInfoState {
    scope: string;
    expiresIn: string;
    refreshExpiresIn: string;
    tokenType: string;
    notBeforePolicy: string;
    userSessionTimeOut: number; // sec
}

export const authInfoState = atom<AuthInfoState>({
    key: '@root/authInfoState',
    default: null,
    effects: [localStorageEffect('@root/authInfoState')],
});

export const accessTokenState = atom<string>({
    key: '@root/accessTokenState',
    default: '',
    effects: [localStorageEffect('@root/accessToken')],
});

export const refreshTokenState = atom<string>({
    key: '@root/refreshTokenState',
    default: '',
    effects: [localStorageEffect('@root/refreshToken')],
});

export const tokenPayloadState = selector<TokenPayloadDTO>({
    key: '@root/tokenPayloadState',
    get: ({ get }) => {
        try {
            const token = get(accessTokenState);
            return jwtDecode<TokenPayloadDTO>(token);
        } catch (e) {
            return null;
        }
    },
});

export const useAuthInfoState = () => {
    return useRecoilValue(authInfoState);
};

export const useAccessTokenState = () => {
    return useRecoilValue(accessTokenState);
};

export const useRefreshTokenState = () => {
    return useRecoilValue(refreshTokenState);
};

export const useTokenPayloadState = () => {
    return useRecoilValue(tokenPayloadState);
};
