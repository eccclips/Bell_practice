import React, { useMemo, useState } from 'react';

import { SvgIcon } from '@mui/material';

import { MenuButton, MenuButtonOption } from 'root-front/components';
import { Icons } from 'root-front/icons';
import { useTokenPayloadState } from 'root-front/store';

import LogoutIcon from 'src/assets/icons/logout.svg';
import { logout } from 'src/utils/auth';
import { Notifications } from 'src/view/containers/header/desktop/notifications';

import { Bookmarks } from '../../bookmarks';
import { Settings } from '../../settings';

import styles from './User.module.scss';

const User = () => {
    const tokenPayload = useTokenPayloadState();
    const [settingsOpened, setSettingsOpened] = useState(false);
    const [bookmarksOpened, setBookmarksOpened] = useState(false);

    const handleLogout = () => {
        logout();
    };

    const handleOpenBookmarks = (closeMenu: () => void) => {
        closeMenu();
        setBookmarksOpened(true);
    };

    const handleOpenSettings = (closeMenu: () => void) => {
        closeMenu();
        setSettingsOpened(true);
    };

    const handleCloseBookmarks = () => {
        setBookmarksOpened(false);
    };

    const handleCloseSettings = () => {
        setSettingsOpened(false);
    };

    const menuOptions = useMemo<MenuButtonOption[]>(
        () => [
            { text: 'Настройки', icon: <Icons.Settings />, onClick: handleOpenSettings },
            { text: 'Закладки', icon: <Icons.Bookmark />, onClick: handleOpenBookmarks },
            { text: 'Выйти', icon: <LogoutIcon />, onClick: handleLogout },
        ],
        []
    );

    const menuBeforeContent = useMemo(() => {
        return (
            <div className={styles.user}>
                <span>{tokenPayload.name}</span>
                <span className={styles.user__email}>{tokenPayload.email}</span>
            </div>
        );
    }, [tokenPayload]);

    return (
        <>
            <div className={styles.row}>
                <Notifications mode="mobile" />
                <div>
                    <MenuButton
                        componentType="icon-button"
                        menuOptions={menuOptions}
                        menuBeforeContent={menuBeforeContent}
                    >
                        <SvgIcon>
                            <Icons.User />
                        </SvgIcon>
                    </MenuButton>
                </div>
            </div>
            <Settings open={settingsOpened} onClose={handleCloseSettings} />
            <Bookmarks open={bookmarksOpened} onClose={handleCloseBookmarks} />
        </>
    );
};

export default React.memo(User);
