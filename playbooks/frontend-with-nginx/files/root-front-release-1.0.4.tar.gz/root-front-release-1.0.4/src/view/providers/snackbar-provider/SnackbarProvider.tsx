import React from 'react';

import { IconButton, SvgIcon } from '@mui/material';
import { closeSnackbar, SnackbarProvider as SnackbarProviderCore } from 'notistack';

import { Icons } from 'root-front/icons';

import styles from './SnackbarProvider.module.scss';

export const SnackbarProvider = ({ children }: React.PropsWithChildren) => {
    return (
        <SnackbarProviderCore
            classes={{ root: styles.snackbar }}
            hideIconVariant
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            action={(key) => (
                <IconButton size="small" onClick={() => closeSnackbar(key)}>
                    <SvgIcon>
                        <Icons.Close />
                    </SvgIcon>
                </IconButton>
            )}
        >
            {children}
        </SnackbarProviderCore>
    );
};
