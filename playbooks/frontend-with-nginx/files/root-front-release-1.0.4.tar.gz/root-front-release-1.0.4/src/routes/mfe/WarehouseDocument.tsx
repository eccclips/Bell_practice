import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const WarehouseDocumentMFE = React.lazy(() =>
    loadModule(process.env.MFE_WAREHOUSE_DOCUMENT_HOST, './WarehouseDocument')
);

export function WarehouseDocumentRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <WarehouseDocumentMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
