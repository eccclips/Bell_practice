import React from 'react';

import { Bookmark } from '../bookmark';

import styles from './TitleWithBookmark.module.scss';

type Props = {
    title: string;
};

const TitleWithBookmark = (props: Props) => {
    const { title } = props;

    return (
        <h1>
            <Bookmark name={title} className={styles.bookmark} />
            {title}
        </h1>
    );
};

export default React.memo(TitleWithBookmark);
