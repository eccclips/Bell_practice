import { useCallback, useLayoutEffect, useRef } from 'react';

export function useEvent<T extends (...args: any[]) => any>(handler: T): T {
    const handlerRef = useRef(null);

    useLayoutEffect(() => {
        handlerRef.current = handler;
    });

    const callback = useCallback((...args) => {
        const fn = handlerRef.current;
        return fn(...args);
    }, []);

    return callback as T;
}

export function usePrevious<T>(value: T): T {
    const currentRef = useRef(value);
    const previousRef = useRef<T>();

    if (currentRef.current !== value) {
        previousRef.current = currentRef.current;
        currentRef.current = value;
    }

    return previousRef.current;
}
