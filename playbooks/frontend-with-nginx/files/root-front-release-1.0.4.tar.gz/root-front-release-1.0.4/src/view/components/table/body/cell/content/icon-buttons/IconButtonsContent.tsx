import React, { useMemo } from 'react';

import { IconButton, SvgIcon } from '@mui/material';

import { typedMemo } from 'root-front/utils';

import { ActionType, TableData } from '../../../../types';

import styles from './IconButtonsContent.module.scss';

type IconButtonsContentProps<Data = any> = {
    actions: ActionType[] | ((data: Data) => ActionType<Data>[]);
    row: TableData<Data>;
    rowIndex: number;
    colIndex: number;
};

const IconButtonsContent = <Data,>(props: IconButtonsContentProps<Data>) => {
    const { actions, row, rowIndex, colIndex } = props;
    const parsedActions = useMemo(
        () => (typeof actions === 'function' ? actions(row) : actions),
        [actions, row]
    );

    return (
        <div className={styles.icons}>
            {parsedActions?.map((action) => (
                <IconButton
                    size="small"
                    key={action.name}
                    onClick={(e) => {
                        e.stopPropagation();
                        action.action(row, { rowIndex, colIndex });
                    }}
                    aria-label={action.name}
                >
                    <SvgIcon>{action.Icon ? <action.Icon /> : null}</SvgIcon>
                </IconButton>
            ))}
        </div>
    );
};

export default typedMemo(IconButtonsContent);
