import React, { useMemo, useState } from 'react';

import { Box, Chip, FormControl, FormHelperText, IconButton, Select, SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { QuerySelectModal } from '../select-modal';
import { QuerySelectWithModalProps } from './types';

import styles from './QuerySelectWithModal.module.scss';

const QuerySelectWithModal = <Data, QueryParams, Multiple extends boolean = false>(
    props: QuerySelectWithModalProps<Data, QueryParams, Multiple>
) => {
    const {
        value,
        name,
        placeholder,
        getOptionFromData,
        onChange,
        onBlur,
        multiple = false,
        dataKey = 'id',
        limit = 5,
        id,
        labelId,
        inputRef,
        error,
        helperText,
        className,
        modalTableName,
        modalTitle,
        disabled,
        ...rest
    } = props;

    const [opened, setOpened] = useState(false);

    const handleOpen = () => {
        if (disabled) {
            return;
        }

        setOpened(true);
    };

    const handleClose = () => {
        setOpened(false);
    };

    const handleChange = (value: Multiple extends true ? Data[] : Data) => {
        onChange?.(value);
        setOpened(false);
    };

    const handleClear = (e: React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        onChange?.((multiple ? [] : null) as Multiple extends true ? Data[] : Data);
    };

    const handleRemoveElement = (el: Data) => {
        onChange?.(
            (value as Data[]).filter(
                (val) => val?.[dataKey] !== el?.[dataKey]
            ) as Multiple extends true ? Data[] : Data
        );
    };

    const showDeleteButton = multiple ? !!(value as Data[]).length : !!value;
    const parsedValue = multiple ? value : value || '';

    const renderValue = useMemo(() => {
        return multiple
            ? (selected) => {
                  const sliced =
                      limit === -1 ? (selected as Data[]) : (selected as Data[]).slice(0, limit);
                  const rest = (selected as Data[]).length - sliced.length;

                  return (
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {(sliced as Data[]).map((value) => {
                              const option = getOptionFromData(value);

                              return (
                                  <Chip
                                      key={option.key}
                                      label={option.label}
                                      size="small"
                                      onDelete={() => {
                                          handleRemoveElement(value);
                                      }}
                                  />
                              );
                          })}
                          {rest > 0 && <span className={styles.rest}>+{rest}</span>}
                      </Box>
                  );
              }
            : (selected) => (selected ? getOptionFromData(selected as Data).label : null);
    }, [multiple, getOptionFromData, limit]);

    return (
        <>
            <FormControl size="small" error={error} className={className}>
                <Select
                    name={name}
                    value={parsedValue}
                    renderValue={renderValue}
                    IconComponent={(props) => (
                        <SvgIcon {...props}>
                            <Icons.Dictionary />
                        </SvgIcon>
                    )}
                    endAdornment={
                        showDeleteButton ? (
                            <IconButton
                                size="small"
                                className={styles.deleteButton}
                                onClick={handleClear}
                            >
                                <SvgIcon>
                                    <Icons.Close />
                                </SvgIcon>
                            </IconButton>
                        ) : null
                    }
                    onClick={handleOpen}
                    onOpen={(e) => {
                        if (e.type === 'keydown') {
                            handleOpen();
                        }
                    }}
                    open={false}
                    multiple={multiple}
                    disabled={disabled}
                    size="small"
                    onBlur={onBlur}
                    inputRef={inputRef}
                    inputProps={{ id: labelId || id }}
                    labelId={labelId || id}
                    sx={{
                        '& .MuiSelect-select .notranslate::after': placeholder
                            ? {
                                  content: `"${placeholder}"`,
                                  opacity: 0.42,
                              }
                            : {},
                    }}
                />
                {helperText ? <FormHelperText>{helperText}</FormHelperText> : null}
            </FormControl>

            <QuerySelectModal
                {...rest}
                name={modalTableName}
                title={modalTitle}
                opened={opened}
                value={value}
                multiple={multiple}
                onClose={handleClose}
                onChange={handleChange}
                dataKey={dataKey}
            />
        </>
    );
};

export default typedMemo(QuerySelectWithModal);
