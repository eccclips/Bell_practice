import React, { useEffect, useMemo } from 'react';

import { Control, UseFormSetValue, UseFormTrigger, useWatch } from 'react-hook-form';

import { typedMemo, useEvent } from 'root-front/utils';

import { Fields } from '../../../../../fields';

type NumberRangeProps<T> = {
    control: Control<T>;
    setValue: UseFormSetValue<Record<string, any>>;
    trigger: UseFormTrigger<Record<string, any>>;
    name: any;
    label: string;
    placeholder?: string;
    inputMode?: 'decimal' | 'numeric';
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
};

const NumberRange = <T,>(props: NumberRangeProps<T>) => {
    const {
        control,
        trigger,
        name,
        label,
        placeholder,
        inputMode = 'decimal',
        onChange,
        setValue,
    } = props;

    const nameFrom = `${name}.from`;
    const nameTo = `${name}.to`;

    const valueFrom = useWatch({ control, name: nameFrom as any }) as number;
    const valueTo = useWatch({ control, name: nameTo as any }) as number;

    const labelFrom = `${label} от`;
    const labelTo = `${label} до`;

    const handleChange = useEvent(() => {
        onChange?.({ from: valueFrom, to: valueTo }, setValue);
    });

    const { placeholderFrom, placeholderTo } = useMemo(
        () => ({
            placeholderFrom: placeholder ? `${placeholder} от` : 'От',
            placeholderTo: placeholder ? `${placeholder} до` : 'До',
        }),
        [placeholder]
    );

    useEffect(() => {
        trigger([nameFrom, nameTo]);
    }, [valueFrom, valueTo]);

    return (
        <>
            <label htmlFor={nameFrom}>{labelFrom}</label>
            <Fields.TextField
                control={control}
                rules={{
                    max: { value: valueTo, message: 'Значение «От» превышает «До»' },
                }}
                name={nameFrom as any}
                id={nameFrom}
                type="number"
                placeholder={placeholderFrom}
                inputMode={inputMode}
                onChange={handleChange}
            />
            <label htmlFor={nameTo}>{labelTo}</label>
            <Fields.TextField
                control={control}
                rules={{
                    min: { value: valueFrom, message: 'Значение «От» превышает «До»' },
                }}
                name={nameTo as any}
                id={nameTo}
                type="number"
                placeholder={placeholderTo}
                inputMode={inputMode}
                onChange={handleChange}
            />
        </>
    );
};

export default typedMemo(NumberRange);
