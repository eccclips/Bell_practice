import axios from 'axios';

import { MS_USER_URL } from '../dictionaries/api';
import { AuthDataDTO, ResponseDTO } from '../interfaces/api';

export const logout = () => {
    localStorage.setItem('@root/accessToken', null);
    localStorage.setItem('@root/refreshToken', null);
    localStorage.setItem('@root/authInfoState', null);
    localStorage.setItem('@root/permissions', null);
    location.pathname = '/auth';
};

export const refreshToken = async (refreshToken: string) => {
    const result = await axios.post<ResponseDTO<AuthDataDTO>>(`${MS_USER_URL}/auth/refresh-token`, {
        refreshToken,
    });

    return result.data;
};
