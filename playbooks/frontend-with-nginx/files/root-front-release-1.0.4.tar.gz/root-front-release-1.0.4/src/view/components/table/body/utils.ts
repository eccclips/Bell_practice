import { TableData, TableGroupModel } from '../types';
import { GROUP_ROW_DATA_SYMBOL, REST_ROWS_SYMBOL } from './constants';
import { GroupedRows } from './types';

export const getRowsModel = <Data>(
    data: TableData<Data>[],
    groupBy: TableGroupModel<Data>['groupBy'],
    getGroupRowData: TableGroupModel<Data>['getGroupRowData'],
    depth = 0
): GroupedRows<Data> => {
    if (!groupBy?.[depth] || !data?.length) {
        return null;
    }

    const result: GroupedRows<Data> = {
        [REST_ROWS_SYMBOL]: null,
        [GROUP_ROW_DATA_SYMBOL]: null,
    };

    for (let i = 0; i < data.length; i += 1) {
        const key = groupBy[depth](data[i]);
        const notNullKey = key === null || key === '' || key === undefined ? REST_ROWS_SYMBOL : key;

        if (!result[notNullKey]) {
            result[notNullKey] = [data[i]];
        } else {
            (result[notNullKey] as TableData<Data>[]).push(data[i]);
        }
    }

    if (!groupBy[depth + 1] && getGroupRowData?.[depth]) {
        Object.entries(result).forEach(([key, value]) => {
            result[key][GROUP_ROW_DATA_SYMBOL] = getGroupRowData[depth](
                value as TableData<Data>[],
                key
            );
        });
    }

    if (groupBy[depth + 1]) {
        Object.entries(result).forEach(([key, value]) => {
            result[key] = getRowsModel(
                value as TableData<Data>[],
                groupBy,
                getGroupRowData,
                depth + 1
            );
            if (getGroupRowData?.[depth]) {
                result[key][GROUP_ROW_DATA_SYMBOL] = getGroupRowData[depth](
                    value as TableData<Data>[],
                    key
                );
            }
        });
        if (result[REST_ROWS_SYMBOL]) {
            result[REST_ROWS_SYMBOL] = getRowsModel(
                result[REST_ROWS_SYMBOL] as TableData<Data>[],
                groupBy,
                getGroupRowData,
                depth + 1
            );
        }
    }

    return result;
};
