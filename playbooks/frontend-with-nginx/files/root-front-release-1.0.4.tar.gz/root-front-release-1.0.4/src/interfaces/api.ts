import { LINK_TYPE } from 'root-front/constants';
import { PERMISSIONS } from 'root-front/store';

import { UserInfoUDB } from './user';

export interface AuthDataDTO {
    accessToken: string;
    refreshToken: string;
    scope: string;
    expiresIn: string;
    refreshExpiresIn: string;
    tokenType: string;
    notBeforePolicy: string;
    userSettings: any;
    roles: string[];
    privileges: PERMISSIONS[];
    userSessionTimeOut: number;
}

export interface ResponseErrorDTO {
    timestamp: number;
    type: string;
    code: string;
    message: string;
    debugMessage: string;
}

export interface ResponseDTO<Data = any> {
    data: Data;
    success: boolean;
    errors: ResponseErrorDTO[];
    page: number;
    totalPages: number;
    total: number;
    limit: number;
    last: boolean;
}

export type DYNAMIC_COLUMN_TYPES = 'link' | 'text' | 'date' | 'boolean' | 'chip';

export interface DynamicRowDTO {
    id: number;
    cells: { id?: number; key: string; value: unknown }[];
}

export interface DynamicColumnDTO {
    key: string;
    name: string;
    type: DYNAMIC_COLUMN_TYPES;
    linkType?: LINK_TYPE;
    children?: DynamicColumnDTO[];
}

export interface DynamicDataDTO {
    rows: DynamicRowDTO[];
    headers: DynamicColumnDTO[];
}

export interface BaseAuditedDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
}
