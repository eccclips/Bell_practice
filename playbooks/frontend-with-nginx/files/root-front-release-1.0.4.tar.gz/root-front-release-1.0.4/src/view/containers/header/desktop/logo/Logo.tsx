import React from 'react';

import { Link } from 'react-router-dom';

import logoUrl from 'src/assets/logo.svg?url';

import styles from './Logo.module.scss';

export const Logo = React.memo(() => {
    return (
        <div className={styles.logo}>
            <Link to="/" className={styles.logo__link}>
                <img src={logoUrl} alt="Лада Имидж" />
            </Link>
        </div>
    );
});
