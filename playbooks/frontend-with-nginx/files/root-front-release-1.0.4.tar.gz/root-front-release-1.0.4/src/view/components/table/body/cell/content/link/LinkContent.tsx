import React, { memo } from 'react';

import { Link } from 'react-router-dom';

import styles from './LinkContent.module.scss';

type LinkContentProps = {
    value: string | number;
    link: string;
};

const LinkContent = (props: LinkContentProps) => {
    const { value, link } = props;

    const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.stopPropagation();
    };

    return (
        <Link to={link} className={styles.link} onClick={handleClick}>
            {value}
        </Link>
    );
};

export default memo(LinkContent);
