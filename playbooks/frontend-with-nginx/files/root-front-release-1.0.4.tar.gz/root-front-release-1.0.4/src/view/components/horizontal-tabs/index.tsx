export { default as HorizontalTabs } from './HorizontalTabs';
export { type HorizontalTab } from './types';
