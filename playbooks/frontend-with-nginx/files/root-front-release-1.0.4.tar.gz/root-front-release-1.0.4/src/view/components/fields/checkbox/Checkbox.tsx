import React from 'react';

import { Checkbox as CheckboxCore, CheckboxProps as CheckboxCoreProps } from '@mui/material';
import { useController, UseControllerProps } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

export type CheckboxProps<T> = UseControllerProps<T> & CheckboxCoreProps;

const Checkbox = <T,>(props: CheckboxProps<T>) => {
    const { field } = useController(props);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => {
        field.onChange(checked);
        props.onChange?.(e, checked);
    };

    const handleBlur = (e: React.FocusEvent<HTMLButtonElement>) => {
        field.onBlur();
        props.onBlur?.(e);
    };

    return (
        <CheckboxCore
            {...props}
            onChange={handleChange}
            onBlur={handleBlur}
            checked={field.value as boolean}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(Checkbox);
