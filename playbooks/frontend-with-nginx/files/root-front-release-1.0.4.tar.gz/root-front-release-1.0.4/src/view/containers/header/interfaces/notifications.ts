export interface Notification {
    id: number;
    title: string;
    text: string;
    isRead: boolean;
}
