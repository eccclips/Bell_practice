import React, { useEffect, useRef } from 'react';

import { Stack } from '@mui/material';
import { useLocation } from 'react-router-dom';

import { useNavigationTabs } from 'src/routes';
import { LAYOUT, useIsMenuExpanded, useLayoutState } from 'src/store/settings';

import { CollapsableList } from '../../components/collapsable-list';
import { NavItem } from '../../components/nav-item';

import styles from './Nav.module.scss';

export const Nav = React.memo(() => {
    const location = useLocation();
    const [isExpanded, setIsExpanded] = useIsMenuExpanded();
    const layout = useLayoutState();

    const tabs = useNavigationTabs();

    const isFirstRenderRef = useRef(true);

    useEffect(() => {
        if (isFirstRenderRef.current) {
            isFirstRenderRef.current = false;
            return;
        }

        if (layout === LAYOUT.TABLET && isExpanded) {
            setIsExpanded(false);
        }
    }, [location]);

    return (
        <nav className={styles.nav}>
            <Stack gap="4px" component="ul">
                {tabs.map((tab) => {
                    if (tab.children?.length) {
                        return <CollapsableList key={tab.name} tab={tab} />;
                    }
                    return (
                        <NavItem
                            key={tab.name}
                            text={tab.name}
                            to={tab.path}
                            type="link"
                            Icon={tab.Icon}
                        />
                    );
                })}
            </Stack>
        </nav>
    );
});
