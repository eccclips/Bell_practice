import dayjs from 'dayjs';
import * as Yup from 'yup';

export const yupIsDayJs = (message = 'Некорректная дата'): Yup.TestConfig => ({
    name: 'yupIsDayJs',
    message,
    test: (val: dayjs.Dayjs) => {
        return dayjs.isDayjs(val) && val?.isValid?.();
    },
});

export const yupDayJsMinDate = (minDate: dayjs.Dayjs, message = ''): Yup.TestConfig => ({
    name: 'yupDayJsMinDate',
    message: message || `Мин. дата ${minDate.format('DD.MM.YYYY')}`,
    test: (val: dayjs.Dayjs) => {
        if (!val?.isValid?.()) {
            return false;
        }
        return minDate.isBefore(val, 'day') || minDate.isSame(val, 'day');
    },
});

export const yupDateRangeSchema = ({
    from,
    to,
}: {
    from?: (
        schema: Yup.StringSchema<string, Yup.AnyObject, undefined, ''>
    ) => Yup.StringSchema<string, Yup.AnyObject, undefined, ''>;
    to?: (
        schema: Yup.StringSchema<string, Yup.AnyObject, undefined, ''>
    ) => Yup.StringSchema<string, Yup.AnyObject, undefined, ''>;
}) =>
    Yup.object({
        from: from ? from(Yup.string().nullable()) : Yup.string().nullable(),
        to: to ? to(Yup.string().nullable()) : Yup.string().nullable(),
    });
