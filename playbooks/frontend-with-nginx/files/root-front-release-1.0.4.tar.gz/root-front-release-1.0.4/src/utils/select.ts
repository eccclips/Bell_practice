import { SelectOption } from 'root-front/components';

export const getSelectOptionsByMap = <T>(
    statusMap: Record<keyof T, { text: string }>
): SelectOption<keyof T>[] => {
    return Object.keys(statusMap).map((key) => ({
        key: key,
        value: key as keyof T,
        label: statusMap[key].text,
    }));
};
