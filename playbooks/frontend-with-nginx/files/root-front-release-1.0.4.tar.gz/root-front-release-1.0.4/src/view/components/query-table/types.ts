import { UseQueryResult } from '@tanstack/react-query';

import { TableColumn } from 'root-front/components';
import { DynamicDataDTO, ResponseDTO, SortInstructionDTO } from 'root-front/interfaces';
import { ListRequestParams } from 'root-front/types';

import { CHIP_COLORS } from '../chip';
import { TableData, TableProps } from '../table';

export type SearchParams = {
    page?: number;
    size?: number;
    sort?: SortInstructionDTO;
};

export type QueryTableProps<
    D,
    P,
    Data extends TableData<D>,
    ParsedData extends TableData<P>,
    Params = any,
> = Pick<
    TableProps<ParsedData>,
    | 'columns'
    | 'dataKey'
    | 'viewMode'
    | 'filters'
    | 'onRowClick'
    | 'isLoading'
    | 'checkboxSelection'
    | 'selectedRows'
    | 'groupModel'
    | 'expandable'
    | 'renderExpandedContent'
    | 'onSelectedRowsChange'
    | 'getRowSelectionDisabled'
    | 'slots'
    | 'itemsPerPage'
    | 'getRowError'
    | 'getRowHighlight'
> & {
    name?: string;
    query: (
        params: ListRequestParams<Record<string, any>, Params>
    ) => UseQueryResult<ResponseDTO<Data[]>>;
    getData?: (data: ResponseDTO<Data[]>) => ParsedData[];
    saveParamsInURI?: boolean;
    defaultParams?: SearchParams;
    defaultFilters?: Record<string, any>;
    getRequestFilters?: (filterValues: Record<string, any>) => any;
    queryParams?: Params;
    allowColumnSettings?: boolean;
    allowSavedFilters?: boolean;
    pageable?: boolean;
};

export type RowDataMap = {
    id: number | string;
    cellsMap: Record<string, { id?: number; key: string; value: unknown }>;
};

export type DynamicQueryTableProps<P, ParsedData extends TableData<P>, Params = any> = Pick<
    TableProps<ParsedData>,
    | 'viewMode'
    | 'onRowClick'
    | 'isLoading'
    | 'checkboxSelection'
    | 'selectedRows'
    | 'groupModel'
    | 'expandable'
    | 'renderExpandedContent'
    | 'onSelectedRowsChange'
    | 'getRowSelectionDisabled'
    | 'slots'
    | 'itemsPerPage'
    | 'isFiltersChanged'
    | 'savedFilters'
    | 'onFiltersReset'
> & {
    name?: string;
    query: (
        params: ListRequestParams<Record<string, any>, Params>
    ) => UseQueryResult<ResponseDTO<DynamicDataDTO>>;
    saveParamsInURI?: boolean;
    defaultParams?: SearchParams;
    queryParams?: Params;
    allowColumnSettings?: boolean;
    requestFilters?: any;
    chipMap?: Record<string, { text: string; color: CHIP_COLORS }>;
    columnProps?: Pick<
        TableColumn,
        | 'sortable'
        | 'resizable'
        | 'resizeWidth'
        | 'initialWidth'
        | 'minWidth'
        | 'maxWidth'
        | 'emptyValue'
    >;
};
