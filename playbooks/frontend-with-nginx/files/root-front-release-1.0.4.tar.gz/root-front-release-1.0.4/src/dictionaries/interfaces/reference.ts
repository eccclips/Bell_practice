import { BaseAuditedDTO } from 'root-front/interfaces';

import { Formula } from '../../view/components/math/types';
import { STANDARD_VARIABLE_PARAM_TYPE, SYSTEM_PARAMS_CODE, SYSTEM_PARAMS_TYPE } from '../constants';

export interface CurrencyDTO {
    id: number;
    code: string;
    externalId: string;
    name: string;
    shortName: string;
    createdDate: string;
    lastModifiedDate: string;
    isDeleted: boolean;
}

export interface ReferenceDTO extends BaseAuditedDTO {
    externalId: string;
    code: string;
    fullName: string;
    shortName: string;
}

export interface StandardVariableParamDTO {
    id: number;
    name: string;
    type: STANDARD_VARIABLE_PARAM_TYPE;
}

export interface StandardVariableParamValueDTO {
    id: number;
    variableId: number;
    value: string | number;
    valueObject: any;
}

export interface FormulaParameterDTO {
    id: number;
    code: string;
    name: string;
    description: string;
    expectedResultUnitOfMeasure: string;
    useInReserveSchedule: boolean;
    useInResourceSchedule: boolean;
    useInB2b: boolean;
    useInB2bItem: boolean;
    useInB2bItemSelf: boolean;
    useInOpt: boolean;
    useInTop: boolean;
    useInTransit: boolean;
    availabilityVariablesGroup?: VariablesGroupDTO;
    optVariablesGroup?: VariablesGroupDTO;
    parametrizable: boolean;
    variables: StandardVariableParamDTO[];
}

export interface FormulaVariableDTO {
    id: number;
    code?: string;
    name: string;
    formula: Formula;
}

export interface CustomFormulaDTO {
    id: number;
    code: string;
    expectedResultUnitOfMeasure: string;
    name: string;
    description: string;
    formula: Formula;
    parametrized: boolean;
    standardVariable?: FormulaParameterDTO;
    values?: StandardVariableParamValueDTO[];
    availabilityVariablesGroup?: VariablesGroupDTO;
    optVariablesGroup?: VariablesGroupDTO;
    useInReserveSchedule: boolean;
    useInResourceSchedule: boolean;
    useInB2b: boolean;
    useInB2bItem: boolean;
    useInB2bItemSelf: boolean;
    useInOpt: boolean;
    useInTop: boolean;
    useInTransit: boolean;
}

export interface SystemParamsDTO extends BaseAuditedDTO {
    code: SYSTEM_PARAMS_CODE;
    name: string;
    description: string;
    value: string | number;
    type: SYSTEM_PARAMS_TYPE;
    valueObject: any;
}

export interface VariablesGroupDTO extends BaseAuditedDTO {
    name: string;
    description: string;
}
