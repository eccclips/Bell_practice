export type SelectedDays = Record<string, React.ReactNode>;

export type CalendarProps = {
    year: number;
    selectedDays: SelectedDays;
    isLoading?: boolean;
};

export type CalendarMonthProps = {
    year: number;
    month: number;
    selectedDays: SelectedDays;
};
