import React from 'react';

import { Button, Menu, MenuItem, SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';

import styles from './TableItemsPerPage.module.scss';

type TableItemsPerPageProps = {
    size: number;
    page: number;
    totalElements: number;
    itemsPerPage: number[];
    onSizeChange: (size: number) => void;
};

const getPagesText = (size: number, page: number, totalElements: number) => {
    const from = page * size + 1;
    const to = Math.min((page + 1) * size, totalElements);

    return `${from} - ${to} из ${totalElements}`;
};

const TableItemsPerPage = (props: TableItemsPerPageProps) => {
    const { size, page, totalElements, itemsPerPage, onSizeChange } = props;

    const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleItemsPerPageChange = (e: React.MouseEvent<HTMLLIElement>) => {
        const nextSize = +e.currentTarget.getAttribute('data-value');

        if (nextSize === size) {
            return;
        }

        onSizeChange(+e.currentTarget.getAttribute('data-value'));
        handleClose();
    };

    const open = !!anchorEl;

    const pagesText = getPagesText(size, page, totalElements);

    return (
        <div className={styles.itemsPerPage}>
            <div className={styles.itemsPerPage__select}>
                <span className={styles.itemsPerPage__text}>Элементов на странице</span>
                <Button
                    variant="outlined"
                    color="secondary"
                    size="small"
                    className={styles.itemsPerPage__button}
                    endIcon={
                        <SvgIcon>
                            <Icons.ArrowDown />
                        </SvgIcon>
                    }
                    onClick={handleClick}
                >
                    {size}
                </Button>
                <Menu
                    anchorEl={anchorEl}
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'center',
                    }}
                    transformOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                    }}
                    onClose={handleClose}
                    open={open}
                >
                    {itemsPerPage.map((value) => (
                        <MenuItem
                            key={value}
                            onClick={handleItemsPerPageChange}
                            data-value={value}
                            selected={size === value}
                        >
                            {value}
                        </MenuItem>
                    ))}
                </Menu>
            </div>
            <div className={styles.itemsPerPage__info}>{pagesText}</div>
        </div>
    );
};

export default React.memo(TableItemsPerPage);
