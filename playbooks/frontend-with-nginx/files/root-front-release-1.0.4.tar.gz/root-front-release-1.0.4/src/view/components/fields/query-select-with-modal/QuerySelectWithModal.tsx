import React from 'react';

import { useController, UseControllerProps } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import {
    QuerySelectWithModal as QuerySelectWithModalCore,
    QuerySelectWithModalProps,
} from '../../query-select';

export type QuerySelectWithModalFieldProps<
    T,
    Data,
    QueryParams,
    Multiple extends boolean,
> = UseControllerProps<T> & Omit<QuerySelectWithModalProps<Data, QueryParams, Multiple>, 'value'>;

const QuerySelectWithModal = <T, Data, QueryParams, Multiple extends boolean = false>(
    props: QuerySelectWithModalFieldProps<T, Data, QueryParams, Multiple>
) => {
    const { field, fieldState } = useController(props);

    const handleChange = (value: Multiple extends true ? Data[] : Data) => {
        field.onChange(value);
        props.onChange?.(value);
    };

    const handleBlur = (e: React.FocusEvent<HTMLDivElement>) => {
        field.onBlur();
        props.onBlur?.(e);
    };

    return (
        <QuerySelectWithModalCore
            {...props}
            helperText={
                fieldState.error ? <FormErrorHelper message={fieldState.error.message} /> : null
            }
            error={!!fieldState.error}
            onChange={handleChange}
            onBlur={handleBlur}
            value={field.value as any}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(QuerySelectWithModal);
