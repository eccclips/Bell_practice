import React from 'react';

import { Control, useController, UseControllerProps } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

import { FormulaConstructor, FormulaConstructorProps } from '../../math';

export type FormulaProps<T> = Omit<UseControllerProps<T>, 'control'> &
    Omit<FormulaConstructorProps, 'control'> & {
        control: Control<T>;
    };

const Formula = <T,>(props: FormulaProps<T>) => {
    useController(props);
    return <FormulaConstructor {...props} />;
};

export default typedMemo(Formula);
