import React from 'react';

import { ErrorPage } from '../error-page';

export class ErrorBoundary extends React.PureComponent<
    { children: React.ReactNode; errorPageText?: string; errorPageContent?: React.ReactNode },
    { hasError: boolean }
> {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError() {
        return { hasError: true };
    }

    render() {
        if (this.state.hasError) {
            return (
                <ErrorPage text={this.props.errorPageText}>{this.props.errorPageContent}</ErrorPage>
            );
        }

        return this.props.children;
    }
}
