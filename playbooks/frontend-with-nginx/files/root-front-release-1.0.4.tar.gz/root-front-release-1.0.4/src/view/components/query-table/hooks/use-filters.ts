import { useCallback, useMemo } from 'react';

import { useTableFiltersState } from 'root-front/store';
import { getFilterValuesForRequest } from 'root-front/utils';

import { TableFilter } from '../../table';

type Config = {
    name: string;
    filters: TableFilter[];
    defaultFilters: Record<string, any>;
    getRequestFilters?: (filterValues: Record<string, any>) => any;
};

export const useFilters = (config: Config) => {
    const { name, filters, defaultFilters, getRequestFilters } = config;

    const [filterValuesState, setFilterValues] = useTableFiltersState(name);

    const filterValues = filterValuesState.isDefault ? defaultFilters : filterValuesState.filters;

    const requestFilters = useMemo(() => {
        const filterValuesForRequest = getFilterValuesForRequest(filterValues, filters);

        const requestFilters =
            filterValuesForRequest && getRequestFilters
                ? getRequestFilters(filterValuesForRequest)
                : filterValuesForRequest;

        return requestFilters;
    }, [filterValues]);

    const filterTimestamp = useMemo(() => Date.now(), [requestFilters]);

    const isFiltersChanged = !!requestFilters;
    const allowResetFiltersToDefault = !!defaultFilters;

    const onFiltersChange = useCallback((nextFilterValues: Record<string, any>) => {
        setFilterValues({ filters: nextFilterValues, isDefault: false, appliedFilter: null });
    }, []);

    const onFiltersReset = useCallback((toDefault: boolean) => {
        setFilterValues({ isDefault: toDefault, filters: null });
    }, []);

    return {
        filterValuesState,
        filterValues,
        requestFilters,
        isFiltersChanged,
        allowResetFiltersToDefault,
        filterTimestamp,
        onFiltersChange,
        onFiltersReset,
        setFilterValues,
    } as const;
};
