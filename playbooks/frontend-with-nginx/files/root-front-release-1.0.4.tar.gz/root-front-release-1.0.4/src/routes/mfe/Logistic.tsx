import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const LogisticMFE = React.lazy(() => loadModule(process.env.MFE_LOGISTIC_HOST, './Logistic'));

export function LogisticRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <LogisticMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
