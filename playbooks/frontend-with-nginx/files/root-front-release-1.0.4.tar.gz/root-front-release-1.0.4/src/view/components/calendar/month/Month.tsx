import React from 'react';

import { DateCalendar } from '@mui/x-date-pickers';
import dayjs from 'dayjs';

import { Day } from '../day';
import { CalendarMonthProps } from '../types';

import styles from '../Calendar.module.scss';

const Month = (props: CalendarMonthProps) => {
    const { year, month, selectedDays } = props;

    const minDate = dayjs(`${year}-${month.toString().padStart(2, '0')}-01`);
    const maxDate = minDate.endOf('month');

    const yearAndMonthString = `${year}-${month.toString().padStart(2, '0')}`;

    return (
        <DateCalendar
            value={null}
            views={['day']}
            minDate={minDate}
            maxDate={maxDate}
            slots={{
                nextIconButton: () => null,
                previousIconButton: () => null,
                day: Day,
            }}
            slotProps={{
                day: { selectedDays, yearAndMonthString } as any,
                calendarHeader: { className: styles.datepicker__header },
            }}
            readOnly
        />
    );
};

export default React.memo(Month);
