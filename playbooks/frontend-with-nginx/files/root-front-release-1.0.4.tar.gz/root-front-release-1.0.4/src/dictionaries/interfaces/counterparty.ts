import {
    ACTIVITIES_STATUS,
    AGREEMENT_TYPE_STATUS,
    CONTRACTOR_AGREEMENT_STATUS,
    CurrencyDTO,
    FINANCIAL_LIMIT_STATUS,
    FINANCIAL_TYPE,
    WarehouseDTO,
    WarehouseGroupDTO,
} from 'root-front/dictionaries';
import { BaseAuditedDTO } from 'root-front/interfaces';

import { COUNTERPARTY_STATUS, RECEIVER_WAREHOUSE_TYPE } from '../constants';

export interface CounterpartyGroupDTO extends BaseAuditedDTO {
    code: string;
    name: string;
}

export interface BusinessDomainDTO extends BaseAuditedDTO {
    code: string;
    name: string;
}

export interface PackingTypeDTO extends BaseAuditedDTO {
    code: string;
    name: string;
}

export interface AgreementTypeDTO extends BaseAuditedDTO {
    code: string;
    name: string;
    status: AGREEMENT_TYPE_STATUS;
}

export interface ActivitiesDTO extends BaseAuditedDTO {
    code: string;
    name: string;
    status: ACTIVITIES_STATUS;
}

export interface ConsigneeContractDTO extends BaseAuditedDTO {
    counterparty: CounterpartyDTO;
    type: string;
    sourceCode: string;
}

export interface CounterpartyDTO extends BaseAuditedDTO {
    sourceId: string;
    sourceCode: string;
    name: string;
    inn: string;
    kpp: string;
    isPurchaser: boolean;
    isVendor: boolean;
    inforCode: string;
    status: COUNTERPARTY_STATUS;
    counterpartyGroup: CounterpartyGroupDTO;
    purchaser?: boolean;
    vendor?: boolean;
}

export interface ContractDTO extends BaseAuditedDTO {
    fullName: string;
    shortName: string;
    sourceId: string;
    sourceCode: string;
    name: string;
    dateBegin: string;
    status: COUNTERPARTY_STATUS;
    counterparty: CounterpartyDTO;
    endDate: string;
}

export interface ContractorAgreementDTO extends BaseAuditedDTO {
    sourceId?: string;
    sourceCode?: string;
    consignee?: CounterpartyDTO;
    counterparty?: CounterpartyDTO;
    warehouse?: WarehouseDTO;
    vazOrderCode?: string;
    comment?: string;
    type?: string;
    agreementType?: AgreementTypeDTO;
    businessDomain?: BusinessDomainDTO;
    packingType?: PackingTypeDTO;
    contract?: ContractDTO;
    status: CONTRACTOR_AGREEMENT_STATUS;
    warehouseGroup?: WarehouseGroupDTO;
    currency?: CurrencyDTO;
    receiverWarehouseType: RECEIVER_WAREHOUSE_TYPE;
    reservationHorizon: number;
    consigneeContract: ConsigneeContractDTO;
}

export interface FinancialLimitDTO extends BaseAuditedDTO {
    externalId: string;
    amount: string;
    amountUsed: string;
    currency: CurrencyDTO;
    dateSet: string;
    type: string;
    amountAvailable: string;
    counterparty?: CounterpartyDTO;
    agreement?: ContractorAgreementDTO;
    contract?: ContractDTO;
    status: FINANCIAL_LIMIT_STATUS;
    limitType: FINANCIAL_TYPE;
}
