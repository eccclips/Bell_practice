import { useMemo } from 'react';

import { TableSettings } from 'root-front/types';

import { TableColumn } from '../../table';
import { getDisplayedColumns, getExtendedColumns, hasColumnSettingsChanges } from '../utils';

type Config = {
    columns: TableColumn[];
    settings: TableSettings;
};

export const useColumns = (config: Config) => {
    const { columns, settings } = config;

    const displayedColumns = useMemo(
        () => getDisplayedColumns(columns, settings.columns),
        [columns, settings.columns]
    );

    const extendedColumns = useMemo(
        () => getExtendedColumns(columns, settings.columns),
        [columns, settings.columns]
    );

    const isColumnsChanged = useMemo(
        () => hasColumnSettingsChanges(columns, extendedColumns),
        [columns, extendedColumns]
    );

    return { displayedColumns, extendedColumns, isColumnsChanged } as const;
};
