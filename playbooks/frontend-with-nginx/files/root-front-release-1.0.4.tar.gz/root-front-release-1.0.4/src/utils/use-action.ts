import { useCallback, useState } from 'react';

import { UseMutateFunction, UseMutationOptions, UseMutationResult } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { enqueueSnackbar } from 'notistack';

type UseActionConfig<Data, Error, Variables> = {
    useMutation: (
        config: UseMutationOptions<Data, Error, Variables>
    ) => UseMutationResult<Data, Error, Variables>;
    successMessage?: string;
    errorMessage?: string;
    onSuccess?: (data: Data, variables: Variables, context: any) => void | boolean;
    onError?: (error: any, variables: Variables, context: unknown) => void | boolean;
};

type UseActionSubmit<Data, Error, Variables> = (
    submitHandler: (helpers: {
        mutate: UseMutateFunction<Data, Error, Variables>;
    }) => void | { successMessage?: string; errorMessage?: string }
) => void;

export const useAction = <Data, Error, Variables>(
    config: UseActionConfig<Data, Error, Variables>
) => {
    const {
        useMutation,
        successMessage = 'Действие успешно выполнено',
        errorMessage = 'Упс! Что-то пошло не так...',
        onSuccess,
        onError,
    } = config;

    const [params, setParams] = useState(() => ({
        successMessage,
        errorMessage,
    }));

    const handleSuccess = () => {
        enqueueSnackbar({
            message: params.successMessage,
            variant: 'success',
        });
    };

    const handleError = (error: AxiosError<any>) => {
        enqueueSnackbar({
            message: error?.response?.data?.debugMessage || params.errorMessage,
            variant: 'error',
        });
    };

    const mutation = useMutation({
        onSuccess: (...args) => {
            const showNotification = onSuccess?.(...args);

            if (showNotification !== false) {
                handleSuccess();
            }
        },
        onError: (...args) => {
            const showNotification = onError?.(...args);
            if (showNotification !== false) {
                handleError(args[0] as AxiosError);
            }
        },
    });

    const submit: UseActionSubmit<Data, Error, Variables> = useCallback((submitHandler) => {
        const result = submitHandler({ mutate: mutation.mutate });
        setParams((prevParams) => ({ ...prevParams, ...(result || {}) }));
    }, []);

    return { mutation, submit, isLoading: mutation.isLoading } as const;
};
