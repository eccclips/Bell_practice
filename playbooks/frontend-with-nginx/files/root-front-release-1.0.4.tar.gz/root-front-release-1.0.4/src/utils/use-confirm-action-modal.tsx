import React, { useCallback, useMemo, useState } from 'react';

import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import { UseMutateFunction, UseMutationOptions, UseMutationResult } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { enqueueSnackbar } from 'notistack';

type ConfirmActionModalConfig<Data, Error, Variables> = {
    useMutation: (
        config: UseMutationOptions<Data, Error, Variables>
    ) => UseMutationResult<Data, Error, Variables>;
    confirmTitle?: string;
    confirmContent: React.ReactNode;
    confirmButtonText?: string;
    secondaryActionButtonText?: string;
    cancelButtonText?: string;
    successMessage?: string;
    errorMessage?: string;
    modalKey?: string;
    onSecondaryActionButtonClick?: (
        setOpened: React.Dispatch<React.SetStateAction<boolean>>
    ) => void;
    onSuccess?: (data: Data, variables: Variables, context: any) => void | boolean;
    onError?: (error: any, variables: Variables, context: unknown) => void | boolean;
};

export type OpenConfirmActionModalConfig<Data, Error, Variables> = Omit<
    ConfirmActionModalConfig<Data, Error, Variables>,
    'useMutation' | 'onSuccess' | 'onError' | 'confirmContent'
> & {
    confirmContent?: React.ReactNode;
    onSubmit: (helpers: { mutate: UseMutateFunction<Data, Error, Variables> }) => void;
    onClose?: (helpers: { mutate: UseMutateFunction<Data, Error, Variables> }) => void;
};

type ModalParams<Data, Error, Variables> = Omit<
    OpenConfirmActionModalConfig<Data, Error, Variables>,
    'onSubmit' | 'onClose'
> & {
    onSubmit?: () => void;
    onClose?: () => void;
};

export const useConfirmActionModal = <Data, Error, Variables>(
    config: ConfirmActionModalConfig<Data, Error, Variables>
) => {
    const {
        useMutation,
        confirmTitle = 'Подтвердите действие',
        confirmContent,
        confirmButtonText = 'Подтвердить',
        cancelButtonText = 'Отменить',
        successMessage = 'Действие успешно выполнено',
        errorMessage = 'Упс! Что-то пошло не так...',
        modalKey,
        onSuccess,
        onError,
        secondaryActionButtonText,
        onSecondaryActionButtonClick,
    } = config;

    const [opened, setOpened] = useState(false);

    const [modalParams, setModalParams] = useState<ModalParams<Data, Error, Variables>>(() => ({
        confirmTitle,
        confirmContent,
        confirmButtonText,
        cancelButtonText,
        successMessage,
        errorMessage,
        modalKey,
        onSubmit: () => {},
        onClose: () => {},
        secondaryActionButtonText,
        onSecondaryActionButtonClick,
    }));

    const handleSuccess = () => {
        enqueueSnackbar({
            message: modalParams.successMessage,
            variant: 'success',
        });
    };

    const handleError = (error: AxiosError<any>) => {
        enqueueSnackbar({
            message: error?.response?.data?.debugMessage || modalParams.errorMessage,
            variant: 'error',
        });
    };

    const mutation = useMutation({
        onSuccess: (...args) => {
            const showNotification = onSuccess?.(...args);

            if (showNotification !== false) {
                handleSuccess();
            }
        },
        onError: (...args) => {
            const showNotification = onError?.(...args);
            if (showNotification !== false) {
                handleError(args[0] as AxiosError);
            }
        },
    });

    const handleSubmit = () => {
        setOpened(false);
        modalParams.onSubmit();
    };

    const handleClose = () => {
        setOpened(false);
        modalParams.onClose();
    };

    const modal = useMemo(() => {
        return (
            <Dialog
                open={opened}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                key={modalParams.modalKey}
            >
                <DialogTitle id="alert-dialog-title">{modalParams.confirmTitle}</DialogTitle>
                <DialogContent>{modalParams.confirmContent}</DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} variant="outlined" color="secondary">
                        {modalParams.cancelButtonText}
                    </Button>
                    {modalParams.secondaryActionButtonText && (
                        <Button
                            onClick={() => modalParams?.onSecondaryActionButtonClick(setOpened)}
                            variant="contained"
                            color="secondary"
                        >
                            {modalParams.secondaryActionButtonText}
                        </Button>
                    )}
                    <Button onClick={handleSubmit} variant="contained" autoFocus>
                        {modalParams.confirmButtonText}
                    </Button>
                </DialogActions>
            </Dialog>
        );
    }, [opened, modalParams]);

    const openModal = useCallback(
        (params: OpenConfirmActionModalConfig<Data, Error, Variables>) => {
            setModalParams((prevParams) => ({
                ...prevParams,
                ...params,
                onSubmit: () => params.onSubmit({ mutate: mutation.mutate }),
                onClose: () => params.onClose?.({ mutate: mutation.mutate }),
            }));
            setOpened(true);
        },
        []
    );

    return { modal, openModal, mutation, isLoading: mutation.isLoading } as const;
};
