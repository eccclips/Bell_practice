import React, { useCallback, useState } from 'react';

import { Checkbox, IconButton, SvgIcon, TextField, Tooltip } from '@mui/material';
import cn from 'classnames';
import debounce from 'lodash/debounce';

import { NotificationDTO } from 'root-front/dictionaries';
import { Icons } from 'root-front/icons';

import { NotificationAction, TABS } from '../constants';

import styles from './NotificationsHeader.module.scss';

type Props = {
    selected: NotificationDTO[];
    data: NotificationDTO[];
    actions: NotificationAction[];
    currentTab: TABS;
    setSelected: React.Dispatch<React.SetStateAction<NotificationDTO[]>>;
    setSearchText: React.Dispatch<React.SetStateAction<string>>;
    setTab: (tab: TABS) => void;
    handleRefetch: () => void;
};

export const NotificationsHeader = (props: Props) => {
    const {
        selected,
        data,
        actions,
        currentTab,
        setSelected,
        setSearchText,
        setTab,
        handleRefetch,
    } = props;

    const [isSearching, setIsSearching] = useState(false);

    const [searchInputValue, setSearchInputValue] = useState('');

    const onSearchChangeDebounced = useCallback(
        debounce(
            (value: string) => {
                setSearchText(value);
            },
            500,
            {
                maxWait: 1000,
            }
        ),
        []
    );

    const onSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchInputValue(e.target.value);
        onSearchChangeDebounced(e.target.value.trim());
    };

    const handleCloseSearch = () => {
        setIsSearching(false);
        setSearchInputValue('');
        setSearchText('');
        onSearchChangeDebounced('');
    };

    if (selected.length) {
        return (
            <div className={styles.header}>
                <Checkbox
                    className={styles.header__checkbox}
                    size="small"
                    indeterminate={selected.length !== data.length}
                    checked={selected.length === data.length}
                    onChange={(e, checked) => {
                        if (checked) {
                            setSelected([...data]);
                        } else {
                            setSelected([]);
                        }
                    }}
                />
                <h1 className={cn(styles.header__title, styles.header__title_selection)}>
                    {`Выбрано: ${selected.length}`}
                </h1>
                <div className={styles.header__actions}>
                    {actions.map((action) => (
                        <Tooltip key={action.title} arrow title={action.title}>
                            <IconButton size="small" onClick={action.onAction}>
                                <SvgIcon fontSize="small">{action.icon}</SvgIcon>
                            </IconButton>
                        </Tooltip>
                    ))}
                </div>
            </div>
        );
    }

    if (isSearching) {
        return (
            <div className={styles.header}>
                <TextField
                    size="small"
                    value={searchInputValue}
                    onChange={onSearch}
                    placeholder="Поиск по уведомлениям"
                    fullWidth
                    className={styles.header__searchInput}
                />
                <IconButton size="small" onClick={handleCloseSearch}>
                    <SvgIcon fontSize="small">
                        <Icons.Close />
                    </SvgIcon>
                </IconButton>
            </div>
        );
    }

    return (
        <div className={styles.header}>
            {currentTab === TABS.ARCHIVE && (
                <IconButton size="small" onClick={() => setTab(TABS.INBOX)}>
                    <SvgIcon fontSize="small">
                        <Icons.ArrowLeft />
                    </SvgIcon>
                </IconButton>
            )}
            <h1
                className={cn(
                    styles.header__title,
                    currentTab === TABS.ARCHIVE && styles.header__title_archive
                )}
            >
                {currentTab === TABS.INBOX ? 'Уведомления' : 'Архив'}
            </h1>
            <div className={styles.header__actions}>
                <Tooltip arrow title="Обновить">
                    <IconButton size="small" onClick={handleRefetch}>
                        <SvgIcon fontSize="small">
                            <Icons.Refresh />
                        </SvgIcon>
                    </IconButton>
                </Tooltip>
                <Tooltip arrow title="Поиск">
                    <IconButton size="small" onClick={() => setIsSearching(true)}>
                        <SvgIcon fontSize="small">
                            <Icons.Search />
                        </SvgIcon>
                    </IconButton>
                </Tooltip>
                {currentTab === TABS.INBOX && (
                    <Tooltip arrow title="Архив">
                        <IconButton size="small" onClick={() => setTab(TABS.ARCHIVE)}>
                            <SvgIcon fontSize="small">
                                <Icons.Inventory2Icon />
                            </SvgIcon>
                        </IconButton>
                    </Tooltip>
                )}
            </div>
        </div>
    );
};

export default React.memo(NotificationsHeader);
