export type MinifiedColumn = {
    key: string;
    disabled: boolean;
    resizeWidth?: number;
    children?: MinifiedColumn[];
};

export type TableSettings = {
    columns?: MinifiedColumn[];
    [key: string]: any;
};
