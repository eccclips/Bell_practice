import React, { useCallback } from 'react';

import { Control, UseFormSetValue } from 'react-hook-form';

import { Fields } from '../../../../../fields';

type TextFieldProps<T> = {
    control: Control<T>;
    name: any;
    label: string;
    placeholder?: string;
    inputMode?: 'decimal' | 'numeric';
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
    setValue: UseFormSetValue<Record<string, any>>;
};

const TextField = <T,>(props: TextFieldProps<T>) => {
    const { control, name, label, placeholder, inputMode, onChange, setValue } = props;

    const handleChange = useCallback(
        (e: React.ChangeEvent<HTMLInputElement>) => {
            onChange?.(e, setValue);
        },
        [onChange, setValue]
    );

    const id = `filter__${name}`;

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <Fields.TextField
                id={id}
                control={control}
                name={name}
                placeholder={typeof placeholder === 'string' ? placeholder : 'Введите значение'}
                size="small"
                type={inputMode ? 'number' : 'text'}
                inputMode={inputMode}
                onChange={handleChange}
            />
        </>
    );
};

export default React.memo(TextField);
