import React from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';

import { Fields } from '../../../../../../fields';

type SaveFiltersModalProps = {
    opened: boolean;
    onClose: () => void;
    onSubmit: (filterName: string) => void;
};

const DEFAULT_VALUES = { filterName: '' };

const VALIDATION_SCHEMA = Yup.object({
    filterName: Yup.string().required('Обязательно'),
});

const SaveFiltersModal = (props: SaveFiltersModalProps) => {
    const { opened, onClose, onSubmit } = props;

    const { control, handleSubmit, reset } = useForm({
        defaultValues: DEFAULT_VALUES,
        resolver: yupResolver(VALIDATION_SCHEMA),
        shouldFocusError: true,
        reValidateMode: 'onChange',
    });

    const submitHandler = (data: typeof DEFAULT_VALUES) => {
        onSubmit(data.filterName);
    };

    return (
        <Dialog
            open={opened}
            onClose={onClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="sm"
            fullWidth
            TransitionProps={{
                onExited: () => {
                    reset({ ...DEFAULT_VALUES });
                },
            }}
        >
            <DialogTitle>Сохранить фильтры</DialogTitle>
            <DialogContent>
                <Fields.TextField
                    control={control}
                    name="filterName"
                    placeholder="Название фильтра"
                    fullWidth
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                            e.stopPropagation();
                            e.preventDefault();
                            handleSubmit(submitHandler)();
                        }
                    }}
                />
            </DialogContent>
            <DialogActions>
                <Button variant="outlined" color="secondary" onClick={onClose}>
                    Отменить
                </Button>
                <Button variant="contained" type="button" onClick={handleSubmit(submitHandler)}>
                    Сохранить
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default React.memo(SaveFiltersModal);
