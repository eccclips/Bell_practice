export enum MARK_NOTIFICATION_ACTION {
    READ = 'READ',
    UNREAD = 'UNREAD',
}

export enum TABS {
    INBOX = 'inbox',
    ARCHIVE = 'archive',
}

export enum FILTER_TABS {
    ALL = 'ALL',
    UNREAD = 'UNREAD',
    READ = 'READ',
}

export type NotificationAction = {
    title: string;
    icon: JSX.Element;
    onAction: () => void;
};

export const getIsReadFilterValue = (filterTab: FILTER_TABS): boolean | null => {
    if (filterTab === FILTER_TABS.ALL) {
        return null;
    }
    if (filterTab === FILTER_TABS.UNREAD) {
        return false;
    }

    return true;
};
