import { BASE_STATUS, CounterpartyDTO, ProductDTO, WarehouseDTO } from 'root-front/dictionaries';
import { BaseAuditedDTO } from 'root-front/interfaces';

export interface SupplyScheduleItemDTO extends BaseAuditedDTO {
    externalId: string;
    orderLineNumber: number;
    product: ProductDTO;
    quantity: number;
    warehouse: WarehouseDTO;
    plannedSupplyDate: string;
    status: BASE_STATUS;
    supplyScheduleId: number;
}

export interface SupplyScheduleDTO extends BaseAuditedDTO {
    externalId: string;
    orderNumber: string;
    supplier: CounterpartyDTO;
    shipper: CounterpartyDTO;
    supplyPeriod: string;
    status: BASE_STATUS;
}

export interface ShipperDTO {
    id: number;
    inforLnId: string;
    isDeleted: boolean;
    name: string;
    sourceCode: string;
}

export interface SupplierDTO extends ShipperDTO {}

export interface ProductsDTO extends ProductDTO {
    characteristic: string;
}

export interface SupplyShipmentDTO extends BaseAuditedDTO {
    externalId: string;
    shipmentDocId: string;
    shipmentDocNumber: string;
    shipmentDocCreateDate: string;
    shipmentNumber: string;
    actualShipmentDate: string;
    plannedSupplyDate: string;
    actualSupplyDate: string;
    shipper: ShipperDTO;
    supplier: SupplierDTO;
    consigneeWarehouse: WarehouseDTO;
    arrivalDocId: string;
    arrivalDocNumber: string;
    status: BASE_STATUS;
}

export interface SupplyShipmentItemDTO extends BaseAuditedDTO {
    externalId: string;
    supplyShipmentId: number;
    supplyShipmentLineNumber: number;
    product: ProductsDTO;
    characteristic: string;
    quantity: number;
    status: BASE_STATUS;
}
