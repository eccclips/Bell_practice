import { atom, useRecoilValue } from 'recoil';

import { localStorageEffect } from 'root-front/utils';

export enum THEME {
    DARK = 'DARK',
    LIGHT = 'LIGHT',
    DEFAULT = 'DEFAULT',
}

export const themeState = atom<THEME>({
    key: '@root/theme',
    default: THEME.DEFAULT,
    effects: [localStorageEffect('@root/theme')],
});

export const useThemeState = () => {
    return useRecoilValue(themeState);
};
