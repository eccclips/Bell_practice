import React from 'react';

import { SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';

import styles from './FormErrorHelper.module.scss';

type FormErrorHelperProps = {
    message: React.ReactNode;
};

const FormErrorHelper = (props: FormErrorHelperProps) => {
    const { message } = props;

    return (
        <span className={styles.container}>
            <SvgIcon className={styles.container__icon}>
                <Icons.Alert />
            </SvgIcon>
            <span className={styles.container__message}>{message}</span>
        </span>
    );
};

export default React.memo(FormErrorHelper);
