import React, { useMemo } from 'react';

import { Breadcrumbs as BreadcrumbsCore, SvgIcon } from '@mui/material';
import { Link, useLocation, useSearchParams } from 'react-router-dom';

import { Icons } from 'root-front/icons';
import { useDocumentHistoryState } from 'root-front/store';

import { BreadcrumbsProps } from './types';
import { getCrumbs } from './utils';

import styles from './Breadcrumbs.module.scss';

const Breadcrumbs = (props: BreadcrumbsProps) => {
    const { breadcrumbs } = props;

    const [searchParams] = useSearchParams();
    const historyRecord = useDocumentHistoryState();

    const location = useLocation();

    const crumbs = useMemo(
        () => getCrumbs(breadcrumbs, location.pathname),
        [breadcrumbs, location.pathname]
    );

    return (
        <BreadcrumbsCore
            separator={
                <SvgIcon width="20px" height="20px" className={styles.breadcrumbs__icon}>
                    <Icons.ArrowRight />
                </SvgIcon>
            }
            aria-label="breadcrumb"
            className={styles.breadcrumbs}
        >
            {crumbs.map(({ breadcrumb, match, withHistory }, index) =>
                index < crumbs.length - 1 ? (
                    <Link
                        key={match.pathname}
                        to={match.pathname}
                        className={styles.breadcrumbs__link}
                    >
                        {typeof breadcrumb === 'function'
                            ? breadcrumb(match, searchParams)
                            : breadcrumb}
                        {!!withHistory && !!historyRecord && ' (История)'}
                    </Link>
                ) : (
                    <span key={match.pathname} className={styles.breadcrumbs__item}>
                        {typeof breadcrumb === 'function'
                            ? breadcrumb(match, searchParams)
                            : breadcrumb}
                        {!!withHistory && !!historyRecord && ' (История)'}
                    </span>
                )
            )}
        </BreadcrumbsCore>
    );
};

export default React.memo(Breadcrumbs);
