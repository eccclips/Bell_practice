import { DateView } from '@mui/x-date-pickers';
import { UseFormSetValue } from 'react-hook-form';

import { SelectOption } from 'root-front/components';

import { QuerySelectProps, QuerySelectWithModalProps } from '../../query-select';

type TableTextFilterType = {
    type: 'text';
    placeholder?: string;
    inputMode?: 'decimal' | 'numeric';
};

type TableSelectFilterType = {
    type: 'select';
    placeholder?: string;
    options?: SelectOption[];
    multiple?: boolean;
};

type TableDateFilterType = {
    type: 'date' | 'date-range';
    datePickerView?: DateView;
};

type TableBooleanFilterType = {
    type: 'boolean';
    placeholder?: string;
};

type TableQuerySelectFilterType = {
    type: 'query-select';
    query: QuerySelectProps<any>['query'];
    placeholder?: string;
    multiple?: boolean;
    saveSearchInputValue?: boolean;
    getOptionFromData?: QuerySelectProps<any>['getOptionFromData'];
    getOptionFromValue?: QuerySelectProps<any>['getOptionFromValue'];
    getOptionDisabled?: QuerySelectProps<any>['getOptionDisabled'];
    groupBy?: QuerySelectProps<any>['groupBy'];
};

type TableQuerySelectWithModalFilterType = {
    type: 'query-select-with-modal';
    multiple?: boolean;
    placeholder?: string;
    modalTableName: string;
    query: QuerySelectWithModalProps<any, any, any>['query'];
    queryParams?: QuerySelectWithModalProps<any, any, any>['queryParams'];
    defaultParams?: QuerySelectWithModalProps<any, any, any>['defaultParams'];
    columns: QuerySelectWithModalProps<any, any, any>['columns'];
    slots?: QuerySelectWithModalProps<any, any, any>['slots'];
    mode?: QuerySelectWithModalProps<any, any, any>['mode'];
    searchable?: boolean;
    getOptionFromData: QuerySelectWithModalProps<any, any, any>['getOptionFromData'];
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
};

type TableNumberRangeFilterType = {
    type: 'number-range';
    placeholder?: string;
    inputMode?: 'decimal' | 'numeric';
};

type TableFilterType =
    | TableTextFilterType
    | TableSelectFilterType
    | TableDateFilterType
    | TableBooleanFilterType
    | TableQuerySelectFilterType
    | TableNumberRangeFilterType
    | TableQuerySelectWithModalFilterType;

export type TableFilter = {
    name: string;
    label: string;
    getRequestFilter?: (value: any) => any;
    isEqualValues?: (a: any, b: any) => boolean;
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
} & TableFilterType;

export type SavedFilter = {
    uid: string;
    name: string;
    values: Record<string, any>;
};
