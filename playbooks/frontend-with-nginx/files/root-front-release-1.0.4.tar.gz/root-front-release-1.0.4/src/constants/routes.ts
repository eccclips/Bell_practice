export enum LINK_TYPE {
    WAREHOUSE = 'WAREHOUSE',
    PRODUCT = 'PRODUCT',
}

export const LINK_TYPE_MAP = {
    [LINK_TYPE.WAREHOUSE]: { path: '/warehouse/warehouses' },
    [LINK_TYPE.PRODUCT]: { path: '/product/positions' },
};
