import * as Yup from 'yup';

export type FormData = {
    username: string;
    password: string;
    closeOtherSessions: boolean;
};

export const DEFAULT_VALUES: FormData = {
    username: '',
    password: '',
    closeOtherSessions: false,
};

export const VALIDATION_SCHEMA = Yup.object({
    username: Yup.string().required('Обязательно для заполнения'),
    password: Yup.string().required('Обязательно для заполнения'),
    closeOtherSessions: Yup.boolean(),
});
