import React, { useMemo, useState } from 'react';

import { SvgIcon } from '@mui/material';

import { MenuButton, MenuButtonOption } from 'root-front/components';
import { Icons } from 'root-front/icons';
import { useTokenPayloadState } from 'root-front/store';

import LogoutIcon from 'src/assets/icons/logout.svg';
import { logout } from 'src/utils/auth';

import { Bookmarks } from '../../bookmarks';
import { Settings } from '../../settings';

import styles from './User.module.scss';

const User = () => {
    const tokenPayload = useTokenPayloadState();

    const [settingsOpened, setSettingsOpened] = useState(false);
    const [bookmarksOpened, setBookmarksOpened] = useState(false);

    const handleLogout = () => {
        logout();
    };

    const handleOpenBookmarks = (closeMenu: () => void) => {
        closeMenu();
        setBookmarksOpened(true);
    };

    const handleOpenSettings = (closeMenu: () => void) => {
        closeMenu();
        setSettingsOpened(true);
    };

    const handleCloseBookmarks = () => {
        setBookmarksOpened(false);
    };

    const handleCloseSettings = () => {
        setSettingsOpened(false);
    };

    const menuOptions = useMemo<MenuButtonOption[]>(
        () => [
            { text: 'Настройки', icon: <Icons.Settings />, onClick: handleOpenSettings },
            { text: 'Закладки', icon: <Icons.Bookmark />, onClick: handleOpenBookmarks },
            { text: 'Выйти', icon: <LogoutIcon />, onClick: handleLogout },
        ],
        []
    );

    return (
        <div className={styles.user}>
            <div className={styles.user__avatar}>
                <MenuButton
                    componentType="icon-button"
                    menuOptions={menuOptions}
                    className={styles.user__avatar}
                >
                    <SvgIcon>
                        <Icons.User />
                    </SvgIcon>
                </MenuButton>
            </div>
            <div className={styles.user__info}>
                <div className={styles.user__name}>{tokenPayload.name}</div>
                <div className={styles.user__email}>{tokenPayload.email}</div>
            </div>
            <Settings open={settingsOpened} onClose={handleCloseSettings} />
            <Bookmarks open={bookmarksOpened} onClose={handleCloseBookmarks} />
        </div>
    );
};

export default React.memo(User);
