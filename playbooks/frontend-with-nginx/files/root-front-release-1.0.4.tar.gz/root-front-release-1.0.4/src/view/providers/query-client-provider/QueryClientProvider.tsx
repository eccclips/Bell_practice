import React, { useRef, useState } from 'react';

import {
    MutationCache,
    QueryCache,
    QueryClient,
    QueryClientProvider as QueryClientProviderCore,
} from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { enqueueSnackbar } from 'notistack';
import { useRecoilState, useSetRecoilState } from 'recoil';

import {
    accessTokenState,
    authInfoState,
    refreshTokenState,
    userPermissionsState,
} from 'root-front/store';
import { useEvent } from 'root-front/utils';

import { logout, refreshToken } from '../../../utils/auth';

export const QueryClientProvider = ({ children }: React.PropsWithChildren) => {
    const setAccessToken = useSetRecoilState(accessTokenState);
    const setUserPermissions = useSetRecoilState(userPermissionsState);
    const [refreshTokenValue, setRefreshToken] = useRecoilState(refreshTokenState);
    const setAuthInfo = useSetRecoilState(authInfoState);

    const isRefreshingTokenRef = useRef(false);

    const handleRefreshToken = useEvent(async () => {
        if (isRefreshingTokenRef.current) {
            return;
        }
        try {
            isRefreshingTokenRef.current = true;
            const result = await refreshToken(refreshTokenValue);
            const { data } = result;
            setAccessToken(data.accessToken);
            setRefreshToken(data.refreshToken);
            setUserPermissions(data.privileges);
            setAuthInfo({
                scope: data.scope,
                expiresIn: data.expiresIn,
                refreshExpiresIn: data.refreshExpiresIn,
                tokenType: data.tokenType,
                notBeforePolicy: data.notBeforePolicy,
                userSessionTimeOut: data.userSessionTimeOut,
            });
            isRefreshingTokenRef.current = false;
        } catch (e) {
            isRefreshingTokenRef.current = false;
            logout();
        }
    });

    const [mutationCache] = useState(
        () =>
            new MutationCache({
                onError: (error: AxiosError, _variables, _context, mutation) => {
                    if (error.response?.status === 403) {
                        logout();
                        return;
                    }

                    if (mutation.options.onError) {
                        return;
                    }

                    enqueueSnackbar({ message: 'Упс! Что-то пошло не так', variant: 'error' });
                },
            })
    );

    const [queryCache] = useState(
        () =>
            new QueryCache({
                onError: (_error, query) => {
                    const error = _error as AxiosError<any>;

                    if (!query.options.meta?.disableDefaultErrorHandler) {
                        enqueueSnackbar({
                            message:
                                error?.response?.data?.debugMessage || 'Упс! Что-то пошло не так',
                            variant: 'error',
                        });
                    }
                },
            })
    );

    const [queryClient] = useState(
        () =>
            new QueryClient({
                defaultOptions: {
                    queries: {
                        retry: (count, error: AxiosError) => {
                            if (error.response?.status === 403) {
                                logout();
                                return false;
                            }
                            if (error.response?.status === 401) {
                                handleRefreshToken();
                                return true;
                            }
                            if (count > 3) {
                                return false;
                            }

                            return true;
                        },
                        keepPreviousData: true,
                        refetchOnWindowFocus: false,
                    },
                    mutations: {
                        retry: (count, error: AxiosError) => {
                            if (
                                error.response?.status === 401 &&
                                !error.config?.url?.endsWith('/auth/login')
                            ) {
                                handleRefreshToken();
                                return true;
                            }

                            return false;
                        },
                    },
                },
                mutationCache,
                queryCache,
            })
    );

    return <QueryClientProviderCore client={queryClient}>{children}</QueryClientProviderCore>;
};
