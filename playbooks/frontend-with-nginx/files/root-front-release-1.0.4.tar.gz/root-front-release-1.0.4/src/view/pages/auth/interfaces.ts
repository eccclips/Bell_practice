export interface LoginDTO {
    username: string;
    password: string;
    workplaceFingerprint: string;
    closeOtherSessions: boolean;
}
