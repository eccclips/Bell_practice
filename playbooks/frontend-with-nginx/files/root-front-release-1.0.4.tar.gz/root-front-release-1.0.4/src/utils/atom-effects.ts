import { AtomEffect } from 'recoil';

export const localStorageEffect: <T>(key: string, autoInit?: boolean) => AtomEffect<T> =
    (key, autoInit = true) =>
    ({ setSelf, onSet }) => {
        const savedValue = localStorage.getItem(key);
        if (autoInit && savedValue != null) {
            setSelf(JSON.parse(savedValue));
        }

        onSet((newValue, _, isReset) => {
            if (isReset) {
                localStorage.removeItem(key);
            } else {
                localStorage.setItem(key, JSON.stringify(newValue));
            }
        });
    };
