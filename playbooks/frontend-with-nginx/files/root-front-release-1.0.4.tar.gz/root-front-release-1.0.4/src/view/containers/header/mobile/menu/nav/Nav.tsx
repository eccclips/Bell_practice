import React, { useEffect, useRef } from 'react';

import { Stack } from '@mui/material';
import { useLocation } from 'react-router-dom';

import { useNavigationTabs } from 'src/routes';
import { useIsMenuExpanded } from 'src/store/settings';

import { CollapsableList } from '../../../components/collapsable-list';
import { NavItem } from '../../../components/nav-item';

import styles from './Nav.module.scss';

export const Nav = React.memo(() => {
    const location = useLocation();
    const [isExpanded, setIsExpanded] = useIsMenuExpanded();
    const tabs = useNavigationTabs();

    const isFirstRenderRef = useRef(true);

    useEffect(() => {
        if (isFirstRenderRef.current) {
            isFirstRenderRef.current = false;
            return;
        }

        if (isExpanded) {
            setIsExpanded(false);
        }
    }, [location]);

    return (
        <nav className={styles.nav}>
            <div className={styles.nav__inner}>
                <Stack gap="4px">
                    {tabs.map((tab) => {
                        if (tab.children?.length) {
                            return <CollapsableList key={tab.name} tab={tab} isMobile />;
                        }
                        return (
                            <NavItem
                                key={tab.name}
                                text={tab.name}
                                to={tab.path}
                                type="link"
                                Icon={tab.Icon}
                                isMobile
                            />
                        );
                    })}
                </Stack>
            </div>
        </nav>
    );
});
