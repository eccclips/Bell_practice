import React, { useEffect, useMemo } from 'react';

import {
    StyledEngineProvider,
    ThemeProvider as ThemeProviderCore,
    useMediaQuery,
} from '@mui/material';

import { THEME, useThemeState } from 'root-front/store';

import { create } from './theme';

export const ThemeProvider = ({ children }: React.PropsWithChildren) => {
    const prefersDarkMode = useMediaQuery('(prefers-color-scheme: dark)');
    const currentTheme = useThemeState();

    const colorTheme = useMemo(() => {
        const preferredTheme = prefersDarkMode ? 'dark' : 'light';
        return create(
            currentTheme === THEME.DEFAULT
                ? preferredTheme
                : (currentTheme.toLocaleLowerCase() as 'light' | 'dark')
        );
    }, [currentTheme, prefersDarkMode]);

    const setThemeMode = (isDark: boolean) => {
        if (isDark) {
            document.body.classList.add('mode-dark');
            document.querySelector('meta[name=theme-color]').setAttribute('content', '#202124');
        } else {
            document.body.classList.remove('mode-dark');
            document.querySelector('meta[name=theme-color]').setAttribute('content', '#FFFFFF');
        }
    };

    useEffect(() => {
        if (currentTheme !== THEME.DEFAULT) {
            return;
        }
        setThemeMode(prefersDarkMode);
    }, [prefersDarkMode]);

    useEffect(() => {
        if (currentTheme === THEME.DEFAULT) {
            return setThemeMode(prefersDarkMode);
        }
        setThemeMode(currentTheme === THEME.DARK);
    }, [currentTheme]);

    return (
        <StyledEngineProvider injectFirst>
            <ThemeProviderCore theme={colorTheme}>{children}</ThemeProviderCore>
        </StyledEngineProvider>
    );
};
