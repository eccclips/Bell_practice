import React from 'react';

import { Outlet } from 'react-router-dom';

import { PERMISSIONS, useUserPermissionsState } from 'root-front/store';
import { hasPermissions } from 'root-front/utils';

import { logout } from '../../../utils/auth';

type Props = {
    permissions: PERMISSIONS[];
    method?: 'every' | 'some';
};

const PermissionRoute = (props: Props) => {
    const { permissions, method = 'some' } = props;
    const userPermissions = useUserPermissionsState();
    const isAllowed = hasPermissions(userPermissions, permissions, method);

    if (isAllowed) {
        return <Outlet />;
    }

    logout();
    return null;
};

export default React.memo(PermissionRoute);
