import React, { useId, useMemo } from 'react';

import { typedMemo } from 'root-front/utils';

import errorPageImageUrl from '../../../assets/error-page.svg?url';
import emptyListUrl from '../../../assets/icons/empty-list.svg?url';
import { LoaderOverlay } from '../loader-overlay';
import { CollapsableList } from './collapsable-list';
import { InfoGridConfig } from './types';

import styles from './InfoGrid.module.scss';

type InfoGridProps<DataType> = {
    config: InfoGridConfig<DataType>;
    data: DataType;
    isLoading?: boolean;
    isRefetching?: boolean;
    isError?: boolean;
};

const InfoGrid = <DataType,>(props: InfoGridProps<DataType>) => {
    const { data, config, isLoading, isRefetching, isError = false } = props;

    const infoId = useId();

    const isEmpty = isLoading === false && !isError && Object.keys(data).length === 0;

    const renderInfo = useMemo(() => {
        const needRenderList = !isLoading && !isError && !isEmpty;

        if (needRenderList) {
            return config.map((groupConfig, groupIndex) => (
                <div key={`${infoId}:${groupIndex}`} className={styles.infoGrid__item}>
                    {groupConfig.map(({ title, itemsConfig }) => (
                        <CollapsableList<DataType | Record<string, any>>
                            key={`${infoId}:${title}`}
                            title={title}
                            data={data}
                            itemsConfig={
                                typeof itemsConfig === 'function' ? itemsConfig(data) : itemsConfig
                            }
                        />
                    ))}
                </div>
            ));
        }

        return null;
    }, [config, data, isLoading, isError, isEmpty]);

    return (
        <div className={styles.infoGrid}>
            <div className={styles.infoGrid__inner}>
                {renderInfo}

                {(isLoading || isRefetching) && <LoaderOverlay />}

                {isEmpty && (
                    <div className={styles.infoGrid__overflow}>
                        <img src={emptyListUrl} alt="Данных не найдено" />
                        <span>Данных не найдено</span>
                    </div>
                )}

                {isError && (
                    <div className={styles.infoGrid__overflow}>
                        <img
                            src={errorPageImageUrl}
                            className={styles.infoGrid__overflow__error}
                            alt="О нет! Что-то пошло не так"
                        />
                        <span>О нет! Что-то пошло не так</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default typedMemo(InfoGrid);
