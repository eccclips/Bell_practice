import React, { useEffect, useMemo } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { Button } from '@mui/material';
import { useForm } from 'react-hook-form';

import { defaultStyles } from 'root-front/styles';

import { DEFAULT_VALUES, formulaValidationSchema } from '../constants';
import { Formula, FormulaConstructorFormProps } from '../types';
import FormulaConstructor from './FormulaConstructor';

const FormulaConstructorForm = (props: FormulaConstructorFormProps) => {
    const { defaultValues: defaultValuesProp, onSubmit: onSubmitProp, onClose } = props;

    const defaultValues = useMemo(
        () => (defaultValuesProp ? { formula: defaultValuesProp } : { formula: DEFAULT_VALUES }),
        [defaultValuesProp]
    );

    const { control, setValue, getValues, handleSubmit, reset } = useForm<{ formula: Formula }>({
        defaultValues,
        reValidateMode: 'onChange',
        shouldFocusError: true,
        resolver: yupResolver(formulaValidationSchema) as any,
    });

    const onSubmit = () => {
        handleSubmit((data: { formula: Formula }) => {
            onSubmitProp?.(data.formula);
        })();
    };

    useEffect(() => {
        if (defaultValuesProp) {
            reset(defaultValues);
        }
    }, [defaultValuesProp]);

    return (
        <FormulaConstructor
            name="formula"
            control={control}
            setValue={setValue}
            getValues={getValues}
        >
            <div className={defaultStyles.header__actions}>
                <Button variant="outlined" color="secondary" onClick={onClose}>
                    Отменить
                </Button>
                <Button variant="contained" onClick={onSubmit}>
                    Сохранить
                </Button>
            </div>
        </FormulaConstructor>
    );
};

export default React.memo(FormulaConstructorForm);
