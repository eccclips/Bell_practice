import React from 'react';

import cn from 'classnames';

import emptyListUrl from '../../../assets/icons/empty-list.svg?url';

import styles from './EmptyPage.module.scss';

interface Props {
    text?: string;
    className?: string;
    children?: React.ReactNode;
}

const EmptyPage = (props: Props) => {
    const { text = 'Данных не найдено', className, children } = props;

    return (
        <div className={cn(styles.page, className)}>
            <img src={emptyListUrl} alt={text} />
            <span>{text}</span>
            {children}
        </div>
    );
};

export default React.memo(EmptyPage);
