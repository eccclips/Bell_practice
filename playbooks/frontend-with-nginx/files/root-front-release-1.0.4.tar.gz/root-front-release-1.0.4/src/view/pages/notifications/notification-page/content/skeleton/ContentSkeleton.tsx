import React from 'react';

import { Skeleton } from '@mui/material';

const ContentSkeleton = () => {
    return (
        <div>
            <Skeleton width="80%" height="32px"></Skeleton>
            <Skeleton width="70%" height="32px"></Skeleton>
            <Skeleton width="60%" height="32px"></Skeleton>
            <Skeleton width="50%" height="32px"></Skeleton>
            <Skeleton width="60%" height="32px"></Skeleton>
            <Skeleton width="80%" height="32px"></Skeleton>
        </div>
    );
};

export default React.memo(ContentSkeleton);
