import { BusinessDomainDTO, WarehouseDocumentDTO } from 'root-front/dictionaries';
import { BaseAuditedDTO } from 'root-front/interfaces';

import { UserInfoUDB } from '../../interfaces';
import {
    ASSEMBLY_PLAN_REMAINDER_STATUS,
    ASSEMBLY_PLAN_REMAINDER_TYPE,
    BASE_STATUS,
    GUARANTEED_RESERVE_STATUS,
    GUARANTEED_RESERVE_TYPE,
    GUARANTEED_STORAGE_CALC_STATUS,
    NORMATIVE_STOCK_RESERVE_TYPE,
    PROCESSING_TYPE,
    WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO,
    WAREHOUSE_ORDER_TYPE_STATUS,
    WAREHOUSE_STATUS,
    WARRANTY_SERVICE_STATISTICS_STATUS,
} from '../constants';
import { AvailabilityCategoryDTO } from './availability';
import { ActivitiesDTO, AgreementTypeDTO, CounterpartyDTO } from './counterparty';
import { ProductDTO, SupplyPropertyDTO } from './product';
import { ReferenceDTO } from './reference';

export interface WarehouseGroupDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    code: string;
    name: string;
}

export interface WarehouseDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    externalWarehouseId: number;
    warehouseCode1c: number;
    status: WAREHOUSE_STATUS;
    fullWarehouseName: string;
    shortWarehouseName: string;
    standardConfiguration: number;
    acceptanceNormative: number;
    crossDockingNormative: number;
    isShipmentWarehouse: boolean;
    b2bPortalId: number;
    b2bPortalForOursId: number;
    inforLnId: number;
    cutOffInMinutes: number;
    cutOffTaskUnloading: boolean;
    noReservation: boolean;
    warehousePrefix: string;
    workThroughShipmentTasks: boolean;
    isTransitWarehouse: boolean;
    timeZome: number;
    dateStart: string;
    dateEnd: string;
    warehouseGroup: WarehouseGroupDTO;
    shipmentWarehouse: boolean;
    transitWarehouse: boolean;
    code1c: string;
}

export interface OrderGroupDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    name: string;
    responsible: string;
    status: BASE_STATUS;
}

export interface WarehouseOrderTypeDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    code: string;
    name: string;
    status: WAREHOUSE_ORDER_TYPE_STATUS;
    directionOfActivity: string;
    agreementType: AgreementTypeDTO;
    priority: number;
    notProcess: boolean;
    checkCreditLimits: boolean;
    settingPriorityChangeRule: boolean;
    agingPeriod: number;
    resourceAvailabilityCategory: AvailabilityCategoryDTO;
    reserveAvailabilityCategory: AvailabilityCategoryDTO;
    orderGroup: OrderGroupDTO;
    predefinedSupplyChain: boolean;
    partiesDivision: boolean;
    automaticGenerationZno: WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO;
    interchangeable: boolean;
    publicationTimeZno: number;
    publicationTimeZnoOptionally: number;
    deadlineExecutionOrder: number;
    businessDomain: ActivitiesDTO;
    salesForecastType: BusinessDomainDTO;
    processingType: PROCESSING_TYPE;
    sendRequestCloseStatus: boolean;
    retrainingSupplyChain: boolean;
    finLimitControl: boolean;
    serviceRate: number;
}

export interface AssemblyPlanRemainderDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    type: ASSEMBLY_PLAN_REMAINDER_TYPE;
    month: number;
    article: string;
    quantity: number;
    subcontractModelItemId: number;
    repairKitItemId: number;
    name: string;
    warehouse: WarehouseDTO;
    product: ProductDTO;
    status: ASSEMBLY_PLAN_REMAINDER_STATUS;
}

export interface GuaranteedReserveDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    type: GUARANTEED_RESERVE_TYPE;
    article: string;
    quantity: number;
    status: GUARANTEED_RESERVE_STATUS;
    productId: number;
    warehouseId: number;
    comment: string;
}

export interface GuaranteedStorageCalcDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    guaranteedParams: GuaranteedReserveDTO;
    warehouse: WarehouseDTO;
    status: GUARANTEED_STORAGE_CALC_STATUS;
    percent: string;
    priority: number;
}

export interface ProductGroupCoefDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    guaranteedParams: GuaranteedReserveDTO;
    index: number;
    productGroup: ProductDTO;
}

export interface DeliverySignCoefDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    guaranteedParams: GuaranteedReserveDTO;
    index: number;
    code: number;
    supplyProperty: SupplyPropertyDTO;
}

export interface SupplierCoefDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    guaranteedParams: GuaranteedReserveDTO;
    counterparty: CounterpartyDTO;
    index: number;
}

export interface ExpertAssessmentDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    guaranteedParams: GuaranteedReserveDTO;
    quantity: number;
    product: ProductDTO;
}

export interface WarrantyServiceStatisticsDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    article: string;
    name: string;
    quantity: number;
    status: WARRANTY_SERVICE_STATISTICS_STATUS;
    product: ProductDTO;
    responsible: string;
}

export interface WarehouseStockBalanceDTO extends BaseAuditedDTO {
    documentId: string;
    unitOfMeasurementId: number;
    unitOfMeasurementCode: string;
    unitOfMeasurementFullName: string;
    productId: number;
    productName: string;
    article: string;
    characteristic: string;
    quantityTotal: string;
    quantityAvailable: string;
    quantityReserved: string;
    quantityReservedCd: string;
    insuranceStockReserve: string;
    normativeStockReserve: string;
    suppliersZnpNotAccepted: string;
    rejectedIncomingMovements: string;
    sourceCreatedDate: string;
    sourceLastModifiedDate: string;
    isCrossDocking: boolean;
    storagePositionNumber: string;
    agreementId: number;
    agreementCode: string;
    status: BASE_STATUS;
    warehouse: WarehouseDTO;
    product: ProductDTO;
    unitOfMeasurement: ReferenceDTO;
    currentBalance: string;
}

export interface NormativeStockReserveDTO extends BaseAuditedDTO {
    type: NORMATIVE_STOCK_RESERVE_TYPE;
    month: string;
    warehouse: WarehouseDTO;
    sourceCreatedDate: string;
    sourceLastModifiedDate: string;
}

export interface NormativeStockReserveItemDTO extends BaseAuditedDTO {
    normativeStockReserve: NormativeStockReserveDTO;
    product: ProductDTO;
    quantity: number;
    article: string;
    status: BASE_STATUS;
}

export interface WarehouseDocumentGroupsDTO {
    isDeleted: boolean;
    disassembles: WarehouseDocumentDTO[];
    movements: WarehouseDocumentDTO[];
    reservationCancels: WarehouseDocumentDTO[];
    reservations: WarehouseDocumentDTO[];
    sales: WarehouseDocumentDTO[];
    warehouseOrders: WarehouseDocumentDTO[];
    znoRequests: WarehouseDocumentDTO[];
    znos: WarehouseDocumentDTO[];
}
