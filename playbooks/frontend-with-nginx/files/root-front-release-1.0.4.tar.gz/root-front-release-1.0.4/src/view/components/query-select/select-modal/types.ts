import { UseQueryResult } from '@tanstack/react-query';

import { ResponseDTO } from 'root-front/interfaces';
import { ListRequestParams } from 'root-front/types';

import { SearchParams } from '../../query-table';
import { TableColumn, TableData } from '../../table';

export enum SELECT_MODE {
    SELECT = 'select',
    APPEND = 'append',
}

export type QuerySelectModalProps<
    Data,
    QueryParams extends Record<string, any>,
    Multiple extends boolean = false,
> = {
    opened: boolean;
    onClose: () => void;
    value: Multiple extends true ? Data[] : Data;
    query: (
        params: ListRequestParams<any, QueryParams & { search?: string }>
    ) => UseQueryResult<ResponseDTO<Data[]>>;
    columns: TableColumn<TableData<Data>>[];
    name: string;
    title?: string;
    defaultParams?: SearchParams;
    queryParams?: QueryParams;
    pageable?: boolean;
    slots?: {
        filters?: JSX.Element;
        filterBlock?: JSX.Element;
        settingsStart?: JSX.Element;
    };
    dataKey?: string;
    multiple?: Multiple;
    mode?: Multiple extends true ? SELECT_MODE | `${SELECT_MODE}` : never;
    searchable?: boolean;
    searchPlaceholder?: string;
    isSubmitting?: boolean;
    onChange?: (value: Multiple extends true ? Data[] : Data) => void;
    onExited?: () => void;
    getRowSelectionDisabled?: Multiple extends true ? (row: Data) => boolean : never;
    modalPaperClassName?: string;
    isSubmitDisabled?: boolean;
};
