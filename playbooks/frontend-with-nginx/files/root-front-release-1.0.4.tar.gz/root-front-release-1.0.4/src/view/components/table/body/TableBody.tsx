import React, { useMemo } from 'react';

import { typedMemo } from 'root-front/utils';

import { TableColumn, TableData, TableGroupModel } from '../types';
import { GroupedRow } from './grouped-row';
import { TableRow } from './row';
import { getRowsModel } from './utils';

type TableBodyProps<Data = any> = {
    data: TableData<Data>[];
    columns: TableColumn<TableData<Data>>[];
    dataKey: string;
    checkboxSelection?: boolean;
    selectedRows?: TableData<Data>[];
    groupModel?: TableGroupModel<Data>;
    expandable?: boolean;
    renderExpandedContent?: (row: TableData<Data>) => JSX.Element;
    onRowClick?: (row: TableData<Data>) => void;
    onSelectRow?: (row: TableData<Data>) => void;
    getRowSelectionDisabled?: (row: TableData<Data>) => boolean;
    getRowError?: (row: TableData<Data>) => boolean;
    getRowHighlight?: (row: TableData<Data>) => boolean;
};

const TableBody = <Data,>(props: TableBodyProps<Data>) => {
    const {
        data,
        dataKey,
        columns,
        checkboxSelection,
        selectedRows,
        groupModel,
        expandable,
        renderExpandedContent,
        onRowClick,
        onSelectRow,
        getRowSelectionDisabled,
        getRowError,
        getRowHighlight,
    } = props;

    const rowsModel = useMemo(() => {
        if (!groupModel) {
            return null;
        }

        return getRowsModel(data, groupModel.groupBy, groupModel.getGroupRowData);
    }, [data, groupModel]);

    const renderGroup = () => {
        return (
            <GroupedRow
                groupModel={groupModel}
                groupedRows={rowsModel}
                depth={0}
                dataKey={dataKey}
                columns={columns}
                checkboxSelection={checkboxSelection}
                expandable={expandable}
                renderExpandedContent={renderExpandedContent}
                onRowClick={onRowClick}
                onSelectRow={onSelectRow}
                getRowSelectionDisabled={getRowSelectionDisabled}
                getRowError={getRowError}
                selectedRows={selectedRows}
            />
        );
    };

    return (
        <tbody>
            {rowsModel && renderGroup()}
            {!rowsModel &&
                data?.map((row, rowIndex) => (
                    <TableRow
                        key={row[dataKey]}
                        dataKey={dataKey}
                        row={row}
                        rowIndex={rowIndex}
                        columns={columns}
                        checkboxSelection={checkboxSelection}
                        expandable={expandable}
                        renderExpandedContent={renderExpandedContent}
                        onRowClick={onRowClick}
                        onSelectRow={onSelectRow}
                        getRowSelectionDisabled={getRowSelectionDisabled}
                        getRowError={getRowError}
                        getRowHighlight={getRowHighlight}
                        selected={
                            !!selectedRows?.find(
                                (selectedRow) => selectedRow[dataKey] === row[dataKey]
                            )
                        }
                    />
                ))}
        </tbody>
    );
};

export default typedMemo(TableBody);
