import React from 'react';

import { AppBar, IconButton, Slide, SvgIcon, useScrollTrigger } from '@mui/material';
import cn from 'classnames';
import { Link } from 'react-router-dom';

import MenuIcon from 'src/assets/icons/menu.svg';
import LogoIcon from 'src/assets/logo.svg';
import { useIsMenuExpanded } from 'src/store/settings';

import { Menu } from './menu';
import { User } from './user';

import styles from './MobileHeader.module.scss';

export const MobileHeader = React.memo(() => {
    const [isExpanded, setIsExpanded] = useIsMenuExpanded();

    const trigger = useScrollTrigger();

    return (
        <Slide appear={false} direction="down" in={!trigger}>
            <AppBar className={styles.header} position="sticky">
                <div className={styles.header__container}>
                    <div>
                        <IconButton onClick={() => setIsExpanded((v) => !v)}>
                            <SvgIcon>
                                <MenuIcon
                                    className={cn(styles.header__menuIcon, {
                                        [styles.header__menuIcon_opened]: isExpanded,
                                    })}
                                />
                            </SvgIcon>
                        </IconButton>
                    </div>
                    <Menu />
                    <Link to="/" className={styles.header__link}>
                        <LogoIcon className={styles.header__logo} viewBox="0 0 190 40" />
                    </Link>
                    <User />
                </div>
            </AppBar>
        </Slide>
    );
});
