import { atom, useRecoilState } from 'recoil';

import { Bookmark } from 'root-front/types';
import { localStorageEffect } from 'root-front/utils';

export const bookmarksState = atom<Bookmark[]>({
    key: '@root/bookmarks',
    default: [],
    effects: [localStorageEffect('@root/bookmarks')],
});

export const useBookmarksState = () => {
    return useRecoilState(bookmarksState);
};
