import React, { useMemo } from 'react';

import {
    Checkbox,
    FormControl,
    FormHelperText,
    InputLabel,
    MenuItem,
    SelectChangeEvent,
    Select as SelectCore,
    SvgIcon,
} from '@mui/material';
import { useController } from 'react-hook-form';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import { SelectMultipleProps } from './types';
import { defaultIsEqualValues } from './utils';

import styles from '../Fields.module.scss';

const VALUE_ALL = '@ALL';

const Select = <T, Value>(props: SelectMultipleProps<T, Value>) => {
    const {
        options,
        control,
        isEqualValues = defaultIsEqualValues,
        placeholder,
        id,
        labelId,
        className,
        withStaticHelperText,
        readOnly,
        disabled,
        ...rest
    } = props;

    const { field, fieldState } = useController({
        name: props.name,
        control: control,
        rules: props.rules,
        shouldUnregister: props.shouldUnregister,
    });

    const selected = useMemo(() => {
        return (
            (field.value as Value[]).map(
                (val) => options.find((option) => isEqualValues(option.value, val))?.key
            ) || []
        );
    }, [options, field.value]);

    const isAllSelected = selected?.length === options.length;

    const handleChange = (e: SelectChangeEvent<(string | number)[]>, child: React.ReactNode) => {
        const { value } = e.target;

        if (value[value.length - 1] === VALUE_ALL) {
            const nextValue =
                selected.length === options.length ? [] : options.map(({ value }) => value);
            field.onChange(nextValue);
            props.onChange?.(e, child, nextValue);
            return;
        }

        const nextValue = (value as (string | number)[]).map(
            (val) => options.find((option) => option.key.toString() === val?.toString?.())?.value
        );

        field.onChange(nextValue);
        props.onChange?.(e, child, nextValue);
    };

    const renderValue = () =>
        (
            (field.value as Value[]).map(
                (val) => options.find((option) => isEqualValues(option.value, val))?.label
            ) || []
        ).join(', ');

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        field.onBlur();
        props.onBlur?.(e);
    };

    return (
        <FormControl
            size={props.size}
            error={!!fieldState.error}
            fullWidth={rest.fullWidth}
            className={className}
        >
            {props.label && <InputLabel id={id || labelId}>{props.label}</InputLabel>}
            <SelectCore
                {...rest}
                size={rest.size || 'small'}
                value={selected}
                onChange={handleChange}
                onBlur={handleBlur}
                inputRef={field.ref}
                inputProps={{ id: labelId || id }}
                labelId={labelId || id}
                renderValue={renderValue}
                IconComponent={(props) =>
                    !readOnly && !disabled ? (
                        <SvgIcon {...props}>
                            <Icons.ArrowDown />
                        </SvgIcon>
                    ) : null
                }
                sx={{
                    '& .MuiSelect-select .notranslate::after': placeholder
                        ? {
                              content: `"${placeholder}"`,
                              opacity: 0.42,
                          }
                        : {},
                }}
                placeholder={placeholder}
                autoComplete="off"
                readOnly={readOnly}
                disabled={disabled}
                multiple={true}
                native={false}
                MenuProps={{
                    sx: {
                        '& .MuiMenu-paper': {
                            maxWidth: 'min-content',
                        },
                    },
                }}
            >
                <MenuItem
                    key={VALUE_ALL}
                    value={VALUE_ALL}
                    selected={isAllSelected}
                    className={isAllSelected ? 'Mui-selected' : ''}
                >
                    <Checkbox
                        checked={isAllSelected}
                        indeterminate={selected.length > 0 && selected.length < options.length}
                        size={rest.size || 'small'}
                    />
                    Все
                </MenuItem>

                {options.map((option) => (
                    <MenuItem key={option.key} value={option.key}>
                        {rest.multiple && (
                            <Checkbox
                                checked={selected.includes(option.key)}
                                size={rest.size || 'small'}
                            />
                        )}
                        {option.label}
                    </MenuItem>
                ))}
            </SelectCore>
            {fieldState.error ? (
                <FormHelperText className={withStaticHelperText && styles.helperText_static}>
                    <FormErrorHelper message={fieldState.error.message} />
                </FormHelperText>
            ) : null}
        </FormControl>
    );
};

export default typedMemo(Select);
