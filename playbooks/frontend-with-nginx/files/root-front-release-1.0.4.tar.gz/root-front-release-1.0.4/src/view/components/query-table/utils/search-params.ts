import { SORT_DIRECTION } from 'root-front/constants';

import { SearchParams } from '../types';

export const getDefaultParams = (itemsPerPage: number[]): SearchParams => ({
    page: 0,
    size: itemsPerPage[0] || 20,
    sort: {
        field: 'id',
        direction: SORT_DIRECTION.DESC,
    },
});

export const getSearchParamsFromURLSearchParams = (
    urlSearchParams: URLSearchParams,
    defaultParams: SearchParams
): SearchParams => {
    const page = +urlSearchParams.get('page') || defaultParams.page;
    const size = +urlSearchParams.get('size') || defaultParams.size;
    const sort =
        urlSearchParams.get('sort') ||
        `${defaultParams.sort.field}_${defaultParams.sort.direction}`;

    const sortSplit = sort.split('_');
    const field = sortSplit[0] || 'id';
    const sortDir = sortSplit[1] || 'desc';
    const direction = SORT_DIRECTION[sortDir.toUpperCase()] || SORT_DIRECTION.DESC;

    return {
        page,
        size,
        sort: {
            field,
            direction,
        },
    };
};

export const getURLSearchParamsFromSearchParams = (
    searchParams: SearchParams,
    defaultParams: SearchParams
): URLSearchParams => {
    const urlSearchParams = new URLSearchParams(window.location.search);
    const { page, size, sort } = searchParams;

    if (page !== defaultParams.page) {
        urlSearchParams.set('page', page.toString());
    } else {
        urlSearchParams.delete('page');
    }

    if (size !== defaultParams.size) {
        urlSearchParams.set('size', size.toString());
    } else {
        urlSearchParams.delete('size');
    }

    if (
        sort.field !== defaultParams.sort.field ||
        sort.direction !== defaultParams.sort.direction
    ) {
        urlSearchParams.set('sort', `${sort.field}_${sort.direction.toLocaleLowerCase()}`);
    } else {
        urlSearchParams.delete('sort');
    }

    return urlSearchParams;
};
