import React, { useCallback, useMemo } from 'react';

import { Chip } from '@mui/material';

import { typedMemo, useEvent } from 'root-front/utils';

import { SelectOption } from '../../fields';
import { QuerySelect as QuerySelectCore, QuerySelectProps } from '../../query-select';
import { SortableList, SortableListProps } from '../../sortable-list';

import styles from './QuerySelectSortable.module.scss';

export type QuerySelectSortableProps<Data, Value> = Omit<
    QuerySelectProps<Data, Value, false>,
    'multiple' | 'onChange'
> &
    Partial<Omit<SortableListProps<Value>, 'list' | 'onChange' | 'getItemKey'>> & {
        onChange?: (value: Value[], type: 'add' | 'sort' | 'delete') => void;
    };

const QuerySelectSortable = <Data, Value>(props: QuerySelectSortableProps<Data, Value>) => {
    const {
        value,
        renderItem: renderItemProp,
        getOptionFromData,
        getOptionFromValue,
        getOptionDisabled: getOptionDisabledProp,
        onChange,
        ...rest
    } = props;

    const handleSort = useCallback((value: Value[]) => {
        onChange?.(value, 'sort');
    }, []);

    const handleAdd = useEvent((newValue) => {
        onChange?.([...((value as Value[]) || []), newValue], 'add');
    });

    const handleDelete = useEvent((index: number) => {
        const nextValue = [...((value as Value[]) || [])];
        nextValue.splice(index, 1);
        onChange?.(nextValue, 'delete');
    });

    const renderItem = useCallback(
        (item: Value, draggable, snapshot, index: number) => {
            const isDisabled = props.disabled || props.readOnly;
            if (renderItemProp) {
                return renderItemProp(item, draggable, snapshot, index);
            }

            return (
                <div {...(!isDisabled ? draggable.draggableProps : {})} className={styles.item}>
                    <Chip
                        {...(!isDisabled ? draggable.dragHandleProps : {})}
                        ref={draggable.innerRef}
                        label={`${index + 1}. ${
                            getOptionFromValue?.(item).label ||
                            getOptionFromData?.(item as any).label ||
                            value.toString()
                        }`}
                        onDelete={
                            props.disabled || props.readOnly ? undefined : () => handleDelete(index)
                        }
                        size="large"
                    />
                </div>
            );
        },
        [props.disabled, props.readOnly]
    );

    const getOption = useCallback(
        (value: Value) => getOptionFromValue?.(value) || getOptionFromData?.(value as any),
        []
    );

    const getItemKey = useCallback((item: Value) => (getOption(item)?.key || item).toString(), []);

    const valueOptions = useMemo(() => {
        return (value as Value[]).map(getOption);
    }, [value]);

    const getOptionDisabled = useCallback(
        (option: SelectOption) => {
            return (
                valueOptions.some((opt) => opt.key === option.key) ||
                getOptionDisabledProp?.(option)
            );
        },
        [valueOptions]
    );

    return (
        <div className={styles.container}>
            <SortableList
                list={value as Value[]}
                getItemKey={getItemKey}
                renderItem={renderItem}
                onChange={handleSort}
                listClassName={styles.list}
            />
            <QuerySelectCore
                {...rest}
                getOptionFromData={getOptionFromData}
                getOptionFromValue={getOptionFromValue}
                multiple={false}
                onChange={handleAdd}
                value={null}
                getOptionDisabled={getOptionDisabled}
                disableCloseOnSelect
                sortableMode
            />
        </div>
    );
};

export default typedMemo(QuerySelectSortable);
