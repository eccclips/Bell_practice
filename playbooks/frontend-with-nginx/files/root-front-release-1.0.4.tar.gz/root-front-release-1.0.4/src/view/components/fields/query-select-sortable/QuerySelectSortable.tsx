import React from 'react';

import { useController, UseControllerProps } from 'react-hook-form';

import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import {
    QuerySelectSortable as QuerySelectSortableCore,
    QuerySelectSortableProps,
} from '../../query-select';

export type QuerySelectSortableFieldProps<T, Data, Value> = UseControllerProps<T> &
    Omit<QuerySelectSortableProps<Data, Value>, 'value'>;

const QuerySelectSortable = <T, Data, Value>(
    props: QuerySelectSortableFieldProps<T, Data, Value>
) => {
    const { field, fieldState } = useController(props);

    const handleChange = (value: Value[], type: 'add' | 'sort' | 'delete') => {
        field.onChange(value);
        props.onChange?.(value, type);
    };

    const handleBlur = (e: React.FocusEvent<HTMLDivElement>) => {
        field.onBlur();
        props.onBlur?.(e);
    };

    return (
        <QuerySelectSortableCore
            {...props}
            helperText={
                fieldState.error ? <FormErrorHelper message={fieldState.error.message} /> : null
            }
            error={!!fieldState.error}
            onChange={handleChange}
            onBlur={handleBlur}
            value={field.value as any}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(QuerySelectSortable);
