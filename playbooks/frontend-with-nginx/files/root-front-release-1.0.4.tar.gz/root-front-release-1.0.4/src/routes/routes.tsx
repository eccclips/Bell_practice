import React from 'react';

import { Route } from 'react-router-dom';

import { ErrorPage } from 'root-front/components';

import { Notifications } from 'src/view/pages/notifications';

import {
    AdminPanelRoute,
    AvailabilityRoute,
    CounterpartyRoute,
    LogisticRoute,
    OrderRoute,
    ProductRoute,
    ReferenceRoute,
    ReportRoute,
    SupplyChainRoute,
    SupplyRoute,
    UserRoute,
    WarehouseDocumentRoute,
    WarehouseRoute,
} from './mfe';

export const ROUTES = [
    <Route path="warehouse/*" key="warehouse/*" element={<WarehouseRoute />} />,
    <Route path="counterparty/*" key="counterparty/*" element={<CounterpartyRoute />} />,
    <Route path="product/*" key="product/*" element={<ProductRoute />} />,
    <Route path="reference/*" key="reference/*" element={<ReferenceRoute />} />,
    <Route path="supply-chain/*" key="supply-chain/*" element={<SupplyChainRoute />} />,
    <Route path="supply-chain/*" key="supply-chain/*" element={<WarehouseRoute />} />,
    <Route path="availability/*" key="availability/*" element={<AvailabilityRoute />} />,
    <Route path="logistic/*" key="logistic/*" element={<LogisticRoute />} />,
    <Route path="supply/*" key="supply/*" element={<SupplyRoute />} />,
    <Route path="admin-panel/*" key="admin-panel/*" element={<AdminPanelRoute />} />,
    <Route path="order/*" key="order/*" element={<OrderRoute />} />,
    <Route
        path="warehouse-document/*"
        key="warehouse-document/*"
        element={<WarehouseDocumentRoute />}
    />,
    <Route path="user/*" key="user/*" element={<UserRoute />} />,
    <Route path="report/*" key="report/*" element={<ReportRoute />} />,
    <Route path="notifications/*" key="notifications/*" element={<Notifications />} />,
    <Route
        path="*"
        key="*"
        element={
            <ErrorPage
                text={'Этот раздел находится в разработке.\nПопробуйте вернуться сюда позднее.'}
            />
        }
    />,
];
