import { UseQueryResult } from '@tanstack/react-query';

import { UsersDTO } from 'root-front/dictionaries';
import { SortInstructionDTO } from 'root-front/interfaces';

import { GroupedRows } from '../body/types';
import { TableColumn } from './column';
import { SavedFilter, TableFilter } from './filter';

export enum TABLE_VIEW_MODE {
    FULL_HEIGHT = 'full-height',
    INNER_SCROLL = 'inner-scroll',
}

export type TableViewMode = TABLE_VIEW_MODE | `${TABLE_VIEW_MODE}`;

export type TableData<Data> = Data & Record<string, any>;

export type TableGroupModel<Data> = {
    groupColumnName: string;
    groupBy: Array<(row: Data) => string>;
    getGroupRowData?: Array<
        ((rows: TableData<Data>[], groupByKey: string) => TableData<Data>) | null
    >;
    sortGroupKeys?: Array<((a: string, b: string) => number) | null>;
    defaultExpanded?: Array<
        boolean | ((rows: TableData<Data>[] | GroupedRows<Data> | TableData<Data>[]) => boolean)
    >;
    leafColumn?: TableColumn<TableData<Data>>;
};

export type SimpleTableProps<T = any> = {
    columns: TableColumn<TableData<T>>[];
    data: TableData<T>[];
    sort?: SortInstructionDTO;
    dataKey?: string;
    viewMode?: TableViewMode;
    checkboxSelection?: boolean;
    selectedRows?: TableData<T>[];
    groupModel?: TableGroupModel<TableData<T>>;
    expandable?: boolean;
    emptyText?: React.ReactNode;
    renderExpandedContent?: (row: TableData<T>) => JSX.Element;
    onSortChange?: (sort: SortInstructionDTO) => void;
    onRowClick?: (data: TableData<T>) => void;
    onSelectedRowsChange?: (rows: TableData<T>[]) => void;
    onColumnResize?: (key: string, width: number) => void;
    getRowSelectionDisabled?: (row: TableData<T>) => boolean;
    getRowHighlight?: (row: TableData<T>) => boolean;
    getRowError?: (row: TableData<T>) => boolean;
    isLoading?: boolean;
    isEmpty?: boolean;
    isError?: boolean;
};

export type PageableTableProps<T = any> = SimpleTableProps<T> & {
    itemsPerPage?: number[];
};

export type TableProps<T = any> = PageableTableProps<T> & {
    page: number;
    size: number;
    extendedColumns?: TableColumn<TableData<T>>[];
    totalElements?: number;
    totalPages?: number;
    filters?: TableFilter[];
    filterValues?: Record<string, any>;
    allowColumnSettings?: boolean;
    hideFooter?: boolean;
    onPageChange: (page: number) => void;
    onSizeChange: (page: number) => void;
    onColumnsSettingsChange?: (columns: TableColumn<TableData<T>>[]) => void;
    onColumnsSettingsReset?: () => void;
    onFiltersChange?: (filterValues: Record<string, any>) => void;
    onFiltersReset?: (toDefault: boolean) => void;
    onRefresh?: () => void;
    isColumnsChanged?: boolean;
    isFiltersChanged?: boolean;
    allowResetFiltersToDefault?: boolean;
    savedFilters?: {
        appliedFilter?: {
            uid: string;
            name: string;
        };
        useSavedFilters: () => UseQueryResult<SavedFilter[]>;
        useUserSavedFilters?: (user: UsersDTO) => UseQueryResult<SavedFilter[]>;
        onApplyFilter: (savedFilter: SavedFilter) => void;
        onSaveFilter: (savedFilter: Omit<SavedFilter, 'uid'>) => void;
        onDeleteFilter: (id: string) => void;
        onImportUserFilters?: (filters: SavedFilter[]) => void;
    };
    slots?: {
        settingsEnd?: JSX.Element;
        settingsStart?: JSX.Element;
    };
};
