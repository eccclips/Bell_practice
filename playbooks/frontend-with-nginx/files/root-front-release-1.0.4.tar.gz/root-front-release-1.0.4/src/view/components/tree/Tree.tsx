import React from 'react';

import { TreeNode } from './node';
import { TreeProps } from './types';

import styles from './Tree.module.scss';

const Tree = (props: TreeProps) => {
    const { treeData, collapsable = true, defaultExpanded = false } = props;

    return (
        <div className={styles.container}>
            {treeData?.map((node, index) => (
                <TreeNode
                    key={node.key}
                    node={node}
                    collapsable={collapsable}
                    defaultExpanded={defaultExpanded}
                    deep={0}
                    last={index === treeData.length - 1}
                />
            ))}
        </div>
    );
};

export default React.memo(Tree);
