import { CHIP_COLORS } from 'root-front/components';

export enum NOTIFICATION_MESSAGE_CHANNEL {
    EMAIL = 'EMAIL',
    INTERNAL = 'INTERNAL',
    MESSENGER = 'MESSENGER',
}

export const NOTIFICATION_MESSAGE_CHANNEL_MAP = {
    [NOTIFICATION_MESSAGE_CHANNEL.EMAIL]: {
        text: 'Email',
    },
    [NOTIFICATION_MESSAGE_CHANNEL.INTERNAL]: {
        text: 'Внутренний',
    },
    [NOTIFICATION_MESSAGE_CHANNEL.MESSENGER]: {
        text: 'Мессенджер',
    },
};

export enum NOTIFICATION_TEMPLATE_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
}

export const NOTIFICATION_TEMPLATE_STATUS_MAP = {
    [NOTIFICATION_TEMPLATE_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [NOTIFICATION_TEMPLATE_STATUS.CLOSED]: { text: 'Не действует', color: CHIP_COLORS.NEUTRAL },
};
