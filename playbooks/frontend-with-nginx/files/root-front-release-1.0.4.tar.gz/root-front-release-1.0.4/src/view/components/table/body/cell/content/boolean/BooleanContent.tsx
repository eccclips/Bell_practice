import React, { memo } from 'react';

import { SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';

import styles from './BooleanContent.module.scss';

type BooleanContentProps = {
    value: boolean;
};

const BooleanContent = (props: BooleanContentProps) => {
    const { value } = props;

    if (value) {
        return (
            <SvgIcon viewBox="0 0 24 24" className={styles.icon_primary}>
                <Icons.Check />
            </SvgIcon>
        );
    }

    return (
        <SvgIcon viewBox="0 0 24 24" className={styles.icon_secondary}>
            <Icons.Minus />
        </SvgIcon>
    );
};

export default memo(BooleanContent);
