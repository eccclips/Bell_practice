import React, { useCallback, useMemo, useRef, useState } from 'react';

import {
    Autocomplete,
    Button,
    Checkbox,
    CircularProgress,
    SvgIcon,
    TextField,
} from '@mui/material';
import cn from 'classnames';
import debounce from 'lodash/debounce';

import { SelectOption } from 'root-front/components';
import { Icons } from 'root-front/icons';
import { typedMemo, useEvent } from 'root-front/utils';

import { QuerySelectProps } from './types';

import fieldsStyles from '../fields/Fields.module.scss';
import styles from './QuerySelect.module.scss';

const ListboxComponent = React.forwardRef<
    HTMLUListElement,
    React.HTMLAttributes<HTMLElement> & Record<string, any>
>((props, ref) => {
    const { children, hasNextPage, handleLoadMoreClick, ...rest } = props;

    return (
        <ul ref={ref} {...rest} key="listbox">
            {children}
            {hasNextPage && (
                <Button onClick={handleLoadMoreClick} className={styles.loadMore}>
                    Показать еще
                </Button>
            )}
        </ul>
    );
});

const QuerySelect = <Data, Value, Multiple extends boolean | undefined = false>(
    props: QuerySelectProps<Data, Value, Multiple>
) => {
    const {
        value,
        onChange,
        onBlur,
        loadingText = 'Поиск...',
        noOptionsText = 'Ничего не найдено',
        label,
        placeholder,
        helperText,
        error,
        inputRef,
        query,
        getOptionFromData,
        getOptionFromValue,
        getOptionDisabled,
        groupBy,
        multiple = false,
        disabled,
        readOnly,
        disableCloseOnSelect,
        sortableMode = false,
        saveSearchInputValue = false,
        className,
        withStaticHelperText,
        limitTags,
        loading: loadingProp,
    } = props;

    const [inputValue, setInputValue] = useState('');
    const [inputValueDebounce, setInputValueDebounce] = useState('');

    const [enabled, setEnabled] = useState(false);

    const listRef = useRef<HTMLElement>(null);

    const { data, isFetching, hasNextPage, fetchNextPage } = query({
        search: inputValueDebounce.trim(),
        enabled: !readOnly && !disabled && enabled,
    });

    const setDebounced = useCallback(
        debounce((value: string) => setInputValueDebounce(value), 500, {
            maxWait: 1000,
        }),
        []
    );

    const handleInputChange = useCallback(
        (_, value: string, reason: 'clear' | 'input' | 'reset') => {
            if (reason === 'reset' && saveSearchInputValue) {
                return;
            }

            setDebounced(value);
            setInputValue(value);
        },
        [saveSearchInputValue]
    );

    const handleChange = useEvent((_, value: SelectOption<Value>[] | SelectOption<Value>) => {
        if (multiple) {
            if (!(value as SelectOption<Value>[])?.length) {
                return onChange([] as any);
            }
            return onChange((value as SelectOption<Value>[]).map((val) => val.value) as any);
        }

        if (!value) {
            return onChange(null);
        }

        if (sortableMode) {
            setInputValue('');
            setDebounced('');
        }

        onChange((value as SelectOption<Value>).value as any);
    });

    const handleOpen = useCallback(() => {
        setEnabled(true);
    }, []);

    const handleLoadMoreClick = useCallback(() => {
        fetchNextPage();
    }, []);

    const options = useMemo(() => {
        if (!data?.pages?.length) {
            return [];
        }

        const optionsList = data.pages.flatMap((page) =>
            page.data.map((dataValue) => getOptionFromData(dataValue))
        );

        if (multiple) {
            if ((value as Value[])?.length && !optionsList.length) {
                return (value as Value[]).map(
                    (val) => getOptionFromData?.(val as any) || getOptionFromValue?.(val)
                );
            }

            return optionsList;
        }

        if (value && !optionsList.length) {
            return [getOptionFromValue?.(value as Value) || getOptionFromData?.(value as any)];
        }
        return optionsList;
    }, [data, value]);

    const optionValue = useMemo(() => {
        if (multiple) {
            if (!(value as Value[])?.length) {
                return [];
            }

            return (value as Value[]).map(
                (val) => getOptionFromValue?.(val) || getOptionFromData?.(val as any)
            );
        }

        if (!value) {
            return null;
        }

        return getOptionFromValue?.(value as Value) || getOptionFromData?.(value as any);
    }, [value, multiple]);

    const loading = (!readOnly && !disabled && isFetching) || loadingProp;

    return (
        <Autocomplete
            multiple={multiple}
            inputValue={inputValue}
            value={optionValue}
            options={options}
            loading={loading}
            loadingText={loadingText}
            noOptionsText={noOptionsText}
            onInputChange={handleInputChange}
            onChange={handleChange}
            onOpen={handleOpen}
            onBlur={onBlur}
            getOptionLabel={(option: SelectOption<Value>) => option.label}
            isOptionEqualToValue={(option: SelectOption<Value>, value: SelectOption<Value>) =>
                option?.key === value?.key
            }
            getOptionDisabled={getOptionDisabled}
            groupBy={groupBy}
            filterOptions={(x) => x}
            ChipProps={{ size: 'small', className: styles.chip }}
            limitTags={limitTags}
            ListboxComponent={ListboxComponent}
            ListboxProps={{ ref: listRef, handleLoadMoreClick, hasNextPage } as any}
            renderInput={(params) => (
                <TextField
                    {...params}
                    variant="outlined"
                    size="small"
                    helperText={helperText}
                    FormHelperTextProps={{
                        className: withStaticHelperText && fieldsStyles.helperText_static,
                    }}
                    error={error}
                    placeholder={readOnly && (value as any)?.length ? '' : placeholder}
                    label={label}
                    inputProps={{ ...params.inputProps, id: props.id }}
                    InputProps={{
                        ...params.InputProps,
                        inputRef: inputRef,
                        endAdornment: (
                            <React.Fragment>
                                {loading ? <CircularProgress size={20} /> : null}
                                {params.InputProps.endAdornment}
                            </React.Fragment>
                        ),
                    }}
                />
            )}
            renderOption={(props, option, { selected }) => (
                <li
                    {...props}
                    key={(option as SelectOption<Value>).key}
                    className={cn(props.className, styles.option)}
                >
                    {multiple && (
                        <Checkbox style={{ marginRight: 8 }} checked={selected} size="small" />
                    )}
                    {(option as SelectOption<Value>).label}
                </li>
            )}
            clearIcon={
                <SvgIcon fontSize="small">
                    <Icons.Close />
                </SvgIcon>
            }
            popupIcon={
                !readOnly && !disabled ? (
                    <SvgIcon>
                        <Icons.ArrowDown />
                    </SvgIcon>
                ) : null
            }
            openOnFocus
            disableCloseOnSelect={
                typeof disableCloseOnSelect === 'boolean' ? disableCloseOnSelect : multiple
            }
            disabled={disabled}
            readOnly={readOnly}
            className={className}
        />
    );
};

export default typedMemo(QuerySelect);
