import { SelectChangeEvent, SelectProps as SelectCoreProps } from '@mui/material';
import { UseControllerProps } from 'react-hook-form';

export type SelectOption<Value = any> = {
    key: string | number;
    value: Value;
    label: string;
};

export type SelectProps<T, Value, Multiple = false> = Omit<
    UseControllerProps<T> & SelectCoreProps<Multiple extends true ? Value[] : Value>,
    'onChange' | 'value' | 'defaultValue' | 'options' | 'renderValue'
> & {
    options: SelectOption<Value>[];
    isEqualValues?: (a: Value, b: Value) => boolean;
    clearable?: boolean;
    onChange?: (
        e: SelectChangeEvent<Multiple extends true ? (string | number)[] : string | number>,
        child: React.ReactNode,
        value: Multiple extends true ? Value[] : Value
    ) => void;
    multiple?: Multiple;
    withStaticHelperText?: boolean;
};

export type SelectSingleProps<T, Value> = Omit<
    UseControllerProps<T> & SelectCoreProps<Value>,
    'onChange' | 'value' | 'defaultValue' | 'options' | 'renderValue'
> & {
    options: SelectOption<Value>[];
    isEqualValues?: (a: Value, b: Value) => boolean;
    clearable?: boolean;
    withStaticHelperText?: boolean;
    onChange?: (
        e: SelectChangeEvent<string | number>,
        child: React.ReactNode,
        value: Value
    ) => void;
};

export type SelectMultipleProps<T, Value> = Omit<
    UseControllerProps<T> & SelectCoreProps<Value[]>,
    'onChange' | 'value' | 'defaultValue' | 'options' | 'renderValue'
> & {
    options: SelectOption<Value>[];
    isEqualValues?: (a: Value, b: Value) => boolean;
    clearable?: boolean;
    withStaticHelperText?: boolean;
    onChange?: (
        e: SelectChangeEvent<(string | number)[]>,
        child: React.ReactNode,
        value: Value[]
    ) => void;
};
