import React, { useEffect, useState } from 'react';

import cn from 'classnames';

import { PERMISSIONS } from 'root-front/store';
import { useHasPermission } from 'root-front/utils';

import { LAYOUT, useIsMenuExpanded, useLayoutState } from 'src/store/settings';

import { Collapser } from './collapser';
import { Logo } from './logo';
import { Nav } from './nav';
import { Notifications } from './notifications';
import { User } from './user';

import styles from './DesktopHeader.module.scss';

export const DesktopHeader = React.memo(() => {
    const [isExpanded, setIsExpanded] = useIsMenuExpanded();

    const [fixedPosition, setFixedPosition] = useState(!isExpanded);
    const layout = useLayoutState();

    const hasNotificationPermissions = useHasPermission(PERMISSIONS.ALL_MESSAGES);

    useEffect(() => {
        if (layout === LAYOUT.TABLET) {
            setIsExpanded(false);
        }
    }, [layout]);

    useEffect(() => {
        if (isExpanded && layout === LAYOUT.TABLET) {
            return setFixedPosition(true);
        }

        if (layout === LAYOUT.DESKTOP) {
            setFixedPosition(false);
        }
    }, [isExpanded, layout]);

    useEffect(() => {
        return () => {
            setIsExpanded(false);
        };
    }, []);

    return (
        <>
            <header
                className={cn(styles.header, {
                    [styles.header__collapsed]: !isExpanded,
                    [styles.header_fixed]: fixedPosition,
                })}
                onTransitionEnd={() => {
                    if (!isExpanded) {
                        setFixedPosition(false);
                    }
                }}
            >
                <Logo />
                <Collapser />
                <Nav />
                {hasNotificationPermissions && <Notifications mode="desktop" />}
                <User />
            </header>
            {fixedPosition && <div className={styles.headerPlaceholder}></div>}
            {layout === LAYOUT.TABLET && isExpanded && (
                <div className={styles.overflow} onClick={() => setIsExpanded(false)}></div>
            )}
        </>
    );
});
