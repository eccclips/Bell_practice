import dayjs from 'dayjs';

dayjs.locale('ru');

type GetFormattedDateWithTimeConfig = {
    showSeconds?: boolean;
    ignoreTimezone?: boolean;
};

const DEFAULT_CONFIG = { showSeconds: true, ignoreTimezone: false };

export const getFormattedDateWithTime = (
    date: string | number,
    config: GetFormattedDateWithTimeConfig = DEFAULT_CONFIG
): string => {
    if (!date) {
        return '';
    }

    const fullConfig: GetFormattedDateWithTimeConfig = { ...DEFAULT_CONFIG, ...config };
    const dateString = fullConfig.ignoreTimezone ? (date as string).slice(0, 19) : date;

    if (fullConfig.showSeconds) {
        return dayjs(dateString).format('DD.MM.YYYY HH:mm:ss');
    }

    return dayjs(dateString).format('DD.MM.YYYY HH:mm');
};

export const getMonthNameByNumber = (monthNumber: number) =>
    dayjs().set('month', monthNumber).format('MMMM');
