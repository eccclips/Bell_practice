import { CHIP_COLORS } from 'root-front/components';

export enum STANDARD_TASK_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
}

export const STANDARD_TASK_STATUS_MAP = {
    [STANDARD_TASK_STATUS.ACTIVE]: { text: 'Активна', color: CHIP_COLORS.SUCCESS },
    [STANDARD_TASK_STATUS.CLOSED]: { text: 'Неактивна', color: CHIP_COLORS.DRAFT },
    [STANDARD_TASK_STATUS.DELETED]: { text: 'Удалена', color: CHIP_COLORS.ERROR },
};

export enum STANDARD_TASK_INTERVAL_UNIT {
    MINUTE = 'MINUTE',
    HOUR = 'HOUR',
    DAY = 'DAY',
    MONTH = 'MONTH',
}

export const STANDARD_TASK_INTERVAL_UNIT_MAP = {
    [STANDARD_TASK_INTERVAL_UNIT.MINUTE]: {
        text: 'Каждые n минут',
    },
    [STANDARD_TASK_INTERVAL_UNIT.HOUR]: { text: 'Каждые n часов' },
    [STANDARD_TASK_INTERVAL_UNIT.DAY]: { text: 'Каждые n дней' },
    [STANDARD_TASK_INTERVAL_UNIT.MONTH]: { text: 'Каждое 1-е число месяца' },
};
