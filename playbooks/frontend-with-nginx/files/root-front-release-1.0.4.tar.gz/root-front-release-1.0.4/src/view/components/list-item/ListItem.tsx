import React, { memo, ReactNode, useMemo } from 'react';

import cn from 'classnames';

import { getFixedNumber, getFormattedDateWithTime } from 'root-front/utils';

import { CHIP_COLORS } from '../chip';
import { BooleanValue } from './boolean-value';
import { ChipValue } from './chip-value';
import { LinkValue } from './link-value';

import styles from './ListItem.module.scss';

type ListItemProps = {
    label: string;
    value: string | number | boolean | ReactNode;
    type?: 'auto' | 'chip' | 'date' | 'boolean' | 'link' | 'amount';
    chipColor?: CHIP_COLORS;
    link?: string;
    className?: string;
    labelFor?: string;
};

const ListItem = (props: ListItemProps) => {
    const { label, value, type = 'auto', chipColor, link, className, labelFor } = props;

    const renderValue = useMemo(() => {
        if (typeof value === 'boolean') {
            return <BooleanValue value={value} />;
        }

        if (type === 'chip') {
            return <ChipValue value={value as string} color={chipColor} />;
        }

        if (type === 'date') {
            return getFormattedDateWithTime(value as string, { ignoreTimezone: true });
        }

        if (type === 'link') {
            return <LinkValue value={value} link={link} />;
        }

        if (type === 'amount') {
            return getFixedNumber(value as string);
        }

        return value || '—';
    }, [value, type, chipColor]);

    return (
        <div className={cn(styles.container, className)}>
            <label className={styles.container__label} htmlFor={labelFor}>
                {label}
            </label>
            <div className={styles.container__valueWrapper}>{renderValue}</div>
        </div>
    );
};

export default memo(ListItem);
