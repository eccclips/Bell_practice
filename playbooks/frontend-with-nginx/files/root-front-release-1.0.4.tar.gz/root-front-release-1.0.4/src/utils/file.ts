import dayjs from 'dayjs';

export const downloadFile = (
    file: Blob,
    name: string,
    extension: string,
    config: { filenameWithDate?: boolean } = { filenameWithDate: true }
) => {
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name}${
        config.filenameWithDate ? ` ${dayjs().format('DD.MM.YYYY HH-mm-ss')}` : ''
    }.${extension}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
};
