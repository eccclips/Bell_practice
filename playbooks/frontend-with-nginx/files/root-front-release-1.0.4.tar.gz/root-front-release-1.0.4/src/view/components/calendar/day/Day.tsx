import React from 'react';

import { Tooltip } from '@mui/material';
import { PickersDay, PickersDayProps } from '@mui/x-date-pickers';
import { Dayjs } from 'dayjs';

import { SelectedDays } from '../types';

import styles from '../Calendar.module.scss';

const Day = (
    props: PickersDayProps<Dayjs> & {
        selectedDays: SelectedDays;
        yearAndMonthString: string;
    }
) => {
    const { selectedDays, yearAndMonthString, day, ...other } = props;

    const dateString = `${yearAndMonthString}-${day.date().toString().padStart(2, '0')}`;
    const selected = selectedDays[dateString];
    if (selected) {
        return (
            <Tooltip
                title={selected}
                enterTouchDelay={0}
                leaveTouchDelay={10000}
                componentsProps={{ tooltip: { className: styles.tooltip } }}
                arrow
            >
                <span>
                    <PickersDay {...other} day={day} selected />
                </span>
            </Tooltip>
        );
    }

    return <PickersDay {...other} day={day} selected={false} />;
};

export default React.memo(Day);
