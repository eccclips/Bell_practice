import React from 'react';

import { Pagination } from '@mui/material';

import { LAYOUT, useLayoutState } from 'root-front/store';

import { DEFAULT_ITEMS_PER_PAGE } from '../constants';
import { TableItemsPerPage } from './items-per-page';

import styles from './TableFooter.module.scss';

type TableFooterProps = {
    size: number;
    page: number;
    totalElements: number;
    totalPages: number;
    itemsPerPage: number[];
    onSizeChange: (size: number) => void;
    onPageChange: (page: number) => void;
};

const TableFooter = (props: TableFooterProps) => {
    const {
        size,
        page,
        totalElements,
        totalPages,
        onSizeChange,
        itemsPerPage = DEFAULT_ITEMS_PER_PAGE,
        onPageChange,
    } = props;

    const layout = useLayoutState();

    const handlePageChange = (e: React.ChangeEvent<unknown>, page: number) => {
        onPageChange(page - 1);
    };

    const currentPage = page + 1;

    return (
        <div className={styles.footer}>
            {typeof totalElements === 'number' && (
                <TableItemsPerPage
                    size={size}
                    page={page}
                    totalElements={totalElements}
                    itemsPerPage={itemsPerPage}
                    onSizeChange={onSizeChange}
                />
            )}

            {typeof totalPages === 'number' && (
                <Pagination
                    className={styles.pagination}
                    page={currentPage}
                    count={totalPages}
                    onChange={handlePageChange}
                    showFirstButton
                    showLastButton
                    size={layout === LAYOUT.MOBILE ? 'small' : 'medium'}
                    shape="rounded"
                    color="primary"
                />
            )}
        </div>
    );
};

export default React.memo(TableFooter);
