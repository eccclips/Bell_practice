import { BaseAuditedDTO } from 'root-front/interfaces';

import {
    BASE_STATUS,
    CALC_TASK_WSO_STAGE,
    CALC_TASK_WSO_STATUS,
    ORDER_ITEM_STATUS,
    ORDER_STATUS,
    ORDER_TYPE,
    PROVISION_SOURCE,
    REPROCESSING_HISTORY_STATE,
    SERVICE_RATE_STATUS,
    SUPPLY_CHAIN_REPROCESSING_TASK_STATUS,
    SUPPLY_CHAIN_SHIPMENT_TYPE,
    TASK_WSO_REASON_TYPE,
    WSO_ADJUSTMENT_REASON_TYPE,
    WSO_PARTY_ITEM_STATUS,
    WSO_PARTY_STATUS,
} from '../constants';
import {
    BusinessDomainDTO,
    ContractorAgreementDTO,
    CounterpartyDTO,
    PackingTypeDTO,
} from './counterparty';
import { ProductDTO } from './product';
import { ReferenceDTO } from './reference';
import { SupplyChainDTO } from './supply-chain';
import { WarehouseDTO, WarehouseGroupDTO, WarehouseOrderTypeDTO } from './warehouse';
import { WarehouseDocumentDTO } from './warehouse-document';

export interface OrderDTO extends BaseAuditedDTO {
    number: string;
    number1c: string;
    agreement: ContractorAgreementDTO;
    specificationMonth: string;
    vor: boolean;
    vorLastModifiedDate: string;
    forced: boolean;
    callCenter: boolean;
    callCenterLastModifiedDate: string;
    responsible: string;
    shippingWarehouse?: WarehouseDTO;
    shipper: CounterpartyDTO;
    customer: CounterpartyDTO;
    status: ORDER_STATUS;
    type: ORDER_TYPE;
    consigneeWarehouse?: WarehouseDTO;
    consigneeWarehouseGroup?: WarehouseGroupDTO;
    consignee: CounterpartyDTO;
    serviceRateDate: string;
    items: OrderItemDTO[];
    percent: number;
    warehouseOrderType: WarehouseOrderTypeDTO;
    expirationDate: string;
    sourceCreatedDate: string;
    sourceLastModifiedDate: string;
    backOrderDate: string;
    isManualPriority: boolean;
    priority: number;
    serviceRate: ServiceRateDTO[];
    requestOrder: OrderDTO;
}

export interface OrderItemDTO extends BaseAuditedDTO {
    syntheticId?: string;
    orderItemId?: number;
    product: ProductDTO;
    orderItemProduct: ProductDTO;
    unit: ReferenceDTO;
    quantity: number;
    quantityUnreserved?: number;
    wsoPartyId?: number;
    status: ORDER_ITEM_STATUS;
    orderId: number;
    warehouse: WarehouseDTO;
    percent: number;
    otherPrice: number;
    price: string;
    priority: number;
    supplyDetails: SupplyDetailDTO[];
    order: OrderDTO;
}

export interface SupplyDetailDTO extends BaseAuditedDTO {
    externalId: string;
    orderItems: OrderItemDTO[];
    product: ProductDTO;
    type: ORDER_TYPE;
    warehouseOrderType: WarehouseOrderTypeDTO;
    warehouseDocumentItem: WarehouseDocumentDTO;
    supplyChain: SupplyChainDTO;
    isCrossDoc: boolean;
    assemblyWarehouse: WarehouseDTO;
    shippingWarehouse: WarehouseDTO;
    transitWarehouse: WarehouseDTO;
    shipmentType: SUPPLY_CHAIN_SHIPMENT_TYPE;
    quantityUnsecured: number;
    quantitySecured: number;
    quantityReserved: number;
    quantityOrderShip: number;
    quantityInRoute: number;
    quantityShipWarehouse: number;
    quantityFinished: number;
    plannedSupplyDate: string;
    plannedShipmentDate: string;
    plannedAvailabilityDate: string;
    priority: number;
    noPlannedShipmentDate: boolean;
    plannedShipmentDateReason: string;
    salesForecastType: string;
    provisionSource: PROVISION_SOURCE;
    warehouseDocument: WarehouseDocumentDTO;
    wsoPartyItem: WsoPartyItemDTO;
}

/** Список позиций НГО */
export interface WsoPartyDTO extends BaseAuditedDTO {
    calcTaskWsoParty: CalcTaskWsoPartyDTO;
    counterparty: CounterpartyDTO;
    packingType: PackingTypeDTO;
    month: string;
    sumParty: number;
    partyNum: string;
    quantity: number;
    status: WSO_PARTY_STATUS;
    responsible: string;
    planShipmentDate: string;
    planProvisionDate: string;
    unsecured: boolean;
    reserved: boolean;
    priority: number;
    transparentPriority: number;
    plannedReservationDate: string;
    planShipmentDateSupplyChain: string;
    product: ProductDTO;
    agreement: ContractorAgreementDTO;
    items: WsoPartyItemDTO;
    sumBatchSet: string;
    dailySum: string;
}

export interface WsoPartyItemDTO extends BaseAuditedDTO {
    quantity: number;
    status: WSO_PARTY_ITEM_STATUS;
    orderItem: OrderItemDTO;
    wsoParty: WsoPartyDTO;
    quantityFinished: number;
    quantityUnsecured: number;
}

export interface SupplyDetailSummaryDTO {
    syntheticId: string;
    orderItemId: number;
    wsoParty?: WsoPartyDTO;
    wsoPartyId?: number;
    product: ProductDTO;
    quantity: number;
    quantityUnreserved: number;
    /** Плановая дата обеспечения (ПДОб) */
    plannedSupplyDate: number;
    /** Плановая дата отгрузки (ПДОт) */
    plannedShipmentDate: number;
}

export interface SalesPlanDTO extends BaseAuditedDTO {
    number: string;
    consignee: CounterpartyDTO;
    agreement: ContractorAgreementDTO;
    businessDomain: BusinessDomainDTO;
    amount: number;
    month: string;
    status: BASE_STATUS;
}

export interface PriorityMatrixDTO extends BaseAuditedDTO {
    ageDays: number;
    priority: number;
    status: BASE_STATUS;
    warehouseOrderTypeId: number;
}

export interface SupplyChainReprocessingTaskDTO extends BaseAuditedDTO {
    totalItems: number;
    status: SUPPLY_CHAIN_REPROCESSING_TASK_STATUS;
    errorMessage: string;
}

export interface OrderReprioritizingTaskDTO extends BaseAuditedDTO {
    totalItems: number;
    status: SUPPLY_CHAIN_REPROCESSING_TASK_STATUS;
    errorMessage: string;
}

export interface ServiceRateDTO extends BaseAuditedDTO {
    status: SERVICE_RATE_STATUS;
}
export interface SupplyChainReprocessingHistoryDTO extends BaseAuditedDTO {
    /** Задание на переподбор */
    task: SupplyChainReprocessingTaskDTO;
    /** Позиция заказа */
    item: OrderItemDTO;
    /** Подобранная номенклатура */
    product: ProductDTO;
    /** Партия НГО */
    wsoParty: WsoPartyDTO;
    /** Номер складского заказа */
    warehouseDocumentNumber: string;
    /** Вид записи: До/После */
    state: REPROCESSING_HISTORY_STATE;
    /** Склад комплектации */
    assemblyWarehouse: WarehouseDTO;
    /** Склад отгрузки */
    shippingWarehouse: WarehouseDTO;
    /** Цепочка обеспечения */
    supplyChain: SupplyChainDTO;
    /** Признак Кросс-докинг  */
    isCrossDoc: boolean;
    /** Источник обеспечения */
    provisionSource: PROVISION_SOURCE;
    /** Способ отгрузки */
    shipmentType: SUPPLY_CHAIN_SHIPMENT_TYPE;
    /** Количество не обеспеченных */
    quantityUnsecured: number;
    /** Количество забронированных */
    quantitySecured: number;
    /** Количество зарезервированных */
    quantityReserved: number;
    /** Количество ЗнО */
    quantityZno: number;
    /** Количество в пути */
    quantityInRoute: number;
    /** Количество на складе отгрузки */
    quantityShipWarehouse: number;
    /** Количество исполнено */
    quantityFinished: number;
    /** Плановая дата обеспечения. */
    plannedSupplyDate: string;
    /** Плановая дата отгрузки (ПДОт) */
    plannedShipmentDate: string;
    /** Плановая дата доступности */
    plannedAvailabilityDate: string;
    /** Осталось непокрыто */
    leftUnsecured: number;
    /** Синтетическое Осталось непокрыто (мапится фронтом для GroupedRow из leftUnsecured) */
    syntheticLeftUnsecured: number;
}

/** Номенклатурные графики отгрузки */
export interface CalcTaskWsoPartyDTO extends BaseAuditedDTO {
    externalId: string;
    reasonType: TASK_WSO_REASON_TYPE;
    status: CALC_TASK_WSO_STATUS;
    stage: CALC_TASK_WSO_STAGE;
    startDate: string;
    hasError: boolean;
    reasons: WSO_ADJUSTMENT_REASON_TYPE[];
    responsible: string;
    sumBatchSet: number;
}

export interface SalesPlanItemDTO extends BaseAuditedDTO {
    salesPlan: SalesPlanDTO;
    agreement?: ContractorAgreementDTO;
    amount: string;
    status: BASE_STATUS;
    consignee?: CounterpartyDTO;
}

export interface OrderItemDraftDTO extends BaseAuditedDTO {
    order: OrderDTO;
    orderId: number;
    productId: number;
    quantity: string;
    unitShortName: string;
    price: number;
    priority: number;
    status: BASE_STATUS;
    warehouse: WarehouseDTO;
    percent: number;
    otherPrice: number;
}
