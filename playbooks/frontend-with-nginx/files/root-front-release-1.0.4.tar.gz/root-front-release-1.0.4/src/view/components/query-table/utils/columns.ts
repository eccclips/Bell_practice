import { TableColumn } from 'root-front/components';
import { MinifiedColumn, TableSettings } from 'root-front/types';

export const getMinifiedColumns = (columns: TableColumn[]): MinifiedColumn[] => {
    return columns.map(({ key, disabled, resizeWidth, children }) => ({
        key,
        disabled,
        resizeWidth,
        children: children?.length ? getMinifiedColumns(children) : null,
    }));
};

export const getDefaultSettings = ({ columns }: { columns: TableColumn[] }): TableSettings => ({
    columns: getMinifiedColumns(columns),
});

export const getExtendedColumns = (columns: TableColumn[], minifiedColumns: MinifiedColumn[]) =>
    minifiedColumns?.map((column) => {
        const extendedColumn = columns?.find((el) => el.key === column.key);

        return {
            ...(extendedColumn || {}),
            ...column,
            children: column.children?.length
                ? getExtendedColumns(extendedColumn?.children, column.children)
                : null,
        };
    });

export const getDisplayedColumns = (
    columns: TableColumn[],
    minifiedColumns: MinifiedColumn[]
): TableColumn[] =>
    minifiedColumns
        ?.filter(({ disabled }) => !disabled)
        .map((column) => {
            const extendedColumn = columns?.find((el) => el.key === column.key);
            return {
                ...(extendedColumn || {}),
                ...column,
                children: column.children?.length
                    ? getDisplayedColumns(extendedColumn?.children, column.children)
                    : null,
            } as TableColumn;
        });

export const hasColumnSettingsChanges = (
    columns: TableColumn[],
    extendedColumns: TableColumn[]
) => {
    if (columns === extendedColumns) {
        return false;
    }

    if (columns?.length !== extendedColumns?.length) {
        return true;
    }

    const checkIsEqualColumns = (columns: TableColumn[], extendedColumns: TableColumn[]) => {
        return extendedColumns?.every((column, index) => {
            const isSameColumn = columns[index]?.key === column.key;

            if (!isSameColumn) {
                return false;
            }

            const isEqualDisabled = !!columns[index]?.disabled === !!column.disabled;
            const isEqualWidth = columns[index].resizeWidth === column.resizeWidth;
            if (!(isEqualDisabled && isEqualWidth)) {
                return false;
            }

            if (column.children?.length) {
                return checkIsEqualColumns(columns[index].children, column.children);
            }

            return true;
        });
    };

    return !checkIsEqualColumns(columns, extendedColumns);
};

export const getResizedColumns = (
    columns: TableColumn[] | MinifiedColumn[],
    key: string,
    width: number
) => {
    return columns.map((column) => {
        if (column.key !== key) {
            return column.children?.length
                ? { ...column, children: getResizedColumns(column.children, key, width) }
                : column;
        }
        return { ...column, resizeWidth: width };
    });
};
