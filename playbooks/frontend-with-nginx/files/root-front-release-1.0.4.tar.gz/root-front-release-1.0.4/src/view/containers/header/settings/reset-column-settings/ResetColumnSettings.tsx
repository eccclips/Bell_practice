import React, { useState } from 'react';

import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';

import { resetTableSettings } from './utils';

import styles from './ResetColumnSettings.module.scss';

const ResetColumnSettings = () => {
    const [opened, setOpened] = useState(false);

    const handleOpen = () => {
        setOpened(true);
    };

    const handleClose = () => {
        setOpened(false);
    };

    return (
        <>
            <label>Сброс настроек таблиц</label>
            <Button variant="outlined" color="secondary" onClick={handleOpen}>
                Сбросить
            </Button>
            <Dialog open={opened} onClose={handleClose}>
                <DialogTitle>Сброс настроек таблиц</DialogTitle>
                <DialogContent className={styles.content}>
                    <p>
                        Все настройки таблиц, такие как расположение, состояние и размер колонок,
                        будут сброшены.
                    </p>
                    <p>
                        Данное действие может помочь, если страница с таблицей открывается с
                        ошибкой.
                    </p>
                </DialogContent>
                <DialogActions>
                    <Button variant="contained" onClick={resetTableSettings}>
                        Сбросить
                    </Button>
                    <Button variant="outlined" color="secondary" onClick={handleClose}>
                        Отменить
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default React.memo(ResetColumnSettings);
