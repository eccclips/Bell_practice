declare module 'public';
declare module '*.scss';
declare module '*.css';
declare module '*.png';
declare module '*.jpg';
declare module '*.svg' {
    const content: React.FunctionComponent<React.SVGAttributes<SVGElement>>;
    export default content;
}
declare module '*.svg?url';

declare module 'root-front/store' {
    export * from 'src/store';
}

declare module 'root-front/api' {
    export * from 'src/api';
}

declare module 'root-front/utils' {
    export * from 'src/utils';
}

declare module 'root-front/components' {
    export * from 'src/view/components';
}

declare module 'root-front/types' {
    export * from 'src/types/index';
}

declare module 'root-front/icons' {
    export * from 'src/view/icons';
}

declare module 'root-front/styles' {
    export * from 'src/styles/index';
}

declare module 'root-front/interfaces' {
    export * from 'src/interfaces/index';
}

declare module 'root-front/constants' {
    export * from 'src/constants/index';
}

declare module 'root-front/dictionaries' {
    export * from 'src/dictionaries';
}
