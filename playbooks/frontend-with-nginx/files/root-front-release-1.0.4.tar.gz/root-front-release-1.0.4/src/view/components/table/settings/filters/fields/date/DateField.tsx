import React, { useCallback, useMemo } from 'react';

import { DateView } from '@mui/x-date-pickers';
import { Control, UseFormSetValue } from 'react-hook-form';

import { Fields } from '../../../../../fields';

export const getViews = (view: DateView) => {
    switch (view) {
        case 'year':
            return ['year'] as DateView[];
        case 'month':
            return ['year', 'month'] as DateView[];
        case 'day':
            return ['year', 'month', 'day'] as DateView[];
        default:
            return ['year', 'month', 'day'] as DateView[];
    }
};

type DateFieldProps<T> = {
    control: Control<T>;
    name: any;
    label: string;
    datePickerView: DateView;
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
    setValue: UseFormSetValue<Record<string, any>>;
};

const DateField = <T,>(props: DateFieldProps<T>) => {
    const { control, name, label, datePickerView, onChange, setValue } = props;

    const handleChange = useCallback(
        (value: any) => {
            onChange?.(value, setValue);
        },
        [onChange, setValue]
    );

    const id = `filter__${name}`;

    const views = useMemo(() => getViews(datePickerView), [datePickerView]);

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <Fields.DatePicker
                id={id}
                control={control}
                name={name}
                views={views}
                openTo={datePickerView || 'day'}
                onChange={handleChange}
            />
        </>
    );
};

export default React.memo(DateField);
