import React, { memo } from 'react';

import { SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';

import styles from './BooleanValue.module.scss';

type BooleanValueProps = {
    value: boolean;
};

const BooleanValue = (props: BooleanValueProps) => {
    const { value } = props;

    if (value) {
        return (
            <SvgIcon viewBox="0 0 24 24" className={styles.booleanValue_stroke_primary}>
                <Icons.Check />
            </SvgIcon>
        );
    }

    return (
        <SvgIcon viewBox="0 0 24 24" className={styles.booleanValue_stroke_secondary}>
            <Icons.Minus />
        </SvgIcon>
    );
};

export default memo(BooleanValue);
