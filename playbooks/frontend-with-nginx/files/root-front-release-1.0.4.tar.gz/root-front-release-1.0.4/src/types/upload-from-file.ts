export type UploadFromFileParams<UploadParams = Record<string, any>> = {
    file: File;
    params: UploadParams;
};

export type SaveDataFromFileParams<Data, SaveParams = Record<string, any>> = {
    data: Data;
    params: SaveParams;
};
