import { DateView } from '@mui/x-date-pickers';
import dayjs from 'dayjs';

export const getStringValueFrom = (value: dayjs.Dayjs, views: readonly DateView[]) => {
    if (!views.includes('month')) {
        return dayjs(value.format('YYYY')).startOf('year').format('YYYY-MM-DDTHH:mm:ss+00:00');
    }

    if (!views.includes('day')) {
        return dayjs(value.format('YYYY-MM')).startOf('month').format('YYYY-MM-DDTHH:mm:ss+00:00');
    }

    return dayjs(value.format('YYYY-MM-DD')).startOf('day').format('YYYY-MM-DDTHH:mm:ss+00:00');
};

export const getStringValueTo = (value: dayjs.Dayjs, views: readonly DateView[]) => {
    if (!views.includes('month')) {
        return dayjs(value.format('YYYY')).endOf('year').format('YYYY-MM-DDTHH:mm:ss+00:00');
    }

    if (!views.includes('day')) {
        return dayjs(value.format('YYYY-MM')).endOf('month').format('YYYY-MM-DDTHH:mm:ss+00:00');
    }

    return dayjs(value.format('YYYY-MM-DD')).endOf('day').format('YYYY-MM-DDTHH:mm:ss+00:00');
};
