import React from 'react';

import { typedMemo } from 'root-front/utils';

import { DEFAULT_ITEMS_PER_PAGE } from './constants';
import { TableFooter } from './footer';
import { TableSettings } from './settings';
import { SimpleTable } from './simple-table';
import { TABLE_VIEW_MODE, TableProps } from './types';

import styles from './Table.module.scss';

function Table<T>(props: TableProps<T>) {
    const {
        columns,
        extendedColumns = columns,
        data,
        dataKey = 'id',
        page,
        size,
        itemsPerPage = DEFAULT_ITEMS_PER_PAGE,
        sort,
        totalElements,
        totalPages,
        filters,
        filterValues,
        checkboxSelection,
        selectedRows,
        groupModel,
        expandable,
        renderExpandedContent,
        allowColumnSettings = true,
        viewMode = TABLE_VIEW_MODE.INNER_SCROLL,
        hideFooter,
        onPageChange,
        onSizeChange,
        onSortChange,
        onColumnsSettingsChange,
        onColumnsSettingsReset,
        onColumnResize,
        onFiltersChange,
        onFiltersReset,
        onRowClick,
        onSelectedRowsChange,
        getRowSelectionDisabled,
        getRowError,
        getRowHighlight,
        onRefresh,
        isLoading,
        isEmpty,
        isError,
        isColumnsChanged,
        isFiltersChanged,
        allowResetFiltersToDefault,
        savedFilters,
        slots,
    } = props;

    return (
        <div className={styles.container}>
            <TableSettings
                extendedColumns={extendedColumns}
                filters={filters}
                filterValues={filterValues}
                allowColumnSettings={allowColumnSettings}
                onFiltersChange={onFiltersChange}
                onFiltersReset={onFiltersReset}
                onColumnsSettingsChange={onColumnsSettingsChange}
                onColumnsSettingsReset={onColumnsSettingsReset}
                onRefresh={onRefresh}
                isColumnsChanged={isColumnsChanged}
                isFiltersChanged={isFiltersChanged}
                allowResetFiltersToDefault={allowResetFiltersToDefault}
                savedFilters={savedFilters}
                settingsEndSlot={slots?.settingsEnd}
                settingsStartSlot={slots?.settingsStart}
            />
            <SimpleTable
                data={data}
                columns={columns}
                sort={sort}
                dataKey={dataKey}
                viewMode={viewMode}
                checkboxSelection={checkboxSelection}
                selectedRows={selectedRows}
                groupModel={groupModel}
                expandable={expandable}
                renderExpandedContent={renderExpandedContent}
                onSelectedRowsChange={onSelectedRowsChange}
                getRowSelectionDisabled={getRowSelectionDisabled}
                onColumnResize={onColumnResize}
                getRowError={getRowError}
                getRowHighlight={getRowHighlight}
                onSortChange={onSortChange}
                onRowClick={onRowClick}
                isLoading={isLoading}
                isError={isError}
                isEmpty={isEmpty}
            />
            {!hideFooter && (
                <TableFooter
                    page={page}
                    size={size}
                    totalElements={totalElements}
                    totalPages={totalPages}
                    itemsPerPage={itemsPerPage}
                    onPageChange={onPageChange}
                    onSizeChange={onSizeChange}
                />
            )}
        </div>
    );
}

export default typedMemo(Table);
