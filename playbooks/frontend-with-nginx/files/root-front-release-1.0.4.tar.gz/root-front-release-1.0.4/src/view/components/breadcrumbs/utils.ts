import { matchPath } from 'react-router-dom';

import { Breadcrumb } from './types';

export const getCrumbs = (breadcrumbs: Breadcrumb[], pathname: string) => {
    return breadcrumbs
        .map((crumb) => ({
            ...crumb,
            match: matchPath({ path: crumb.path, end: false }, pathname),
        }))
        .filter(({ match }) => match);
};
