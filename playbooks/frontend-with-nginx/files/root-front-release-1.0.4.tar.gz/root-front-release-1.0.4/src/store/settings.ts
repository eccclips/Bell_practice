import { atom, AtomEffect, useRecoilState, useRecoilValue } from 'recoil';

export enum LAYOUT {
    DESKTOP = 'DESKTOP',
    TABLET = 'TABLET',
    MOBILE = 'MOBILE',
}

export const getLayout = () => {
    if (window.innerWidth > 1024) {
        return LAYOUT.DESKTOP;
    }

    if (window.innerWidth > 768) {
        return LAYOUT.TABLET;
    }

    return LAYOUT.MOBILE;
};

const expandedLocalStorageEffect: AtomEffect<boolean> = ({ setSelf, onSet }) => {
    const key = '@root/isMenuExpandedState';
    const savedValue = localStorage.getItem(key);
    if (getLayout() === LAYOUT.DESKTOP && savedValue != null) {
        setSelf(JSON.parse(savedValue));
    }

    onSet((newValue, _, isReset) => {
        isReset
            ? localStorage.removeItem(key)
            : localStorage.setItem(key, JSON.stringify(newValue));
    });
};

export const windowWidthEffect: AtomEffect<LAYOUT> = ({ setSelf }) => {
    const onResize = () => {
        setSelf(getLayout());
    };

    window.addEventListener('resize', onResize);

    return () => {
        window.removeEventListener('resize', onResize);
    };
};

export const isMenuExpandedState = atom<boolean>({
    key: '@root/isMenuExpandedState',
    default: getLayout() === LAYOUT.DESKTOP ? true : false,
    effects: [expandedLocalStorageEffect],
});

export const useIsMenuExpanded = () => {
    return useRecoilState(isMenuExpandedState);
};

const layoutState = atom<LAYOUT>({
    key: '@root/layoutState',
    default: getLayout(),
    effects: [windowWidthEffect],
});

export const useLayoutState = () => {
    return useRecoilValue(layoutState);
};
