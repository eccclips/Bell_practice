import React, { useCallback, useState } from 'react';

import { Button } from '@mui/material';

import { defaultStyles } from 'root-front/styles';

import {
    ARGUMENT_TYPE,
    ELEMENT_TYPE,
    OPERANDS_LENGTH_FROM_OPERATOR_MAP,
    OPERATOR_TYPE,
} from '../constants';
import { FormulaConstructorProps } from '../types';
import { getDefaultOperands, getEmptyFormula } from '../utils';
import { FormulaPreview } from './formula-preview';
import { Operand } from './operand';

import styles from './FormulaConstructor.module.scss';

const FormulaConstructor = (props: FormulaConstructorProps) => {
    const { name, children, control, setValue, getValues, additionalArguments } = props;

    const [hoveredOperand, setHoveredOperand] = useState<string | null>(null);

    const onHover = useCallback((uid: string | null) => {
        setHoveredOperand(uid);
    }, []);

    const handleChangeElementType = useCallback(
        (prefixName: string) => (e, child, value: ELEMENT_TYPE) => {
            if (value === ELEMENT_TYPE.ARGUMENT) {
                setValue(`${prefixName}argumentType` as any, ARGUMENT_TYPE.CONSTANT);
                setValue(`${prefixName}operator` as any, null);
                setValue(`${prefixName}operands` as any, null);
                setValue(`${prefixName}negative` as any, false);
                setValue(`${prefixName}constant` as any, null);
                setValue(`${prefixName}parameter` as any, null);
            } else {
                setValue(`${prefixName}argumentType` as any, null);
                setValue(`${prefixName}operator` as any, null);
                setValue(`${prefixName}operands` as any, []);
                setValue(`${prefixName}constant` as any, null);
                setValue(`${prefixName}parameter` as any, null);
                setValue(`${prefixName}negative` as any, null);
            }
        },
        []
    );

    const handleChangeOperatorType = useCallback(
        (prefixName: string) => (e, child, value: OPERATOR_TYPE) => {
            const operands = getValues(`${prefixName}operands` as any);
            if (operands?.length < OPERANDS_LENGTH_FROM_OPERATOR_MAP[value].min) {
                setValue(`${prefixName}operands` as any, [
                    ...(operands || []),
                    ...getDefaultOperands(
                        OPERANDS_LENGTH_FROM_OPERATOR_MAP[value].min - operands.length
                    ),
                ]);
            } else if (operands?.length > OPERANDS_LENGTH_FROM_OPERATOR_MAP[value].max) {
                setValue(
                    `${prefixName}operands` as any,
                    operands.slice(0, OPERANDS_LENGTH_FROM_OPERATOR_MAP[value].max)
                );
            }
        },
        []
    );

    const handleChangeArgumentType = useCallback(
        (prefixName: string) => () => {
            setValue(`${prefixName}constant` as any, null);
            setValue(`${prefixName}parameter` as any, null);
            setValue(`${prefixName}negative` as any, false);
        },
        []
    );

    const handleAppendOperand = useCallback(
        (prefixName: string) => () => {
            const operands = getValues(`${prefixName}operands` as any);
            setValue(`${prefixName}operands` as any, [...operands, ...getDefaultOperands(1)], {
                shouldDirty: true,
            });
        },
        []
    );

    const handleRemoveOperand = useCallback(
        (prefixName: string) => () => {
            // Достаем из строки вида 'operands.N.operands.M.' значения 'operands.N.operands' и M
            const nameArray = prefixName.slice(0, -1).split('.');
            const index = +nameArray[nameArray.length - 1];
            const name = nameArray.slice(0, -1).join('.');

            // Удаляем из operands.N.operands элемент с индексом M
            const operands = [...getValues(name as any)];
            operands.splice(index, 1);
            setValue(name as any, operands, { shouldDirty: true });
        },
        []
    );

    const handleResetFormula = () => {
        const emptyFormula = getEmptyFormula();
        setValue(name, emptyFormula, { shouldDirty: true });

        // Нужно для индексации изменений этих полей в useWatch
        setValue(`${name}.uid`, emptyFormula.uid);
        setValue(`${name}.type`, emptyFormula.type);
        setValue(`${name}.argumentType`, (emptyFormula as any).argumentType);
        setValue(`${name}.operands`, null);
    };

    return (
        <div className={styles.container}>
            <FormulaPreview
                control={control}
                prefixName={`${name}.`}
                hoveredOperand={hoveredOperand}
                onHover={onHover}
                size="medium"
            />

            <Operand
                prefixName={`${name}.`}
                control={control}
                hoveredOperand={hoveredOperand}
                title=""
                handleChangeElementType={handleChangeElementType}
                handleChangeOperatorType={handleChangeOperatorType}
                handleChangeArgumentType={handleChangeArgumentType}
                handleAppendOperand={handleAppendOperand}
                handleRemoveOperand={handleRemoveOperand}
                additionalArguments={additionalArguments}
            >
                {children || (
                    <div className={defaultStyles.header__actions}>
                        <Button variant="outlined" color="secondary" onClick={handleResetFormula}>
                            Очистить
                        </Button>
                    </div>
                )}
            </Operand>
        </div>
    );
};

export default React.memo(FormulaConstructor);
