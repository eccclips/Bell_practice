import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const OrderMFE = React.lazy(() => loadModule(process.env.MFE_ORDER_HOST, './Order'));

export function OrderRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <OrderMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
