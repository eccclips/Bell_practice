import React, { useMemo } from 'react';

import { FormControlLabel, IconButton, SvgIcon } from '@mui/material';
import cn from 'classnames';
import { useWatch } from 'react-hook-form';

import { Icons } from 'root-front/icons';

import { Fields } from '../../../../fields';
import {
    ADDITIONAL_ARGUMENT_TYPE_OPTIONS,
    ARGUMENT_TYPE,
    ARGUMENT_TYPE_OPTIONS,
    ELEMENT_TYPE,
    ELEMENT_TYPE_OPTIONS,
} from '../../../constants';
import { FormulaConstructorOperandProps } from '../../../types';
import {
    getSelectOptionFromCustomFormula,
    getSelectOptionFromFormulaParameter,
    getSelectOptionFromResourceB2B,
    getSelectOptionFromResourceOpt,
} from '../../../utils';
import {
    useCustomFormulaDictionary,
    useFormulaParameterDictionary,
    useParametrizedDictionary,
    useSettingFormulaCalcB2BDictionaryById,
    useSettingFormulaCalcOptDictionary,
} from '../../api';
import { FormulaPreview } from '../../formula-preview';

import styles from '../../FormulaConstructor.module.scss';

type Props = Pick<
    FormulaConstructorOperandProps,
    | 'control'
    | 'prefixName'
    | 'handleChangeElementType'
    | 'handleChangeArgumentType'
    | 'handleRemoveOperand'
    | 'deletable'
    | 'additionalArguments'
    | 'children'
>;

const Argument = (props: Props) => {
    const {
        control,
        prefixName,
        handleChangeElementType,
        handleChangeArgumentType,
        handleRemoveOperand,
        additionalArguments = [],
        deletable,
        children,
    } = props;

    const argumentTypeOptions = useMemo(() => {
        const additionalOptions = ADDITIONAL_ARGUMENT_TYPE_OPTIONS.filter((option) =>
            additionalArguments.find((argumentData) => option.key === argumentData.type)
        );

        return [...ARGUMENT_TYPE_OPTIONS, ...additionalOptions];
    }, [additionalArguments]);

    const operandUid = useWatch({
        control,
        name: `${prefixName}uid` as 'formula.uid',
        exact: true,
    });

    const operandType = useWatch({
        control,
        name: `${prefixName}type` as 'formula.type',
        exact: true,
    });

    const operandArgumentType = useWatch({
        control,
        name: `${prefixName}argumentType` as 'formula.argumentType',
        exact: true,
    });

    const requestData = additionalArguments.find(
        (argumentData) => argumentData.type === operandArgumentType
    )?.requestData;

    if (operandType !== ELEMENT_TYPE.ARGUMENT) {
        return null;
    }

    const renderFields = () => {
        switch (operandArgumentType) {
            case ARGUMENT_TYPE.CONSTANT:
                return (
                    <Fields.TextField
                        key={`${operandUid}.constant`}
                        control={control}
                        name={`${prefixName}constant` as any}
                        type="number"
                        inputMode="numeric"
                        rules={{ required: 'Обязательно' }}
                        placeholder="Введите значение"
                        className={styles.row__field}
                    />
                );
            case ARGUMENT_TYPE.PARAMETER:
                return (
                    <>
                        <Fields.QuerySelect
                            key={`${operandUid}.parameter`}
                            control={control}
                            name={`${prefixName}parameter` as any}
                            query={useFormulaParameterDictionary}
                            getOptionFromData={getSelectOptionFromFormulaParameter}
                            rules={{ required: 'Обязательно' }}
                            placeholder="Выберите из справочника"
                            className={cn(styles.row__field, styles.row__field_parameter)}
                        />
                        <FormControlLabel
                            control={
                                <Fields.Checkbox
                                    key={`${operandUid}.negative`}
                                    control={control}
                                    name={`${prefixName}negative` as any}
                                />
                            }
                            label="Отрицательное"
                        />
                    </>
                );
            case ARGUMENT_TYPE.FORMULA:
                return (
                    <>
                        <Fields.QuerySelect
                            key={`${operandUid}.formula`}
                            control={control}
                            name={`${prefixName}parameter` as any}
                            query={useCustomFormulaDictionary}
                            getOptionFromData={getSelectOptionFromCustomFormula}
                            rules={{ required: 'Обязательно' }}
                            placeholder="Выберите из справочника"
                            className={cn(styles.row__field, styles.row__field_parameter)}
                        />
                        <FormControlLabel
                            control={
                                <Fields.Checkbox
                                    key={`${operandUid}.negative`}
                                    control={control}
                                    name={`${prefixName}negative` as any}
                                />
                            }
                            label="Отрицательное"
                        />
                    </>
                );
            case ARGUMENT_TYPE.CUSTOMIZED_PARAMETER:
                return (
                    <>
                        <Fields.QuerySelect
                            key={`${operandUid}.customizedParameter`}
                            control={control}
                            name={`${prefixName}parameter` as any}
                            query={useParametrizedDictionary}
                            getOptionFromData={getSelectOptionFromCustomFormula}
                            rules={{ required: 'Обязательно' }}
                            placeholder="Выберите из справочника"
                            className={cn(styles.row__field, styles.row__field_parameter)}
                        />
                        <FormControlLabel
                            control={
                                <Fields.Checkbox
                                    key={`${operandUid}.negative`}
                                    control={control}
                                    name={`${prefixName}negative` as any}
                                />
                            }
                            label="Отрицательное"
                        />
                    </>
                );
            case ARGUMENT_TYPE.RESOURCE_FORMULA_B2B:
                return (
                    <>
                        <Fields.QuerySelect
                            key={`${operandUid}.b2bResourceFormula`}
                            control={control}
                            name={`${prefixName}parameter` as any}
                            query={useSettingFormulaCalcB2BDictionaryById(requestData)}
                            getOptionFromData={getSelectOptionFromResourceB2B}
                            rules={{ required: 'Обязательно' }}
                            placeholder="Выберите из справочника"
                            className={cn(styles.row__field, styles.row__field_parameter)}
                        />
                        <FormControlLabel
                            control={
                                <Fields.Checkbox
                                    key={`${operandUid}.negative`}
                                    control={control}
                                    name={`${prefixName}negative` as any}
                                />
                            }
                            label="Отрицательное"
                        />
                    </>
                );
            case ARGUMENT_TYPE.RESOURCE_FORMULA_OPT:
                return (
                    <>
                        <Fields.QuerySelect
                            key={`${operandUid}.optResourceFormula`}
                            control={control}
                            name={`${prefixName}parameter` as any}
                            query={useSettingFormulaCalcOptDictionary}
                            getOptionFromData={getSelectOptionFromResourceOpt}
                            rules={{ required: 'Обязательно' }}
                            placeholder="Выберите из справочника"
                            className={cn(styles.row__field, styles.row__field_parameter)}
                        />
                        <FormControlLabel
                            control={
                                <Fields.Checkbox
                                    key={`${operandUid}.negative`}
                                    control={control}
                                    name={`${prefixName}negative` as any}
                                />
                            }
                            label="Отрицательное"
                        />
                    </>
                );
        }
    };

    return (
        <div className={styles.row}>
            <div className={styles.row__start}>
                <Fields.Select
                    control={control}
                    name={`${prefixName}type` as any}
                    options={ELEMENT_TYPE_OPTIONS}
                    onChange={handleChangeElementType(prefixName)}
                    className={styles.row__field}
                />
                <Fields.Select
                    control={control}
                    name={`${prefixName}argumentType` as any}
                    options={argumentTypeOptions}
                    onChange={handleChangeArgumentType(prefixName)}
                    className={styles.row__field}
                />
                {renderFields()}
                {deletable && (
                    <IconButton onClick={handleRemoveOperand(prefixName)}>
                        <SvgIcon>
                            <Icons.Trash />
                        </SvgIcon>
                    </IconButton>
                )}
            </div>
            <div className={styles.row__end}>
                {children || <FormulaPreview control={control} prefixName={prefixName} />}
            </div>
        </div>
    );
};

export default React.memo(Argument);
