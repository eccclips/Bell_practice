import { CHIP_COLORS } from 'root-front/components';

export enum AVAILABILITY_CATEGORY_TYPE {
    RESERVE = 'RESERVE',
    RESOURCE = 'RESOURCE',
}

export enum AVAILABILITY_CATEGORY_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
}

export const AVAILABILITY_CATEGORY_STATUS_MAP = {
    [AVAILABILITY_CATEGORY_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [AVAILABILITY_CATEGORY_STATUS.DRAFT]: { text: 'Черновик', color: CHIP_COLORS.DRAFT },
    [AVAILABILITY_CATEGORY_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};

export const AVAILABILITY_CATEGORY_TYPE_MAP = {
    [AVAILABILITY_CATEGORY_TYPE.RESERVE]: { text: 'Запас' },
    [AVAILABILITY_CATEGORY_TYPE.RESOURCE]: { text: 'Ресурс' },
};

export enum GUARANTEED_RESERVE_CALC_STATUS {
    NEW = 'NEW',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    ERROR = 'ERROR',
}

export const GUARANTEED_RESERVE_CALC_STATUS_MAP = {
    [GUARANTEED_RESERVE_CALC_STATUS.NEW]: { text: 'Новый', color: CHIP_COLORS.DRAFT },
    [GUARANTEED_RESERVE_CALC_STATUS.IN_PROGRESS]: { text: 'В работе', color: CHIP_COLORS.SUCCESS },
    [GUARANTEED_RESERVE_CALC_STATUS.ERROR]: { text: 'Ошибка', color: CHIP_COLORS.ERROR },
    [GUARANTEED_RESERVE_CALC_STATUS.COMPLETED]: { text: 'Выполнен', color: CHIP_COLORS.NEUTRAL },
};

export enum GUARANTEED_RESERVE_TASK_TYPE {
    CALCULATED = 'CALCULATED',
    EXCEL = 'EXCEL',
    MANUAL = 'MANUAL',
}

export const GUARANTEED_RESERVE_TASK_TYPE_MAP = {
    [GUARANTEED_RESERVE_TASK_TYPE.CALCULATED]: { text: 'Расчет', color: CHIP_COLORS.NEUTRAL },
    [GUARANTEED_RESERVE_TASK_TYPE.EXCEL]: { text: 'Импорт из Excel', color: CHIP_COLORS.SUCCESS },
    [GUARANTEED_RESERVE_TASK_TYPE.MANUAL]: {
        text: 'Корректировка ГЗ на GUI',
        color: CHIP_COLORS.DRAFT,
    },
};

export enum FORMULA_TYPE {
    INCOMING_RESOURCE_M0 = 'INCOMING_RESOURCE_M0',
    FREE_RESOURCE_M1_M5 = 'FREE_RESOURCE_M1_M5',
    DEFICIT_M1 = 'DEFICIT_M1',
    FREE_AVAILABILITY = 'FREE_AVAILABILITY',
    FREE_RESOURCE = 'FREE_RESOURCE',
    RESOURCE_B2B_CHART_PRODUCT = 'RESOURCE_B2B_CHART_PRODUCT',
    RESOURCE_B2B_OTHER_PRODUCT = 'RESOURCE_B2B_OTHER_PRODUCT',
    RESOURCE_B2B = 'RESOURCE_B2B',
}

export const FORMULA_TYPE_MAP = {
    [FORMULA_TYPE.DEFICIT_M1]: { text: 'Дефицит М+1' },
    [FORMULA_TYPE.FREE_AVAILABILITY]: { text: 'Свободное наличие расчета для В2В' },
    [FORMULA_TYPE.FREE_RESOURCE_M1_M5]: { text: 'Свободный ресурс (М+1 - М+5)' },
    [FORMULA_TYPE.RESOURCE_B2B_CHART_PRODUCT]: { text: 'Ресурс В2В для графиковой номенклатуры' },
    [FORMULA_TYPE.RESOURCE_B2B_OTHER_PRODUCT]: { text: 'Ресурс В2В для прочей номенклатуры' },
    [FORMULA_TYPE.INCOMING_RESOURCE_M0]: { text: 'Входящий ресурс (ресурс на итог М0)' },
    [FORMULA_TYPE.FREE_RESOURCE]: { text: 'Свободный ресурс для расчета В2В' },
    [FORMULA_TYPE.RESOURCE_B2B]: { text: 'Ресурс В2В для своих' },
};

export enum CALC_TASK_B2B_STATUS {
    NEW = 'NEW',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    ERROR = 'ERROR',
}

export const CALC_TASK_B2B_STATUS_MAP = {
    [CALC_TASK_B2B_STATUS.NEW]: { text: 'Новый', color: CHIP_COLORS.NEUTRAL },
    [CALC_TASK_B2B_STATUS.IN_PROGRESS]: { text: 'В работе', color: CHIP_COLORS.DRAFT },
    [CALC_TASK_B2B_STATUS.COMPLETED]: {
        text: 'Выполнен',
        color: CHIP_COLORS.SUCCESS,
    },
    [CALC_TASK_B2B_STATUS.ERROR]: { text: 'Ошибка', color: CHIP_COLORS.NEUTRAL },
};

export enum SALES_FORECAST_TYPE {
    DEALER = 'DEALER',
    WHOLESALE_OPERATOR = 'WHOLESALE_OPERATOR',
}

export const SALES_FORECAST_TYPE_MAP = {
    [SALES_FORECAST_TYPE.DEALER]: {
        text: 'Дилер',
    },
    [SALES_FORECAST_TYPE.WHOLESALE_OPERATOR]: {
        text: 'Оптовый оператор',
    },
};

export enum ACCESSIBLE_RESOURCE_TYPE {
    MAIN_RESOURCE = 'MAIN_RESOURCE',
    ADDITIONAL_RESOURCE = 'ADDITIONAL_RESOURCE',
}

export const ACCESSIBLE_RESOURCE_TYPE_MAP = {
    [ACCESSIBLE_RESOURCE_TYPE.MAIN_RESOURCE]: { text: 'Основной' },
    [ACCESSIBLE_RESOURCE_TYPE.ADDITIONAL_RESOURCE]: { text: 'Дополнительный ресурс' },
};

export enum INTERNAL_ACCESSIBLE_RESOURCE_STATUS {
    DRAFT = 'DRAFT',
    IN_PROGRESS = 'IN_PROGRESS',
    ACCEPTED = 'ACCEPTED',
    COMPLETED = 'COMPLETED',
    REMOVED = 'REMOVED',
    SENT = 'SENT',
    PUBLISHED = 'PUBLISHED',
    RECALL_CLOSED = 'RECALL_CLOSED',
    RECALL_SENT = 'RECALL_SENT',
}

export const INTERNAL_ACCESSIBLE_RESOURCE_STATUS_MAP = {
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.DRAFT]: { text: 'Черновик', color: CHIP_COLORS.DRAFT },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.COMPLETED]: {
        text: 'Обработан',
        color: CHIP_COLORS.SUCCESS,
    },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.REMOVED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.SENT]: { text: 'Направлен', color: CHIP_COLORS.NEUTRAL },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.RECALL_SENT]: {
        text: 'Направлен отзыв',
        color: CHIP_COLORS.NEUTRAL,
    },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.IN_PROGRESS]: {
        text: 'В обработке',
        color: CHIP_COLORS.DRAFT,
    },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.ACCEPTED]: {
        text: 'Проведен',
        color: CHIP_COLORS.NEUTRAL,
    },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.RECALL_CLOSED]: {
        text: 'Запрещен отзыв',
        color: CHIP_COLORS.DISABLED,
    },
    [INTERNAL_ACCESSIBLE_RESOURCE_STATUS.PUBLISHED]: {
        text: 'Опубликован',
        color: CHIP_COLORS.SUCCESS,
    },
};

export enum EXTERNAL_ACCESSIBLE_RESOURCE_STATUS {
    DELIVERED = 'DELIVERED',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    DELETED = 'DELETED ',
}

export const EXTERNAL_ACCESSIBLE_RESOURCE_STATUS_MAP = {
    [EXTERNAL_ACCESSIBLE_RESOURCE_STATUS.DELIVERED]: {
        text: 'Получен',
        color: CHIP_COLORS.NEUTRAL,
    },
    [EXTERNAL_ACCESSIBLE_RESOURCE_STATUS.IN_PROGRESS]: {
        text: 'В обработке',
        color: CHIP_COLORS.DRAFT,
    },
    [EXTERNAL_ACCESSIBLE_RESOURCE_STATUS.COMPLETED]: {
        text: 'Обработан',
        color: CHIP_COLORS.SUCCESS,
    },
    [EXTERNAL_ACCESSIBLE_RESOURCE_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
};

export enum RESOURCE_OPT_TYPE {
    TRANSIT = 'TRANSIT',
    WHOLESALE = 'WHOLESALE',
    TOP_PRODUCT = 'TOP_PRODUCT',
}

export const RESOURCE_OPT_TYPE_MAP = {
    [RESOURCE_OPT_TYPE.TOP_PRODUCT]: { text: 'Ресурс по топовой номенклатуре' },
    [RESOURCE_OPT_TYPE.WHOLESALE]: { text: 'Ресурс оптовых операторов' },
    [RESOURCE_OPT_TYPE.TRANSIT]: { text: 'Ресурс по транзитным поставщикам' },
};

export enum PRODUCT_SETTINGS_OPT {
    ONLY_ADDITIONAL = 'ONLY_ADDITIONAL',
    MAIN_SET = 'MAIN_SET',
    BY_MAIN_PRODUCT = 'BY_MAIN_PRODUCT',
}

export const PRODUCT_SETTINGS_OPT_MAP = {
    [PRODUCT_SETTINGS_OPT.ONLY_ADDITIONAL]: { text: 'Расчет только по выбранной номенклатуре' },
    [PRODUCT_SETTINGS_OPT.MAIN_SET]: { text: 'Добавить номенклатуру к основному списку' },
    [PRODUCT_SETTINGS_OPT.BY_MAIN_PRODUCT]: { text: 'Расчет по основной номенклатуре' },
};

export enum CALC_TASK_OPT_STATUS {
    NEW = 'NEW',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    CANCELED = 'CANCELED',
    ERROR = 'ERROR',
}

export const CALC_TASK_OPT_STATUS_MAP = {
    [CALC_TASK_OPT_STATUS.NEW]: {
        text: 'Запланировано',
        color: CHIP_COLORS.NEUTRAL,
    },
    [CALC_TASK_OPT_STATUS.IN_PROGRESS]: {
        text: 'В работе',
        color: CHIP_COLORS.DRAFT,
    },
    [CALC_TASK_OPT_STATUS.COMPLETED]: {
        text: 'Завершено',
        color: CHIP_COLORS.SUCCESS,
    },
    [CALC_TASK_OPT_STATUS.CANCELED]: {
        text: 'Отменено',
        color: CHIP_COLORS.ERROR,
    },
    [CALC_TASK_OPT_STATUS.ERROR]: {
        text: 'Ошибка',
        color: CHIP_COLORS.ERROR,
    },
};

export enum SECURED_TYPE {
    SECURED = 'SECURED',
    UNSECURED = 'UNSECURED',
}

export const SECURED_TYPE_MAP = {
    [SECURED_TYPE.SECURED]: { text: 'Обеспечено' },
    [SECURED_TYPE.UNSECURED]: { text: 'Не обеспечено' },
};

export enum STOCK_AND_RESOURCE_INDICATOR_TYPE {
    STOCK_OUT = 'STOCK_OUT',
    RESERVE_OUT = 'RESERVE_OUT',
    STOCK_IN = 'STOCK_IN',
}

export const STOCK_AND_RESOURCE_INDICATOR_TYPE_MAP = {
    [STOCK_AND_RESOURCE_INDICATOR_TYPE.STOCK_OUT]: {
        text: 'Зарезервированный запас в исходящих (неотгруженных) внутренних перемещениях',
    },
    [STOCK_AND_RESOURCE_INDICATOR_TYPE.RESERVE_OUT]: {
        text: 'Забронированный ресурс в исходящих (неотгруженных) внутренних перемещениях',
    },
    [STOCK_AND_RESOURCE_INDICATOR_TYPE.STOCK_IN]: {
        text: 'Запас к поступлению по входящим внутренним перемещениям',
    },
};

export enum WHOLESALE_DEMAND_TYPE {
    CREATE = 'CREATE',
    UPDATE = 'UPDATE',
}

export const WHOLESALE_DEMAND_TYPE_MAP = {
    [WHOLESALE_DEMAND_TYPE.CREATE]: { text: 'Первоначальная' },
    [WHOLESALE_DEMAND_TYPE.UPDATE]: { text: 'Уточненная' },
};

export enum CALC_TASK_AVAILABILITY_REASON_TYPE {
    SCHEDULE = 'SCHEDULE',
    MANUAL = 'MANUAL',
    CHANGE_SET_WAREHOUSES = 'CHANGE_SET_WAREHOUSES',
    CHANGE_CALC_FORMULA = 'CHANGE_CALC_FORMULA',
}

export const CALC_TASK_AVAILABILITY_REASON_TYPE_MAP = {
    [CALC_TASK_AVAILABILITY_REASON_TYPE.SCHEDULE]: { text: 'По расписанию' },
    [CALC_TASK_AVAILABILITY_REASON_TYPE.CHANGE_CALC_FORMULA]: { text: 'Изменение формул расчета' },
    [CALC_TASK_AVAILABILITY_REASON_TYPE.CHANGE_SET_WAREHOUSES]: {
        text: 'Изменение списка складов',
    },
    [CALC_TASK_AVAILABILITY_REASON_TYPE.MANUAL]: { text: 'Ручное обновление' },
};

export enum CALC_TASK_AVAILABILITY_STATUS {
    NEW = 'NEW',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    CANCELED = 'CANCELED',
    ERROR = 'ERROR',
}

export const CALC_TASK_AVAILABILITY_STATUS_MAP = {
    [CALC_TASK_AVAILABILITY_STATUS.NEW]: {
        text: 'Запланировано',
        color: CHIP_COLORS.NEUTRAL,
    },
    [CALC_TASK_AVAILABILITY_STATUS.IN_PROGRESS]: {
        text: 'В работе',
        color: CHIP_COLORS.DRAFT,
    },
    [CALC_TASK_AVAILABILITY_STATUS.COMPLETED]: {
        text: 'Завершено',
        color: CHIP_COLORS.SUCCESS,
    },
    [CALC_TASK_AVAILABILITY_STATUS.CANCELED]: {
        text: 'Отменено',
        color: CHIP_COLORS.ERROR,
    },
    [CALC_TASK_AVAILABILITY_STATUS.ERROR]: {
        text: 'Ошибка',
        color: CHIP_COLORS.ERROR,
    },
};

export enum RESOURCES_EXCLUDE_TYPE {
    EXCLUDE_B2B = 'EXCLUDE_B2B',
    EXCLUDE_B2B_SELF = 'EXCLUDE_B2B_SELF',
    EXCLUDE_B2B_SELF_IMPORT = 'EXCLUDE_B2B_SELF_IMPORT',
    EXCLUDE_WHOLESALE = 'EXCLUDE_WHOLESALE',
}

export enum DOCUMENT_RESOURCE_WAREHOUSE_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
    CLOSED = 'CLOSED',
    PENDING = 'PENDING',
}

export const DOCUMENT_RESOURCE_WAREHOUSE_STATUS_MAP = {
    [DOCUMENT_RESOURCE_WAREHOUSE_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [DOCUMENT_RESOURCE_WAREHOUSE_STATUS.DRAFT]: { text: 'Черновик', color: CHIP_COLORS.DRAFT },
    [DOCUMENT_RESOURCE_WAREHOUSE_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
    [DOCUMENT_RESOURCE_WAREHOUSE_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [DOCUMENT_RESOURCE_WAREHOUSE_STATUS.PENDING]: {
        text: 'Ожидает активации',
        color: CHIP_COLORS.DISABLED,
    },
};

export enum RESOURCES_EXCLUDE_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
    CLOSED = 'CLOSED',
    PENDING = 'PENDING',
}

export const RESOURCES_EXCLUDE_STATUS_MAP = {
    [RESOURCES_EXCLUDE_STATUS.ACTIVE]: { text: 'Действует', color: CHIP_COLORS.SUCCESS },
    [RESOURCES_EXCLUDE_STATUS.DRAFT]: { text: 'Черновик', color: CHIP_COLORS.DRAFT },
    [RESOURCES_EXCLUDE_STATUS.DELETED]: { text: 'Удален', color: CHIP_COLORS.ERROR },
    [RESOURCES_EXCLUDE_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [RESOURCES_EXCLUDE_STATUS.PENDING]: {
        text: 'Ожидает активации',
        color: CHIP_COLORS.DISABLED,
    },
};
