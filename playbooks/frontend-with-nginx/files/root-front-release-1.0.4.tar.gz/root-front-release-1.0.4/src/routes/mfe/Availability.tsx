import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const AvailabilityMFE = React.lazy(() =>
    loadModule(process.env.MFE_AVAILABILITY_HOST, './Availability')
);

export function AvailabilityRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <AvailabilityMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
