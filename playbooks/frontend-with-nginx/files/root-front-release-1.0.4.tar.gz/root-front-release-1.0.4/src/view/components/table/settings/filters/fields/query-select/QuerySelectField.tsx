import React, { useCallback } from 'react';

import { Control, UseFormSetValue } from 'react-hook-form';

import { QuerySelectProps } from 'root-front/components';

import { Fields, SelectOption } from '../../../../../fields';

import styles from './QuerySelectField.module.scss';

type QuerySelectFieldProps<T> = {
    control: Control<T>;
    name: any;
    label: string;
    multiple?: boolean;
    placeholder?: string;
    query?: QuerySelectProps<any>['query'];
    getOptionFromData?: QuerySelectProps<any>['getOptionFromData'];
    getOptionFromValue?: QuerySelectProps<any>['getOptionFromValue'];
    getOptionDisabled?: QuerySelectProps<any>['getOptionDisabled'];
    groupBy?: (option: SelectOption<any>) => string;
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
    setValue: UseFormSetValue<Record<string, any>>;
    saveSearchInputValue?: boolean;
};

const QuerySelectField = <T,>(props: QuerySelectFieldProps<T>) => {
    const {
        control,
        name,
        label,
        placeholder,
        multiple,
        query,
        getOptionFromData,
        getOptionFromValue,
        getOptionDisabled,
        groupBy,
        onChange,
        setValue,
        saveSearchInputValue,
    } = props;

    const handleChange = useCallback(
        (value: any) => {
            onChange?.(value, setValue);
        },
        [onChange, setValue]
    );

    const id = `filter__${name}`;

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <div className={styles.container}>
                <Fields.QuerySelect
                    control={control}
                    name={name}
                    placeholder={
                        typeof placeholder === 'string' ? placeholder : 'Выберите из справочника'
                    }
                    query={query}
                    getOptionFromData={getOptionFromData}
                    getOptionFromValue={getOptionFromValue}
                    getOptionDisabled={getOptionDisabled}
                    multiple={multiple}
                    groupBy={groupBy}
                    onChange={handleChange}
                    saveSearchInputValue={saveSearchInputValue}
                />
            </div>
        </>
    );
};

export default React.memo(QuerySelectField);
