import React, { useCallback } from 'react';

import { Control, UseFormSetValue } from 'react-hook-form';

import { Fields } from '../../../../../fields';
import { QuerySelectWithModalProps } from '../../../../../query-select';

import styles from './QuerySelectWithModalField.module.scss';

type QuerySelectWithModalFieldProps<T> = {
    control: Control<T>;
    name: any;
    label: string;
    multiple: boolean;
    placeholder: string;
    modalTableName: string;
    query: QuerySelectWithModalProps<any, any, any>['query'];
    queryParams: QuerySelectWithModalProps<any, any, any>['queryParams'];
    defaultParams: QuerySelectWithModalProps<any, any, any>['defaultParams'];
    columns: QuerySelectWithModalProps<any, any, any>['columns'];
    slots: QuerySelectWithModalProps<any, any, any>['slots'];
    mode: QuerySelectWithModalProps<any, any, any>['mode'];
    searchable: boolean;
    getOptionFromData: QuerySelectWithModalProps<any, any, any>['getOptionFromData'];
    onChange: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
    setValue: UseFormSetValue<Record<string, any>>;
};

const QuerySelectWithModalField = <T,>(props: QuerySelectWithModalFieldProps<T>) => {
    const {
        control,
        name,
        label,
        placeholder,
        multiple,
        modalTableName,
        query,
        queryParams,
        defaultParams,
        columns,
        slots,
        mode,
        searchable,
        getOptionFromData,
        onChange,
        setValue,
    } = props;

    const handleChange = useCallback(
        (value: any) => {
            onChange?.(value, setValue);
        },
        [onChange, setValue]
    );

    const id = `filter__${name}`;

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <div className={styles.container}>
                <Fields.QuerySelectWithModal
                    control={control}
                    name={name}
                    modalTableName={modalTableName}
                    query={query}
                    queryParams={queryParams}
                    defaultParams={defaultParams}
                    getOptionFromData={getOptionFromData}
                    columns={columns}
                    searchable={searchable}
                    placeholder={
                        typeof placeholder === 'string' ? placeholder : 'Выберите из справочника'
                    }
                    onChange={handleChange}
                    slots={slots}
                    multiple={multiple}
                    mode={mode}
                />
            </div>
        </>
    );
};

export default React.memo(QuerySelectWithModalField);
