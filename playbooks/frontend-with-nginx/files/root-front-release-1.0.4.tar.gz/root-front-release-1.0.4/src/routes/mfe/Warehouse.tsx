import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const WarehouseMFE = React.lazy(() => loadModule(process.env.MFE_WAREHOUSE_HOST, './Warehouse'));

export function WarehouseRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <WarehouseMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
