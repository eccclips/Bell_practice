import { ReactElement, ReactNode } from 'react';

export type HorizontalTab = {
    key: string;
    label: string;
    renderPage: ReactNode;
    icon?: string | ReactElement;
};

export type HorizontalTabsProps = {
    tabs: HorizontalTab[];
    defaultTabKey: string;
    activeTab?: string;
    onChange?: (tab: string) => void;
};
