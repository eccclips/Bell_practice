import { CustomFormulaDTO, FormulaParameterDTO, FormulaVariableDTO } from 'root-front/dictionaries';
import { randomUUID } from 'root-front/utils';

import { ARGUMENT_TYPE, ELEMENT_TYPE, OPERATOR_TYPE } from './constants';
import { Formula } from './types';

export const getEmptyFormula = (): Formula => ({
    uid: randomUUID(),
    type: ELEMENT_TYPE.ARGUMENT,
    argumentType: ARGUMENT_TYPE.CONSTANT,
    constant: null,
});

export const getDefaultOperands = (length: number): Formula[] =>
    Array.from({ length }).map(() => ({
        uid: randomUUID(),
        type: ELEMENT_TYPE.ARGUMENT,
        argumentType: ARGUMENT_TYPE.CONSTANT,
        constant: null,
        negative: false,
    }));

export const getOperandTitle = (operator: OPERATOR_TYPE, index: number) => {
    switch (operator) {
        case OPERATOR_TYPE.PLUS:
            return `Слагаемое ${index + 1}`;
        case OPERATOR_TYPE.MINUS:
            if (index === 0) {
                return `Уменьшаемое`;
            }
            return `Вычитаемое ${index}`;
        case OPERATOR_TYPE.DIVIDE:
        case OPERATOR_TYPE.DIV:
        case OPERATOR_TYPE.MOD:
            if (index === 0) {
                return 'Делимое';
            }
            return 'Делитель';
        case OPERATOR_TYPE.MULTIPLY:
            return `Множитель ${index + 1}`;
        case OPERATOR_TYPE.POW:
            if (index === 0) {
                return 'Основание степени';
            }
            return 'Показатель степени';
        case OPERATOR_TYPE.SQRT:
            return 'Выражение под корнем';
        case OPERATOR_TYPE.MAX:
        case OPERATOR_TYPE.MIN:
            return `Значение ${index + 1}`;
        case OPERATOR_TYPE.FLOOR:
        case OPERATOR_TYPE.CEIL:
            return 'Округляемое';
        case OPERATOR_TYPE.ABS:
            return 'Значение';
        default:
            return '';
    }
};

export const getSelectOptionFromFormulaParameter = (data: FormulaParameterDTO) => ({
    key: data.id,
    label: `${data.name} (${data.code})`,
    value: data,
});

export const getSelectOptionFromCustomFormula = (data: CustomFormulaDTO) => ({
    key: data.id,
    label: `${data.name} (${data.code})`,
    value: data,
});

export const getSelectOptionFromResourceOpt = (data: FormulaVariableDTO) => ({
    key: data.id,
    label: data.name,
    value: data,
});

export const getSelectOptionFromResourceB2B = (data: FormulaVariableDTO) => ({
    key: data.id,
    label: data.name,
    value: data,
});
