import {
    BASE_STATUS,
    ContractorAgreementDTO,
    CounterpartyDTO,
    ORDER_TYPE,
    OrderDTO,
    ProductDTO,
    SupplyChainDTO,
    WAREHOUSE_DOCUMENT_ACTION_TYPE,
    WAREHOUSE_DOCUMENT_ITEM_STATUS,
    WAREHOUSE_DOCUMENT_STATUS,
    WAREHOUSE_DOCUMENT_TYPE,
    WarehouseDTO,
    ZNO_REQUEST_TASK_STATUS,
} from 'root-front/dictionaries';
import { BaseAuditedDTO } from 'root-front/interfaces';

import { PROVISION_SOURCE } from '../constants';

export interface WarehouseDocumentItemDTO extends BaseAuditedDTO {
    externalId: string;
    syntheticId: string;
    storagePositionNumber: string;
    status: WAREHOUSE_DOCUMENT_ITEM_STATUS;
    product: ProductDTO;
    orderItemProduct: ProductDTO;
    quantity: number;
    quantityUnreserved: number;
    quantityFinished: number;
    quantityRefused: number;
    wsoPartyId: number;
    orderItemId: number;
    price: number;
    plannedSupplyDate: string;
    plannedShipmentDate: string;
    plannedAvailabilityDate: string;
    provisionSource: PROVISION_SOURCE;
    warehouseDocument?: WarehouseDocumentDTO;
    order?: OrderDTO;
}

export interface WarehouseDocumentItemGroupDTO {
    id: number;
    product: ProductDTO;
    quantity: number;
    quantitySecured: number;
    quantityReserved: number;
    quantityZno: number;
    quantityRefused: number;
    quantityFinished: number;
    quantityUnreserved: number;
}

export interface WarehouseDocumentTypeDTO extends BaseAuditedDTO {
    externalId: string;
    code: string;
    name: string;
    type: WAREHOUSE_DOCUMENT_TYPE;
    mask: string;
}

export interface WarehouseDocumentDTO extends BaseAuditedDTO {
    externalId: string;
    documentType: WarehouseDocumentTypeDTO;
    warehouseOrderTypeId: number;
    agreement: ContractorAgreementDTO;
    routeCode: string;
    customerOrderId: number;
    parentDocumentId: number;
    number: string;
    status: WAREHOUSE_DOCUMENT_STATUS;
    documentActionType: WAREHOUSE_DOCUMENT_ACTION_TYPE;
    shipper: CounterpartyDTO;
    customer: CounterpartyDTO;
    consignee: CounterpartyDTO;
    transitWarehouseIds: number[];
    supplyChain: SupplyChainDTO;
    order: OrderDTO;
    crossDocking: boolean;
    residualControl: boolean;
    comment: string;
    plannedPublishDate: string;
    actualPublishDate: string;
    processingResultCode: string;
    rootDocumentId: number;
    customerOrderType: ORDER_TYPE;
    items?: WarehouseDocumentItemDTO[];
    totalAmount?: number;
    totalVolume?: number;
    totalWeight?: number;
    taskId?: number;
    assemblyWarehouse: WarehouseDTO;
    consigneeWarehouse: WarehouseDTO;
    manual?: boolean;
}

export type WarehouseDocumentTreeElementDTO = WarehouseDocumentDTO & {
    childWarehouseDocumentDtoList?: WarehouseDocumentDTO[];
    order?: OrderDTO;
};

export interface CustomerOrderDTO extends BaseAuditedDTO {
    externalId: string;
    znoRequestTaskId: number;
    order: OrderDTO;
}

export interface ZnoRequestTaskDTO extends BaseAuditedDTO {
    externalId: string;
    number: number;
    customerOrderType: ORDER_TYPE;
    senderWarehouses: WarehouseDTO[];
    maxWeight: number;
    maxVolume: number;
    maxAmount: number;
    limitsAutoApply: boolean;
    useCutOff: boolean;
    usePackingType: boolean;
    noCrossDocking: boolean;
    manual: boolean;
    comment: string;
    status: ZNO_REQUEST_TASK_STATUS;
    customerOrders: CustomerOrderDTO[];
}

export interface ReservationItemDTO extends BaseAuditedDTO {
    product: ProductDTO;
    orderItemProduct: ProductDTO;
    orderItemId: number;
    provisionSource: string;
    quantity: string;
    quantityZno: string;
    status: BASE_STATUS;
    syntheticId: string;
    totalPrice: string;
    totalVolume: string;
    totalWeight: string;
    plannedAvailabilityDate: string;
    plannedShipmentDate: string;
    plannedSupplyDate: string;
    price: string;
    priority: number;
    warehouseDocument: WarehouseDocumentDTO;
}

export interface ZnoRequestTaskItemDTO extends BaseAuditedDTO {
    externalId: string;
    znoRequestTaskId: number;
    warehouse: WarehouseDTO;
    reservationItem: ReservationItemDTO;
    quantity: number;
    priority: number;
    weight: number;
    volume: number;
    price: number;
    totalAmount: number;
    included: boolean;
    znoRequestItemId: number;
}

export interface ExecuteOrderDto extends BaseAuditedDTO {
    order: OrderDTO;
    delayExecutionDays: number; // TODO check
    priority: string;
    financialLimitAmount: number;
}
