import React, { useMemo } from 'react';

import cn from 'classnames';

import { typedMemo, useEvent } from 'root-front/utils';

import emptyListUrl from '../../../../assets/icons/empty-list.svg?url';
import { ErrorPage } from '../../error-page';
import { LoaderOverlay } from '../../loader-overlay';
import { TableBody } from '../body';
import { TableHead } from '../head';
import { SimpleTableProps, TABLE_VIEW_MODE, TableData } from '../types';
import { ERROR_TEXT, getFilteredData } from './constants';
import { getFlatColumns } from './utils';

import styles from '../Table.module.scss';

const SimpleTable = <Data,>(props: SimpleTableProps<Data>) => {
    const {
        data,
        columns,
        dataKey = 'id',
        viewMode = TABLE_VIEW_MODE.FULL_HEIGHT,
        sort,
        checkboxSelection,
        selectedRows,
        groupModel,
        expandable,
        emptyText,
        renderExpandedContent,
        onRowClick,
        onSortChange,
        onSelectedRowsChange,
        getRowSelectionDisabled,
        onColumnResize,
        getRowError,
        getRowHighlight,
        isError,
        isEmpty,
        isLoading,
    } = props;

    const flatColumns = useMemo(() => getFlatColumns(columns), [columns]);

    const isScrollable = viewMode === TABLE_VIEW_MODE.INNER_SCROLL;

    const isAllRowsSelected = useMemo(() => {
        if (!checkboxSelection) {
            return false;
        }

        const filteredData = getFilteredData(data, getRowSelectionDisabled);
        return (
            !!filteredData.length &&
            filteredData.every(
                (row) => selectedRows?.find((selectedRow) => selectedRow[dataKey] === row[dataKey])
            )
        );
    }, [checkboxSelection, data, selectedRows, getRowSelectionDisabled]);

    const isIndeterminate = useMemo(() => {
        if (!checkboxSelection) {
            return false;
        }

        return (
            !isAllRowsSelected &&
            !!getFilteredData(data, getRowSelectionDisabled).some(
                (row) =>
                    !!selectedRows?.find((selectedRow) => selectedRow[dataKey] === row[dataKey])
            )
        );
    }, [checkboxSelection, data, isAllRowsSelected, selectedRows, getRowSelectionDisabled]);

    const handleSelectRow = useEvent((row: TableData<Data>) => {
        if (isError || isLoading) {
            return;
        }

        let nextSelectedRows = [...(selectedRows || [])];
        const checked = !selectedRows?.find((selectedRow) => selectedRow[dataKey] === row[dataKey]);

        if (checked) {
            nextSelectedRows.push(row);
        } else {
            nextSelectedRows = nextSelectedRows.filter(
                (selectedRow) => selectedRow[dataKey] !== row[dataKey]
            );
        }

        onSelectedRowsChange?.(nextSelectedRows);
    });

    const handleSelectAll = useEvent(() => {
        if (isError || isLoading || isEmpty) {
            return;
        }

        let nextSelectedRows = [...(selectedRows || [])];
        if (isAllRowsSelected) {
            nextSelectedRows = nextSelectedRows.filter(
                (selectedRow) =>
                    !getFilteredData(data, getRowSelectionDisabled).find(
                        (row) => row[dataKey] === selectedRow[dataKey]
                    )
            );
        } else {
            nextSelectedRows = [
                ...nextSelectedRows,
                ...getFilteredData(data, getRowSelectionDisabled),
            ];
        }
        onSelectedRowsChange?.(nextSelectedRows);
    });

    return (
        <div className={styles.container__table}>
            <div
                className={cn(
                    styles.container__tableWrapper,
                    isScrollable && styles.container__tableWrapper_scroll
                )}
            >
                <table className={cn(styles.table, isScrollable && styles.table_scroll)}>
                    <TableHead
                        columns={columns}
                        sort={sort}
                        viewMode={viewMode}
                        checkboxSelection={checkboxSelection}
                        isAllRowsSelected={isAllRowsSelected}
                        isIndeterminate={isIndeterminate}
                        expandable={expandable}
                        groupModel={groupModel}
                        onSortChange={onSortChange}
                        onSelectAll={handleSelectAll}
                        onColumnResize={onColumnResize}
                    />
                    <TableBody
                        data={data}
                        columns={flatColumns}
                        dataKey={dataKey}
                        checkboxSelection={checkboxSelection}
                        selectedRows={selectedRows}
                        expandable={expandable}
                        groupModel={groupModel}
                        renderExpandedContent={renderExpandedContent}
                        onRowClick={onRowClick}
                        onSelectRow={handleSelectRow}
                        getRowSelectionDisabled={getRowSelectionDisabled}
                        getRowError={getRowError}
                        getRowHighlight={getRowHighlight}
                    />
                </table>
            </div>

            {isLoading && <LoaderOverlay />}

            {isEmpty && (
                <div className={styles.container__overflow}>
                    <div className={styles.container__overflow__inner}>
                        <img src={emptyListUrl} alt="Данных не найдено" />
                        <span>{emptyText || 'Данных не найдено'}</span>
                    </div>
                </div>
            )}

            {isError && (
                <div className={styles.container__overflow}>
                    <ErrorPage
                        text={ERROR_TEXT}
                        className={cn(
                            styles.container__overflow__inner,
                            styles.container__overflow__inner_error
                        )}
                    />
                </div>
            )}
        </div>
    );
};

export default typedMemo(SimpleTable);
