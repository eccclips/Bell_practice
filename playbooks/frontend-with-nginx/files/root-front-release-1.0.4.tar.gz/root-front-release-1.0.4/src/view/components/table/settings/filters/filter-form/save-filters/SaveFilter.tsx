import React, { useCallback, useState } from 'react';

import { IconButton, SvgIcon } from '@mui/material';
import { UseFormGetValues } from 'react-hook-form';

import { TableProps } from 'root-front/components';
import { Icons } from 'root-front/icons';

import { SaveFiltersModal } from './modal';

type SaveFilterProps = Pick<TableProps<any>, 'savedFilters'> & {
    getValues: UseFormGetValues<Record<string, any>>;
    setOpenedFilterModal: React.Dispatch<React.SetStateAction<boolean>>;
    hasFilters: boolean;
};

const SaveFilter = (props: SaveFilterProps) => {
    const { savedFilters, getValues, setOpenedFilterModal, hasFilters } = props;
    const [opened, setOpened] = useState(false);

    const handleClose = useCallback(() => {
        setOpened(false);
    }, []);

    const handleSubmit = useCallback((filterName: string) => {
        setOpened(false);

        const values = getValues();
        savedFilters.onSaveFilter?.({ name: filterName, values });
        setOpenedFilterModal(false);
    }, []);

    return (
        <>
            <IconButton disabled={!hasFilters} onClick={() => setOpened(true)} type="button">
                <SvgIcon>
                    <Icons.Bookmark />
                </SvgIcon>
            </IconButton>
            <SaveFiltersModal opened={opened} onClose={handleClose} onSubmit={handleSubmit} />
        </>
    );
};

export default React.memo(SaveFilter);
