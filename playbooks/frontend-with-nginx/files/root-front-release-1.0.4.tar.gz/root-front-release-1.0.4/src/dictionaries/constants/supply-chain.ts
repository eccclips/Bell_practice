import { CHIP_COLORS } from 'root-front/components';

export enum LOGISTIC_ZONE_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
}

export const LOGISTIC_ZONE_STATUS_MAP = {
    [LOGISTIC_ZONE_STATUS.ACTIVE]: {
        text: 'Активный',
        color: CHIP_COLORS.SUCCESS,
    },
    [LOGISTIC_ZONE_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
    [LOGISTIC_ZONE_STATUS.DELETED]: {
        text: 'Удален',
        color: CHIP_COLORS.ERROR,
    },
};

export enum LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON {
    EXCLUDE_LIST = 'EXCLUDE_LIST',
    SUPPLY_PROPERTY = 'SUPPLY_PROPERTY',
    BOTH = 'BOTH',
    NOT_EXCLUDE = 'NOT_EXCLUDE',
    NOT_EXCLUDE_LIST = 'NOT_EXCLUDE_LIST',
}

export const LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON_MAP = {
    [LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON.EXCLUDE_LIST]: {
        text: 'Исключен по списку номенклатуры',
    },
    [LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON.SUPPLY_PROPERTY]: {
        text: 'Исключен по признаку поставки',
    },
    [LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON.BOTH]: {
        text: 'Исключен по списку номенклатуры и по признаку поставки',
    },
};

export enum SUPPLY_CHAIN_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
}

export const SUPPLY_CHAIN_STATUS_MAP = {
    [SUPPLY_CHAIN_STATUS.ACTIVE]: {
        text: 'Активный',
        color: CHIP_COLORS.SUCCESS,
    },
    [SUPPLY_CHAIN_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
    [SUPPLY_CHAIN_STATUS.DELETED]: {
        text: 'Удален',
        color: CHIP_COLORS.ERROR,
    },
};

export enum SUPPLY_CHAIN_SHIPMENT_TYPE {
    DIRECT = 'DIRECT',
    KD = 'KD',
    IN_TRANSIT = 'IN_TRANSIT',
    RESOURCE = 'RESOURCE',
}

export const SUPPLY_CHAIN_SHIPMENT_TYPE_MAP = {
    [SUPPLY_CHAIN_SHIPMENT_TYPE.DIRECT]: {
        text: 'Прямая',
        color: CHIP_COLORS.NEUTRAL,
    },
    [SUPPLY_CHAIN_SHIPMENT_TYPE.KD]: {
        text: 'КД',
        color: CHIP_COLORS.NEUTRAL,
    },
    [SUPPLY_CHAIN_SHIPMENT_TYPE.IN_TRANSIT]: {
        text: 'В пути',
        color: CHIP_COLORS.NEUTRAL,
    },
    [SUPPLY_CHAIN_SHIPMENT_TYPE.RESOURCE]: {
        text: 'Ресурс',
        color: CHIP_COLORS.NEUTRAL,
    },
};
