import { UserInfoUDB } from 'root-front/interfaces';

import {
    LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON,
    LOGISTIC_ZONE_STATUS,
    SUPPLY_CHAIN_SHIPMENT_TYPE,
    SUPPLY_CHAIN_STATUS,
} from '../constants';
import { ContractorAgreementDTO, CounterpartyDTO } from './counterparty';
import { ProductDTO } from './product';
import { WarehouseDTO, WarehouseOrderTypeDTO } from './warehouse';

export interface LogisticZoneSuppliersDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: CounterpartyDTO;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    counterparty: CounterpartyDTO;
    status: string;
}

export interface LogisticZoneShipmentType {
    id?: number;
    externalId?: string;
    isDeleted?: boolean;
    createdDate?: string;
    createdBy?: UserInfoUDB;
    lastModifiedDate?: string;
    lastModifiedBy?: UserInfoUDB;
    paramType: string;
    name: string;
    code: string;
}

export interface LogisticZoneDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    name: string;
    status: LOGISTIC_ZONE_STATUS;
    logisticZoneSuppliers: LogisticZoneSuppliersDTO[];
    notSuppliedProducts: ProductDTO[];
    supplyChains: SupplyChainDTO[];
    excludedParams: LogisticZoneShipmentType[];
}

export interface SupplyChainDTO {
    id: number;
    isDeleted: boolean;
    createdDate: string;
    createdBy: UserInfoUDB;
    lastModifiedDate: string;
    lastModifiedBy: UserInfoUDB;
    status: SUPPLY_CHAIN_STATUS;
    counterparty: CounterpartyDTO;
    agreement: ContractorAgreementDTO;
    warehouseOrderType: WarehouseOrderTypeDTO;
    priority: number;
    shipmentWarehouse: WarehouseDTO;
    pickingWarehouses: WarehouseDTO[];
    shipmentType: SUPPLY_CHAIN_SHIPMENT_TYPE;
    reservationHorizon: number;
    availableResHorizon: number;
    logisticZone: LogisticZoneDTO;
    warehouses: WarehouseDTO[];
}

export interface LogisticZoneProductDTO extends ProductDTO {
    excludeReason: LOGISTIC_ZONE_PRODUCT_EXCLUDE_REASON;
    excluded: boolean;
}
