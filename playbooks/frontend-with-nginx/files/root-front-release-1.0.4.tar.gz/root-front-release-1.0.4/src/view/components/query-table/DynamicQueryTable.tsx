import React, { useCallback, useEffect, useMemo } from 'react';

import { useLocation } from 'react-router-dom';

import { LINK_TYPE_MAP } from 'root-front/constants';
import { DynamicColumnDTO } from 'root-front/interfaces';
import { useTableSettingsState } from 'root-front/store';
import { typedMemo, useEvent } from 'root-front/utils';

import { CHIP_COLORS, TableColumn } from '../../components';
import { DEFAULT_ITEMS_PER_PAGE, Table, TableData } from '../table';
import { TableError } from './components';
import { useParams, useSettings } from './hooks';
import { DynamicQueryTableProps, RowDataMap } from './types';
import {
    getDisplayedColumns,
    getExtendedColumns,
    getMinifiedColumns,
    hasColumnSettingsChanges,
} from './utils';

const DynamicQueryTable = <Params,>(
    props: DynamicQueryTableProps<RowDataMap, TableData<RowDataMap>, Params>
) => {
    const location = useLocation();
    const {
        query,
        saveParamsInURI = true,
        name = location.pathname,
        defaultParams,
        itemsPerPage = DEFAULT_ITEMS_PER_PAGE,
        queryParams,
        allowColumnSettings,
        isLoading: isLoadingProp,
        columnProps = { sortable: true },
        requestFilters,
        chipMap,
        ...rest
    } = props;

    const [tableSettings, setTableSettings] = useTableSettingsState(name);
    const {
        page,
        size,
        sort,
        onPageChange,
        onSizeChange,
        onSortChange,
        handleSetParams,
        fullDefaultParams,
    } = useParams({
        name,
        defaultParams,
        saveParamsInURI,
        itemsPerPage,
    });

    const { data, isFetching, isError, refetch } = query({
        page,
        size,
        sort,
        params: queryParams,
        filters: requestFilters,
    });

    const parsedData: TableData<RowDataMap>[] = useMemo(
        () =>
            data?.data?.rows.map((row) => {
                const cellsMap = {};

                row.cells.forEach((cell) => {
                    cellsMap[cell.key] = { ...cell };
                });

                return {
                    id: row.id,
                    cellsMap,
                };
            }) || [],
        [data]
    );

    const getParsedColumn = useCallback(
        (dynamicColumn: DynamicColumnDTO): TableColumn<RowDataMap> => {
            const baseProperty: TableColumn<RowDataMap> = {
                key: dynamicColumn.key,
                name: dynamicColumn.name,
                type: dynamicColumn.type as any,
                valueGetter: (data) => data.cellsMap[dynamicColumn.key]?.value,
                ...columnProps,
            };

            if (dynamicColumn.children) {
                baseProperty.children = dynamicColumn.children.map((childColumn) =>
                    getParsedColumn(childColumn)
                );
            }

            if (dynamicColumn.type === 'link') {
                return {
                    ...baseProperty,
                    type: dynamicColumn.type,
                    linkGetter: (data) => {
                        const path = LINK_TYPE_MAP[dynamicColumn.linkType]?.path;
                        const id = data.cellsMap?.[dynamicColumn.key]?.id;

                        if (path && id) return `${path}/${id}`;
                        if (!id && path) return path;
                        return '/';
                    },
                };
            }

            if (dynamicColumn.type === 'chip') {
                return {
                    ...baseProperty,
                    type: dynamicColumn.type,
                    chipColorGetter: (data) => {
                        const value = data.cellsMap[dynamicColumn.key]?.value;

                        return chipMap[String(value)]?.color || CHIP_COLORS.NEUTRAL;
                    },
                    valueGetter: (data) => {
                        const value = data.cellsMap[dynamicColumn.key]?.value;

                        return chipMap[String(value)]?.text;
                    },
                };
            }

            return baseProperty;
        },
        [chipMap, name, columnProps]
    );

    const parsedColumns: TableColumn<RowDataMap>[] = useMemo(
        () => data?.data?.headers.map((column) => getParsedColumn(column)) || [],
        [data, getParsedColumn]
    );

    useEffect(() => {
        if (parsedColumns.length && tableSettings?.columns) {
            const filteredSettings = tableSettings.columns.filter((setting) =>
                parsedColumns.some((column) => column.key === setting.key)
            );

            const newColumns = parsedColumns.filter((column) => {
                const isExistInSettings = tableSettings.columns.some(
                    (columnSetting) => columnSetting.key === column.key
                );

                return !isExistInSettings;
            });

            const nextColumnsSettings = [...filteredSettings, ...getMinifiedColumns(newColumns)];

            setTableSettings((prevSettings) => ({
                ...(prevSettings || {}),
                columns: nextColumnsSettings,
            }));
        }
    }, [parsedColumns]);

    const { settings, onColumnsSettingsChange, onColumnsSettingsReset, onColumnResize } =
        useSettings({ name, columns: parsedColumns });

    const displayedColumns = useMemo(
        () => (parsedColumns.length ? getDisplayedColumns(parsedColumns, settings.columns) : []),
        [parsedColumns, settings.columns]
    );

    const extendedColumns = useMemo(
        () => (parsedColumns.length ? getExtendedColumns(parsedColumns, settings.columns) : []),
        [parsedColumns, settings.columns]
    );

    const isColumnsChanged = useMemo(
        () => hasColumnSettingsChanges(parsedColumns, extendedColumns),
        [parsedColumns, extendedColumns]
    );

    const { total, totalPages } = data || {};

    const isEmpty = !isFetching && !isError && parsedData?.length === 0;

    const handleRefresh = useCallback(() => {
        refetch();
    }, []);

    const handleResetAll = useEvent(() => {
        onColumnsSettingsReset?.();
        handleSetParams(fullDefaultParams);
    });

    useEffect(() => {
        if (data?.totalPages <= page) {
            onPageChange(0);
        }
    }, [data?.totalPages, page]);

    return (
        <TableError onResetAll={handleResetAll}>
            <Table
                {...rest}
                data={parsedData}
                columns={displayedColumns}
                extendedColumns={extendedColumns}
                page={page}
                size={size}
                sort={sort}
                itemsPerPage={itemsPerPage}
                totalElements={total}
                totalPages={totalPages}
                isLoading={isLoadingProp || isFetching}
                isEmpty={isEmpty}
                isError={isError}
                onPageChange={onPageChange}
                onSizeChange={onSizeChange}
                onSortChange={onSortChange}
                onColumnsSettingsChange={onColumnsSettingsChange}
                onColumnsSettingsReset={onColumnsSettingsReset}
                onColumnResize={onColumnResize}
                onRefresh={handleRefresh}
                isColumnsChanged={isColumnsChanged}
                allowColumnSettings={allowColumnSettings}
            />
        </TableError>
    );
};

export default typedMemo(DynamicQueryTable);
