import React, { useCallback, useMemo, useState } from 'react';

import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';

import { useEvent } from './hooks';

type UseConfirmActionConfig = {
    confirmContent: React.ReactNode;
    confirmTitle?: string;
    confirmButtonText?: string;
    cancelButtonText?: string;
    modalKey?: string;
    onSubmit: () => void;
    onCancel?: () => void;
};

export const useConfirmAction = (config: UseConfirmActionConfig) => {
    const {
        confirmContent,
        confirmTitle = 'Подтвердите действие',
        confirmButtonText = 'Подтвердить',
        cancelButtonText = 'Отменить',
        modalKey,
        onSubmit,
        onCancel,
    } = config;

    const [opened, setOpened] = useState(false);

    const handleSubmit = useEvent(() => {
        setOpened(false);
        onSubmit();
    });

    const handleClose = useEvent(() => {
        setOpened(false);
        onCancel?.();
    });

    const openModal = useCallback(() => {
        setOpened(true);
    }, []);

    const closeModal = useCallback(() => {
        setOpened(true);
    }, []);

    const modal = useMemo(() => {
        return (
            <Dialog
                open={opened}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                key={modalKey}
            >
                <DialogTitle id="alert-dialog-title">{confirmTitle}</DialogTitle>
                <DialogContent>{confirmContent}</DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} variant="outlined" color="secondary">
                        {cancelButtonText}
                    </Button>
                    <Button onClick={handleSubmit} variant="contained" autoFocus>
                        {confirmButtonText}
                    </Button>
                </DialogActions>
            </Dialog>
        );
    }, [opened, confirmContent, confirmTitle, cancelButtonText, confirmButtonText, modalKey]);

    return { modal, openModal, closeModal } as const;
};
