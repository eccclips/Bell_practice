export const truncateString = (string, width) =>
    string.length > width ? string.slice(0, width).trim() + '...' : string;

export const getFixedNumber = (input: string | number, fractionDigits = 2) => {
    if (!input) return '';

    const number = typeof input === 'string' ? parseFloat(input) : input;

    if (isNaN(number)) return '';

    return number.toFixed(fractionDigits);
};
