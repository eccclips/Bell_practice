import React, { useCallback } from 'react';

import { Control, UseFormSetValue } from 'react-hook-form';

import { Fields, SelectOption } from '../../../../../fields';

type SelectFieldProps<T> = {
    control: Control<T>;
    name: any;
    options: SelectOption[];
    multiple: boolean;
    label: string;
    placeholder?: string;
    isEqualValues?: (a: any, b: any) => boolean;
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
    setValue: UseFormSetValue<Record<string, any>>;
};

const SelectField = <T,>(props: SelectFieldProps<T>) => {
    const {
        control,
        name,
        options,
        multiple,
        label,
        placeholder,
        isEqualValues,
        onChange,
        setValue,
    } = props;

    const handleChange = useCallback(
        (_, __, value: any) => {
            onChange?.(value, setValue);
        },
        [onChange, setValue]
    );

    const id = `filter__${name}`;

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <Fields.Select
                labelId={id}
                control={control}
                name={name}
                placeholder={typeof placeholder === 'string' ? placeholder : 'Выберите значение'}
                options={options}
                multiple={multiple}
                isEqualValues={isEqualValues}
                size="small"
                clearable
                onChange={handleChange}
            />
        </>
    );
};

export default React.memo(SelectField);
