import React from 'react';

import { SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';
import { useDocumentHistoryState } from 'root-front/store';
import { getFormattedDateWithTime } from 'root-front/utils';

import { Bookmark } from '../bookmarks';
import { LinkIconButton } from '../link-button';

import styles from './Title.module.scss';

type Props = {
    title: string;
    goBackLink?: string;
    withGoBack?: boolean;
    withHistory?: boolean;
    withBookmark?: boolean;
};

const DocumentTitle = (props: Props) => {
    const {
        title,
        goBackLink = '..',
        withGoBack = true,
        withHistory = true,
        withBookmark = true,
    } = props;

    const historyRecord = useDocumentHistoryState();

    const isHistory = withHistory && !!historyRecord;

    const titleContent = isHistory
        ? `История «${title}» №${historyRecord.id}${
              historyRecord.date ? ` от ${getFormattedDateWithTime(historyRecord.date)}` : ''
          }`
        : title;

    const showBookmark = withBookmark && (!withHistory || !historyRecord);

    return (
        <h1>
            {withGoBack && (
                <LinkIconButton to={isHistory ? '.' : goBackLink} className={styles.button}>
                    <SvgIcon>
                        <Icons.ArrowLeft />
                    </SvgIcon>
                </LinkIconButton>
            )}
            {showBookmark && <Bookmark name={title} className={styles.button} />}
            {titleContent}
        </h1>
    );
};

export default React.memo(DocumentTitle);
