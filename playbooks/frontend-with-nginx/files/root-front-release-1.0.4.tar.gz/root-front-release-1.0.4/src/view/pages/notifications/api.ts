import {
    InfiniteData,
    useInfiniteQuery,
    useMutation,
    UseMutationOptions,
    useQuery,
    useQueryClient,
} from '@tanstack/react-query';
import { AxiosResponse } from 'axios';

import { api } from 'root-front/api';
import { SORT_DIRECTION } from 'root-front/constants';
import { BASE_STATUS, MS_NOTIFICATION_URL, NotificationDTO } from 'root-front/dictionaries';
import { ResponseDTO } from 'root-front/interfaces';

import { FILTER_TABS, getIsReadFilterValue, MARK_NOTIFICATION_ACTION, TABS } from './constants';

export const useNotifications = ({
    tab,
    search,
    filterTab,
}: {
    tab: TABS;
    search: string;
    filterTab: FILTER_TABS;
}) => {
    return useInfiniteQuery({
        queryKey: ['@root/notifications/page', tab, filterTab, search],
        queryFn: async ({ pageParam }) => {
            const result = await api.post<
                ResponseDTO<NotificationDTO[]>,
                AxiosResponse<ResponseDTO<NotificationDTO[]>>
            >(`${MS_NOTIFICATION_URL}/notification/page`, {
                pageInfo: {
                    page: pageParam || 0,
                    size: 20,
                    sort: [
                        {
                            field: 'id',
                            direction: SORT_DIRECTION.DESC,
                        },
                    ],
                },
                isRead: getIsReadFilterValue(filterTab),
                messageTopic: search || null,
                status: tab === TABS.ARCHIVE ? [BASE_STATUS.CLOSED] : [BASE_STATUS.ACTIVE],
            });

            return result.data;
        },
        staleTime: 60 * 1000,
        refetchInterval: 20000,
        refetchOnWindowFocus: true,
        getNextPageParam: (lastPage) =>
            lastPage.page + 1 < lastPage.totalPages ? lastPage.page + 1 : undefined,
    });
};

export const useNotificationsById = (id: number, enabled = true, refetchOnMount = true) => {
    return useQuery({
        queryKey: ['@root/notifications/id', id],
        queryFn: async () => {
            const result = await api.get<
                ResponseDTO<NotificationDTO>,
                AxiosResponse<ResponseDTO<NotificationDTO>>,
                { id: number }
            >(`${MS_NOTIFICATION_URL}/notification/${id}`);

            return result.data;
        },
        enabled,
        refetchOnMount,
    });
};

export const useMarkNotifications = (
    config: UseMutationOptions<
        ResponseDTO<NotificationDTO[]>,
        any,
        {
            ids: number[];
            action: MARK_NOTIFICATION_ACTION;
            tab: TABS;
            filterTab: FILTER_TABS;
            search: string;
        }
    > = {}
) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationKey: ['@root/notifications/mark'],
        mutationFn: async (data) => {
            const res = await api.post<
                ResponseDTO<NotificationDTO[]>,
                AxiosResponse<ResponseDTO<NotificationDTO[]>>
            >(`${MS_NOTIFICATION_URL}/notification/mark-all`, {
                notifications: data.ids,
                isRead: data.action === MARK_NOTIFICATION_ACTION.READ,
            });

            return res.data;
        },
        ...config,
        onMutate: async (variables) => {
            const notificationsQueryKey = [
                '@root/notifications/page',
                variables.tab,
                variables.filterTab,
                variables.search,
            ];

            await queryClient.cancelQueries({ queryKey: notificationsQueryKey });

            const previousNotifications = queryClient.getQueryData(
                notificationsQueryKey
            ) as InfiniteData<ResponseDTO<NotificationDTO[]>>;

            queryClient.setQueryData<InfiniteData<ResponseDTO<NotificationDTO[]>>>(
                notificationsQueryKey,
                (oldData) => {
                    const newData = oldData?.pages.map((page) => ({
                        ...page,
                        data: page.data.map((item) => {
                            if (variables.ids.some((id) => item.id === id)) {
                                return {
                                    ...item,
                                    isRead: variables.action === MARK_NOTIFICATION_ACTION.READ,
                                };
                            } else {
                                return item;
                            }
                        }),
                    }));
                    return {
                        ...oldData,
                        pages: newData,
                    };
                }
            );

            return { previousNotifications } as const;
        },
        onError: (...args) => {
            queryClient.setQueryData(
                ['@root/notifications/page', args[1].tab, args[1].filterTab, args[1].search],
                (args[2] as any).previousNotifications
            );
            config.onError?.(...args);
        },
        onSettled: (...args) => {
            config.onSettled?.(...args);
            queryClient.invalidateQueries(['@root/notifications/page']);
            queryClient.invalidateQueries(['@root/unread-notifications-count']);
        },
    });
};

export const useChangeNotificationStatus = (
    config: UseMutationOptions<
        ResponseDTO<NotificationDTO[]>,
        any,
        { ids: number[]; status: BASE_STATUS }
    > = {}
) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationKey: ['@root/notifications/delete'],
        mutationFn: async (data) => {
            const res = await api.post<
                ResponseDTO<NotificationDTO[]>,
                AxiosResponse<ResponseDTO<NotificationDTO[]>>
            >(`${MS_NOTIFICATION_URL}/notification/mark-all`, {
                notifications: data.ids,
                status: data.status,
            });

            return res.data;
        },
        ...config,
        onSettled: (...args) => {
            config.onSettled?.(...args);
            queryClient.invalidateQueries(['@root/notifications/page']);
            queryClient.invalidateQueries(['@root/unread-notifications-count']);
        },
    });
};

export const useDeleteNotifications = (
    config: UseMutationOptions<
        ResponseDTO<NotificationDTO[]>,
        any,
        { ids: number[]; action: MARK_NOTIFICATION_ACTION; tab: TABS }
    > = {}
) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationKey: ['@root/notifications/delete'],
        mutationFn: async (data) => {
            const res = await api.put<
                ResponseDTO<NotificationDTO[]>,
                AxiosResponse<ResponseDTO<NotificationDTO[]>>
            >(`${MS_NOTIFICATION_URL}/notification/delete`, data.ids);

            return res.data;
        },
        ...config,
        onSettled: (...args) => {
            config.onSettled?.(...args);
            queryClient.invalidateQueries(['@root/notifications/page']);
            queryClient.invalidateQueries(['@root/unread-notifications-count']);
        },
    });
};
