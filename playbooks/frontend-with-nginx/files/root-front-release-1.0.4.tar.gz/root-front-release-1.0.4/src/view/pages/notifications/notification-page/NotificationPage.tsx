import React, { useCallback, useEffect, useMemo } from 'react';

import { Drawer } from '@mui/material';
import { useIsMutating } from '@tanstack/react-query';
import { useSearchParams } from 'react-router-dom';

import { EmptyPage } from 'root-front/components';
import { NotificationDTO } from 'root-front/dictionaries';
import { LAYOUT, useLayoutState } from 'root-front/store';

import { useNotificationsById } from '../api';
import { Content } from './content';

import styles from './NotificationPage.module.scss';

type Props = {
    notificationId: number;
    opened: boolean;
    handleReadCurrentNotification: () => void;
};

const NotificationPage = (props: Props) => {
    const { notificationId, opened, handleReadCurrentNotification } = props;

    const layoutState = useLayoutState();
    const isMobile = layoutState === LAYOUT.MOBILE;

    const [_, setSearchParams] = useSearchParams();

    const { data, isLoading, isPreviousData, isFetching, isError } = useNotificationsById(
        notificationId,
        opened
    );

    const notification = useMemo(() => data?.data || ({} as NotificationDTO), [data]);

    const isMarkingNotification = !!useIsMutating({ mutationKey: ['@root/notifications/mark'] });

    const handleCloseNotification = useCallback(() => {
        setSearchParams((prevSearchParams) => {
            const nextSearchParams = new URLSearchParams(prevSearchParams);
            nextSearchParams.delete('notificationId');

            return nextSearchParams;
        });
    }, []);

    useEffect(() => {
        if (data?.data && !data.data.isRead && !isMarkingNotification) {
            handleReadCurrentNotification();
        }
    }, [data]);

    return (
        <>
            {isMobile && (
                <Drawer
                    anchor="right"
                    open={opened}
                    className={styles.drawer}
                    PaperProps={{ className: styles.drawer__paper }}
                    variant="persistent"
                >
                    <Content
                        notification={notification}
                        handleCloseNotification={handleCloseNotification}
                        isMobile={isMobile}
                        isLoading={isLoading || (isFetching && isPreviousData)}
                        isError={isError}
                    />
                </Drawer>
            )}
            {!isMobile && opened ? (
                <Content
                    notification={notification}
                    handleCloseNotification={handleCloseNotification}
                    isMobile={isMobile}
                    isLoading={isLoading || (isFetching && isPreviousData)}
                    isError={isError}
                />
            ) : null}

            {!isMobile && !opened && <EmptyPage text="Выберите уведомление для просмотра" />}
        </>
    );
};

export default React.memo(NotificationPage);
