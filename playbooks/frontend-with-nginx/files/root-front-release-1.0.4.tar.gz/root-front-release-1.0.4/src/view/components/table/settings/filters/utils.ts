import dayjs from 'dayjs';

import { TableFilter } from '../../types';

export const getDefaultValues = (filters: TableFilter[]) => {
    return filters.reduce((acc, next) => {
        switch (next.type) {
            case 'date':
                acc[next.name] = null as dayjs.Dayjs;
                return acc;
            case 'date-range':
                acc[next.name] = { from: null as dayjs.Dayjs, to: null as dayjs.Dayjs };
                return acc;
            case 'select':
                acc[next.name] = next.multiple ? [] : '';
                return acc;
            case 'query-select':
                acc[next.name] = next.multiple ? [] : null;
                return acc;
            case 'query-select-with-modal':
                acc[next.name] = next.multiple ? [] : null;
                return acc;
            case 'number-range':
                acc[next.name] = { from: null, to: null };
                return acc;
            default:
                acc[next.name] = '';
                return acc;
        }
    }, {});
};
