import React, { useEffect, useState } from 'react';

import { IconButton, SvgIcon } from '@mui/material';
import classNames from 'classnames';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { TableData, TableGroupModel } from '../../types';
import { TableCell } from '../cell';
import { GROUP_ROW_DATA_SYMBOL, REST_ROWS_SYMBOL } from '../constants';
import { TableRow, TableRowProps } from '../row';
import { GroupedRows } from '../types';

import stylesCell from '../cell/TableCell.module.scss';
import stylesRow from '../row/TableRow.module.scss';
import styles from './GroupedRow.module.scss';

type GroupedRowProps<Data> = {
    groupModel: TableGroupModel<Data>;
    groupedRows: GroupedRows<Data> | TableData<Data>[];
    selectedRows: TableData<Data>[];
    depth: number;
} & Omit<TableRowProps<Data>, 'row' | 'rowIndex' | 'selected'>;

const GroupedRow = <Data,>(props: GroupedRowProps<Data>) => {
    const { groupModel, groupedRows, selectedRows, depth, ...rest } = props;

    const [expanded, setExpanded] = useState<(string | typeof REST_ROWS_SYMBOL)[]>(() => {
        if (
            typeof groupModel.defaultExpanded?.[depth] === 'function'
                ? (groupModel.defaultExpanded?.[depth] as any)?.(groupedRows)
                : !!groupModel.defaultExpanded?.[depth]
        ) {
            return Object.keys(groupedRows);
        }
        return [];
    });

    const handleSwitchExpanded = (key: string | typeof REST_ROWS_SYMBOL) => {
        setExpanded((prevExpanded) => {
            if (prevExpanded.includes(key)) {
                return prevExpanded.filter((value) => value !== key);
            }
            return [...prevExpanded, key];
        });
    };

    useEffect(() => {
        setExpanded((prevExpanded) => {
            if (
                typeof groupModel.defaultExpanded?.[depth] === 'function'
                    ? (groupModel.defaultExpanded?.[depth] as any)?.(groupedRows)
                    : !!groupModel.defaultExpanded?.[depth]
            ) {
                return Object.keys(groupedRows);
            }
            return prevExpanded?.length ? [] : prevExpanded;
        });
    }, [groupedRows]);

    // Если группа — массив, то выходим из рекурсии, отрисовывая эти строки
    if (Array.isArray(groupedRows) && groupedRows.length) {
        return groupedRows.map((row, rowIndex) => (
            <TableRow
                key={row[props.dataKey]}
                rowIndex={rowIndex}
                row={row}
                groupModel={groupModel}
                groupedDepth={depth}
                selected={
                    !!selectedRows?.find(
                        (selectedRow) => selectedRow[props.dataKey] === row[props.dataKey]
                    )
                }
                {...rest}
                grouped
            />
        ));
    }
    // Если нет, значит это объект. Тогда уходим рекурсией вглубь по полям этого объекта
    const result = [];

    const renderRows = (
        [key, rows]: [string | typeof REST_ROWS_SYMBOL, GroupedRows<Data> | TableData<Data>[]],
        index: number
    ) => {
        const isExpanded = expanded.includes(key);

        result.push(
            <tr key={`GROUP_${key.toString()}`} className={stylesRow.row}>
                <td>
                    <div className={stylesCell.cell} style={{ paddingLeft: 10 + depth * 10 }}>
                        <IconButton
                            size="small"
                            onClick={() => handleSwitchExpanded(key)}
                            className={styles.button}
                        >
                            <SvgIcon
                                fontSize="small"
                                className={classNames(
                                    styles.button__icon,
                                    isExpanded && styles.button__icon_expanded
                                )}
                            >
                                <Icons.ArrowRight />
                            </SvgIcon>
                        </IconButton>
                        {key === REST_ROWS_SYMBOL ? 'Другое' : (key as string)}
                    </div>
                </td>
                {!rows[GROUP_ROW_DATA_SYMBOL] ? (
                    <td colSpan={100}></td>
                ) : (
                    rest.columns.map((column, colIndex) => (
                        <TableCell
                            key={`GROUP_${key.toString()}_${column.key}`}
                            row={rows[GROUP_ROW_DATA_SYMBOL]}
                            column={column}
                            rowIndex={index}
                            colIndex={colIndex + 1}
                        />
                    ))
                )}
            </tr>
        );

        if (isExpanded) {
            result.push(
                <GroupedRow
                    key={`GROUP_${key.toString()}_${index}`}
                    groupModel={groupModel}
                    groupedRows={rows as GroupedRows<Data>}
                    selectedRows={selectedRows}
                    depth={depth + 1}
                    {...rest}
                />
            );
        }
    };

    const groupedRowsArray = Object.entries(groupedRows) as [
        string,
        GroupedRows<Data> | TableData<Data>[],
    ][];

    const groupedRowsArraySorted = groupModel.sortGroupKeys?.[depth]
        ? groupedRowsArray.sort((a, b) => groupModel.sortGroupKeys[depth](a[0], b[0]))
        : groupedRowsArray;

    // Сначала рендерим группы
    groupedRowsArraySorted.forEach(renderRows);

    // Затем остальное
    if (groupedRows[REST_ROWS_SYMBOL]) {
        renderRows(
            [REST_ROWS_SYMBOL, groupedRows[REST_ROWS_SYMBOL] as GroupedRows<Data>],
            groupedRowsArraySorted.length
        );
    }
    return result;
};

export default typedMemo(GroupedRow);
