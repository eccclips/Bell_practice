import React, { useState } from 'react';

import {
    Button,
    Checkbox,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Stack,
    SvgIcon,
} from '@mui/material';
import { Link } from 'react-router-dom';

import { Icons } from 'root-front/icons';
import { LAYOUT, useBookmarksState, useLayoutState } from 'root-front/store';

import emptyListUrl from '../../../../assets/icons/empty-list.svg?url';

import styles from './Bookmarks.module.scss';

type Props = {
    open: boolean;
    onClose: () => void;
};

const Bookmarks = ({ open, onClose }: Props) => {
    const layout = useLayoutState();
    const [bookmarks, setBookmarks] = useBookmarksState();

    const [unchecked, setUnchecked] = useState<string[]>([]);

    const handleClose = () => {
        onClose?.();
    };

    const handleTransitionExited = () => {
        if (unchecked.length) {
            setBookmarks((prevBookmarks) =>
                prevBookmarks.filter(({ url }) => !unchecked.includes(url))
            );
            setUnchecked([]);
        }
    };

    const handleCheck = (url: string, checked: boolean) => {
        setUnchecked((prevUnchecked) => {
            if (checked) {
                return prevUnchecked.filter((uncheckedUrl) => uncheckedUrl !== url);
            }
            return [...prevUnchecked, url];
        });
    };

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            fullScreen={layout === LAYOUT.MOBILE}
            maxWidth="xs"
            fullWidth
            TransitionProps={{ onExited: handleTransitionExited }}
        >
            <DialogTitle>Закладки</DialogTitle>
            <DialogContent className={styles.bookmarks__content}>
                {bookmarks.length ? (
                    <Stack component="ul" gap="4px">
                        {bookmarks.map((bookmark) => (
                            <li key={bookmark.url} className={styles.bookmarks__element}>
                                <Checkbox
                                    icon={
                                        <SvgIcon>
                                            <Icons.Bookmark />
                                        </SvgIcon>
                                    }
                                    checkedIcon={
                                        <SvgIcon>
                                            <Icons.BookmarkFilled />
                                        </SvgIcon>
                                    }
                                    checked={!unchecked.includes(bookmark.url)}
                                    onChange={(_, checked) => handleCheck(bookmark.url, checked)}
                                    size="small"
                                    className={styles.bookmarks__checkbox}
                                />
                                <Link
                                    to={bookmark.url}
                                    className={styles.bookmarks__link}
                                    onClick={handleClose}
                                >
                                    {bookmark.name}
                                </Link>
                            </li>
                        ))}
                    </Stack>
                ) : (
                    <div className={styles.bookmarks__empty}>
                        <img src={emptyListUrl} />
                        <span>Здесь пока ничего нет.</span>
                        <span>
                            Вы можете добавить страницу в закладки, нажав на соответствующую иконку
                            в заголовке.
                        </span>
                    </div>
                )}
            </DialogContent>
            <DialogActions>
                <Button variant="outlined" onClick={handleClose} color="secondary">
                    Закрыть
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default React.memo(Bookmarks);
