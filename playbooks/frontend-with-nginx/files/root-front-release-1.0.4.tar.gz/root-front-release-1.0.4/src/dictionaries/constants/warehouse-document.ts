import { CHIP_COLORS } from 'root-front/components';

export enum ZNO_REQUEST_TASK_STATUS {
    DRAFT = 'DRAFT',
    AWAIT_PROCESSING = 'AWAIT_PROCESSING',
    ITEMS_SELECTION = 'ITEMS_SELECTION',
    ITEMS_SELECTION_COMPLETED = 'ITEMS_SELECTION_COMPLETED',
    IN_PROCESS = 'IN_PROCESS',
    COMPLETED = 'COMPLETED',
    DELETED = 'DELETED',
}

export const ZNO_REQUEST_TASK_STATUS_MAP = {
    [ZNO_REQUEST_TASK_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
    [ZNO_REQUEST_TASK_STATUS.AWAIT_PROCESSING]: {
        text: 'Ожидает обработки',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ZNO_REQUEST_TASK_STATUS.ITEMS_SELECTION]: {
        text: 'Подбор позиций',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ZNO_REQUEST_TASK_STATUS.ITEMS_SELECTION_COMPLETED]: {
        text: 'Выполнен подбор',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ZNO_REQUEST_TASK_STATUS.IN_PROCESS]: {
        text: 'Формирование заявок',
        color: CHIP_COLORS.DISABLED,
    },
    [ZNO_REQUEST_TASK_STATUS.COMPLETED]: {
        text: 'Исполнен',
        color: CHIP_COLORS.SUCCESS,
    },
    [ZNO_REQUEST_TASK_STATUS.DELETED]: {
        text: 'Удален',
        color: CHIP_COLORS.ERROR,
    },
};

export enum REPORT_EXECUTE_ORDER_VIEW {
    ORDER = 'ORDER',
    SUPPLY_DETAIL = 'SUPPLY_DETAIL',
    MOVING = 'MOVING',
    ZNO_SHIPMENT = 'ZNO_SHIPMENT',
    SALE_ZNO_SHIPMENT = 'SALE_ZNO_SHIPMENT',
}

export const REPORT_EXECUTE_ORDER_VIEW_MAP = {
    [REPORT_EXECUTE_ORDER_VIEW.ORDER]: {
        text: 'Заказ (позиции – партии НГО)',
    },
    [REPORT_EXECUTE_ORDER_VIEW.SUPPLY_DETAIL]: {
        text: 'Обеспечение потребности',
    },
    [REPORT_EXECUTE_ORDER_VIEW.MOVING]: {
        text: 'Перемещения',
    },
    [REPORT_EXECUTE_ORDER_VIEW.ZNO_SHIPMENT]: {
        text: 'ЗнО на отгрузку',
    },
    [REPORT_EXECUTE_ORDER_VIEW.SALE_ZNO_SHIPMENT]: {
        text: 'РТиУ',
    },
};
