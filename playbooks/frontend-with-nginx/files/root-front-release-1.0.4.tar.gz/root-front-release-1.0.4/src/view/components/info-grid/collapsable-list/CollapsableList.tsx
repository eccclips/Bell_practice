import React, { useMemo, useReducer } from 'react';

import { Collapse, IconButton, SvgIcon } from '@mui/material';
import cn from 'classnames';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { ListItem } from '../../list-item';
import { ListItemConfig } from '../types';

import styles from './CollapsableList.module.scss';

type CollapsableListProps<DataType> = {
    title: string;
    data: DataType;
    itemsConfig: Array<ListItemConfig<DataType>>;
};

const CollapsableList = <DataType,>(props: CollapsableListProps<DataType>) => {
    const { data, title, itemsConfig } = props;

    const [isOpen, toggleOpen] = useReducer((isOpen) => !isOpen, true);

    const renderList = useMemo(() => {
        return itemsConfig.map((itemConfig) => {
            let value = data[itemConfig.key];
            const chipColor = itemConfig.type === 'chip' && itemConfig.chipColorGetter(data);
            const linkValue = itemConfig.type === 'link' ? itemConfig.linkGetter(data) : null;

            if (itemConfig.valueGetter) {
                value = itemConfig.valueGetter(data);
            }

            return (
                <ListItem
                    key={itemConfig.key}
                    label={itemConfig.label}
                    value={value}
                    type={itemConfig.type}
                    chipColor={chipColor}
                    link={linkValue}
                    className={styles.list__item}
                />
            );
        });
    }, [data, itemsConfig]);

    return (
        <div className={styles.list}>
            <div className={styles.list__header}>
                <h3>{title}</h3>
                <IconButton onClick={toggleOpen} size="small">
                    <SvgIcon
                        className={cn(styles.list__header__icon, {
                            [styles.list__header__icon_collapsed]: isOpen,
                        })}
                    >
                        <Icons.ArrowRight />
                    </SvgIcon>
                </IconButton>
            </div>
            <Collapse in={isOpen}>{renderList}</Collapse>
        </div>
    );
};

export default typedMemo(CollapsableList);
