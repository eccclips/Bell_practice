import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const SupplyChainMFE = React.lazy(() =>
    loadModule(process.env.MFE_SUPPLY_CHAIN_HOST, './SupplyChain')
);

export function SupplyChainRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <SupplyChainMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
