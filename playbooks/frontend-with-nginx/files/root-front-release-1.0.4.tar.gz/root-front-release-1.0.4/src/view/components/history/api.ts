import { useQuery } from '@tanstack/react-query';
import { AxiosResponse } from 'axios';

import { api } from 'root-front/api';
import { DocumentHistoryDTO, ListRequestDTO, ResponseDTO } from 'root-front/interfaces';
import { ListRequestParams } from 'root-front/types';
import { getPaginationFromRequestParams } from 'root-front/utils';

export const useDocumentHistoryList = (params: ListRequestParams<any, { url: string }>) => {
    return useQuery({
        queryKey: ['@root/history/list', params],
        queryFn: async () => {
            const result = await api.post<
                ResponseDTO<DocumentHistoryDTO[]>,
                AxiosResponse<ResponseDTO<DocumentHistoryDTO[]>>,
                ListRequestDTO
            >(params.params?.url, {
                ...getPaginationFromRequestParams(params),
                ...(params.filters || {}),
            });

            return result.data;
        },
    });
};
