import React, { useRef, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { IconButton, InputAdornment } from '@mui/material';
import { getCurrentBrowserFingerPrint } from '@rajesh896/broprint.js';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { useSetRecoilState } from 'recoil';

import { Fields, LoadingButton } from 'root-front/components';
import { Icons } from 'root-front/icons';
import {
    accessTokenState,
    authInfoState,
    PERMISSIONS,
    refreshTokenState,
    userPermissionsState,
} from 'root-front/store';

import LogoIcon from 'src/assets/logo.svg';

import { useLoginMutation } from './api';
import { DEFAULT_VALUES, FormData, VALIDATION_SCHEMA } from './constants';

import styles from './Auth.module.scss';

const Auth = () => {
    const setAccessToken = useSetRecoilState(accessTokenState);
    const setRefreshToken = useSetRecoilState(refreshTokenState);
    const setAuthInfo = useSetRecoilState(authInfoState);
    const setUserPermissions = useSetRecoilState(userPermissionsState);

    const navigate = useNavigate();
    const workplaceFingerprintRef = useRef<string>('');

    const [error, setError] = useState('');

    const { control, handleSubmit, formState } = useForm({
        defaultValues: DEFAULT_VALUES,
        mode: 'onChange',
        resolver: yupResolver(VALIDATION_SCHEMA) as any,
        shouldFocusError: true,
    });

    const [showPassword, setShowPassword] = React.useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
    };

    const { mutate, isLoading } = useLoginMutation({
        onSuccess: (result) => {
            const { data } = result;
            setAccessToken(data.accessToken);
            setRefreshToken(data.refreshToken);
            setAuthInfo({
                scope: data.scope,
                expiresIn: data.expiresIn,
                refreshExpiresIn: data.refreshExpiresIn,
                tokenType: data.tokenType,
                notBeforePolicy: data.notBeforePolicy,
                userSessionTimeOut: data.userSessionTimeOut,
            });
            setUserPermissions(
                showPassword ? [...data.privileges, PERMISSIONS.SUPER_ADMIN] : data.privileges
            );
            navigate('/');
        },
        onError: (result) => {
            setError(result?.response?.data?.debugMessage || 'Упс! Что-то пошло не так...');
        },
    });

    const onSubmit = async (data: FormData) => {
        setError('');

        if (!workplaceFingerprintRef.current) {
            workplaceFingerprintRef.current = (await getCurrentBrowserFingerPrint()).toString();
        }

        mutate({ ...data, workplaceFingerprint: workplaceFingerprintRef.current });
    };

    return (
        <main className={styles.main}>
            <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
                <div className={styles.form__header}>
                    <h1>
                        <LogoIcon className={styles.form__logo} viewBox="0 0 190 40" />
                    </h1>
                    <h2>Добро пожаловать!</h2>
                </div>
                <Fields.TextField
                    control={control}
                    name="username"
                    label="Логин"
                    type="text"
                    size="medium"
                    autoComplete="username"
                />
                <Fields.TextField
                    control={control}
                    name="password"
                    label="Пароль"
                    type={showPassword ? 'text' : 'password'}
                    size="medium"
                    InputProps={{
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    aria-label="toggle password visibility"
                                    onClick={handleClickShowPassword}
                                    onMouseDown={handleMouseDownPassword}
                                    edge="end"
                                >
                                    {showPassword ? (
                                        <Icons.VisibilityOff />
                                    ) : (
                                        <Icons.VisibilityOn />
                                    )}
                                </IconButton>
                            </InputAdornment>
                        ),
                        className: styles.input,
                    }}
                    autoComplete="current-password"
                />
                <div className={styles.form__closeSessions}>
                    <Fields.Checkbox
                        control={control}
                        name="closeOtherSessions"
                        id="closeOtherSessions"
                        size="small"
                    />
                    <label htmlFor="closeOtherSessions">Завершить другие сессии</label>
                </div>

                <div className={styles.form__actions}>
                    <LoadingButton
                        type="submit"
                        variant="contained"
                        size="medium"
                        isLoading={isLoading}
                        disabled={!formState.isValid}
                    >
                        Войти
                    </LoadingButton>
                    {error && <span className={styles.form__error}>{error}</span>}
                </div>
            </form>
        </main>
    );
};

export default React.memo(Auth);
