import React from 'react';

import { SvgIcon } from '@mui/material';

import { TableColumn } from 'root-front/components';
import { Icons } from 'root-front/icons';
import { ResponseErrorDTO } from 'root-front/interfaces';

import { SelectOption } from '../../fields';
import { FormData, TABLE_MODE } from './types';

import styles from './UploadFromFileModal.module.scss';

export const DEFAULT_FORMATS = ['.xlsx' as const, '.xls' as const];

export const DEFAULT_VALUES: FormData = {
    viewMode: TABLE_MODE.ALL,
    search: '',
};

export const TABLE_MODE_SELECT_OPTIONS: SelectOption<TABLE_MODE>[] = [
    {
        key: TABLE_MODE.ALL,
        value: TABLE_MODE.ALL,
        label: 'Все строки',
    },
    {
        key: TABLE_MODE.ERRORS,
        value: TABLE_MODE.ERRORS,
        label: 'Только ошибки',
    },
];

export const INDEX_COLUMN: TableColumn<{ index: number }> = {
    key: '@@index',
    name: '№ строки',
    maxWidth: 100,
    valueGetter: (data) => data.index + 1,
};

export const ERROR_COLUMN: TableColumn<{ errors: ResponseErrorDTO[] }> = {
    key: '@@error',
    name: 'Статус загрузки',
    minWidth: 200,
    valueGetter: (data) =>
        data.errors?.length ? (
            <span className={styles.table__rowError}>
                {data.errors.map(({ message }) => message).join('; ')}
            </span>
        ) : (
            <SvgIcon>
                <Icons.Check className={styles.table__rowSuccess} />
            </SvgIcon>
        ),
};

export const getColumnsWithError = <Data,>(columns: TableColumn<Data>[]) => [
    INDEX_COLUMN as TableColumn<Data>,
    ...columns,
    ERROR_COLUMN as TableColumn<Data>,
];
