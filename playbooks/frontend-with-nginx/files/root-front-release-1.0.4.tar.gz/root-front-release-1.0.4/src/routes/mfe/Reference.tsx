import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const ReferenceMFE = React.lazy(() => loadModule(process.env.MFE_REFERENCE_HOST, './Reference'));

export function ReferenceRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <ReferenceMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
