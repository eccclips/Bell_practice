import { getDictionaryQuery } from 'root-front/utils';

import { MS_USER_URL } from '../api';
import { UsersDTO } from '../interfaces';

export const useUsersDictionary = getDictionaryQuery<UsersDTO>({
    url: `${MS_USER_URL}/user/page`,
    queryKey: ['@root/user/page'],
});

export const getSelectOptionFromUsers = (data: UsersDTO) => ({
    key: data.id,
    label: data.fio,
    value: data,
});
