import React, { useCallback, useState } from 'react';

import { Button, SvgIcon } from '@mui/material';

import { SavedFilter, TableProps } from 'root-front/components';
import { Icons } from 'root-front/icons';

import { ImportFiltersModal } from './modal';

type ImportFiltersProps = Pick<TableProps<any>, 'savedFilters'> & {
    closeFilterModal?: () => void;
};

const ImportFilters = (props: ImportFiltersProps) => {
    const { savedFilters, closeFilterModal } = props;
    const [opened, setOpened] = useState(false);

    const handleClose = useCallback(() => {
        setOpened(false);
    }, []);

    const handleImportFilters = useCallback((filters: SavedFilter[]) => {
        setOpened(false);

        savedFilters.onImportUserFilters?.(filters);
    }, []);

    const handleApplyFilter = useCallback((savedFilter: SavedFilter) => {
        setOpened(false);

        savedFilters.onApplyFilter?.(savedFilter);
        closeFilterModal?.();
    }, []);

    return (
        <>
            <Button
                variant="outlined"
                color="secondary"
                startIcon={
                    <SvgIcon>
                        <Icons.Group />
                    </SvgIcon>
                }
                onClick={() => setOpened(true)}
                type="button"
            >
                Фильтры пользователей
            </Button>
            <ImportFiltersModal
                opened={opened}
                onClose={handleClose}
                onImport={handleImportFilters}
                onApply={handleApplyFilter}
                savedFilters={savedFilters}
            />
        </>
    );
};

export default React.memo(ImportFilters);
