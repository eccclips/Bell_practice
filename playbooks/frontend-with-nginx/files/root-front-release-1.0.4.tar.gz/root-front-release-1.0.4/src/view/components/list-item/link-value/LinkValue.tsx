import React, { memo, ReactNode } from 'react';

import { Link } from 'react-router-dom';

import styles from './LinkValue.module.scss';

type LinkValueProps = {
    value: ReactNode;
    link?: string;
};

const LinkValue = (props: LinkValueProps) => {
    const { value, link } = props;
    if (!link) {
        return value;
    }
    return (
        <Link to={link} className={styles.link}>
            {value}
        </Link>
    );
};

export default memo(LinkValue);
