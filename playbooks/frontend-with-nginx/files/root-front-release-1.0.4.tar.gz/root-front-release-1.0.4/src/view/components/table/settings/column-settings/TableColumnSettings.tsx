import React, { useCallback, useEffect, useMemo, useState } from 'react';

import { Button, Drawer, IconButton, SvgIcon, Switch } from '@mui/material';
import cn from 'classnames';

import { Icons } from 'root-front/icons';

import { SortableList } from '../../../sortable-list';
import { TableColumn, TableData } from '../../types';

import styles from './TableColumnSettings.module.scss';

type TableColumnSettingsProps<Data = any> = {
    columns: TableColumn<TableData<Data>>[];
    onColumnsSettingsChange?: (columns: TableColumn<TableData<Data>>[]) => void;
    onColumnsSettingsReset?: () => void;
};

const TableColumnSettings = <Data,>(props: TableColumnSettingsProps<Data>) => {
    const { columns, onColumnsSettingsChange, onColumnsSettingsReset } = props;

    const [opened, setOpened] = useState(false);

    const [updatedColumns, setUpdatedColumns] = useState(columns);

    const handleOpen = () => {
        setOpened(true);
    };

    const handleClose = () => {
        setOpened(false);
    };

    const handleSaveSettings = () => {
        onColumnsSettingsChange?.(updatedColumns);
        handleClose();
    };

    const handleResetSettings = () => {
        onColumnsSettingsReset?.();
        handleClose();
    };

    const onColumnsSort = useCallback((newColumns: TableColumn<TableData<Data>>[]) => {
        setUpdatedColumns(newColumns);
    }, []);

    const renderChildItems = (columns: TableColumn<TableData<Data>>[], disabled: boolean) => {
        return columns.map((column) => (
            <div key={column.key} className={cn(styles.item)}>
                <div className={styles.item__content}>
                    <Switch
                        value={column.key}
                        checked={!column.disabled}
                        onChange={onVisibilityChange}
                        className={styles.item__switch}
                        disabled={disabled}
                    />
                    <div className={styles.item__element}>
                        <span className={styles.item__text}>{column.name}</span>
                    </div>
                </div>
                {column.children?.length && (
                    <div className={styles.item__children}>
                        {renderChildItems(column.children, column.disabled || disabled)}
                    </div>
                )}
            </div>
        ));
    };

    const renderItem = useCallback(
        (column: TableColumn<TableData<Data>>, draggable, snapshot) => (
            <div
                {...draggable.draggableProps}
                ref={draggable.innerRef}
                className={cn(styles.item, {
                    [styles.item_dragging]: snapshot.isDragging,
                })}
            >
                <div className={styles.item__content}>
                    <Switch
                        value={column.key}
                        checked={!column.disabled}
                        onChange={onVisibilityChange}
                        className={styles.item__switch}
                        disabled={typeof column.permanent === 'boolean' ? column.permanent : false}
                    />
                    <div className={styles.item__element} {...draggable.dragHandleProps}>
                        <span className={styles.item__text}>{column.name}</span>
                        <div className={styles.item__dragger}>
                            <Icons.Drag />
                        </div>
                    </div>
                </div>
                {column.children?.length && (
                    <div className={styles.item__children}>
                        {renderChildItems(column.children, column.disabled)}
                    </div>
                )}
            </div>
        ),
        []
    );

    const getItemKey = useCallback((item: TableColumn<TableData<Data>>) => {
        return item.key;
    }, []);

    const onVisibilityChange = (e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => {
        const updateColumnsVisibility = (columns: TableColumn[]) => {
            return columns.map((column) => {
                if (column.key === e.target.value) {
                    return { ...column, disabled: !checked };
                }

                if (column.children?.length) {
                    column.children = updateColumnsVisibility(column.children);
                    return column;
                }

                return column;
            });
        };
        setUpdatedColumns((prevColumns) => updateColumnsVisibility(prevColumns));
    };

    const hasDisplayedColumns = useMemo(
        () => updatedColumns.some(({ disabled }) => !disabled),
        [updatedColumns]
    );

    const isSaveDisabled = updatedColumns === columns || !hasDisplayedColumns;

    useEffect(() => {
        setUpdatedColumns(columns);
    }, [opened]);

    return (
        <>
            <Button
                startIcon={
                    <SvgIcon>
                        <Icons.Columns />
                    </SvgIcon>
                }
                variant="outlined"
                color="secondary"
                size="small"
                onClick={handleOpen}
            >
                Столбцы
            </Button>

            <Drawer
                anchor="right"
                open={opened}
                PaperProps={{ className: styles.paper }}
                onClose={handleClose}
            >
                <div className={styles.container}>
                    <div className={styles.container__header}>
                        <h3>Настройка столбцов</h3>
                        <IconButton onClick={handleClose}>
                            <SvgIcon>
                                <Icons.Close />
                            </SvgIcon>
                        </IconButton>
                    </div>

                    <div className={styles.container__content}>
                        <SortableList
                            list={updatedColumns}
                            onChange={onColumnsSort}
                            getItemKey={getItemKey}
                            renderItem={renderItem}
                            listClassName={styles.container__list}
                        />
                    </div>

                    <div className={styles.container__footer}>
                        <Button
                            variant="outlined"
                            color="secondary"
                            startIcon={
                                <SvgIcon>
                                    <Icons.Close />
                                </SvgIcon>
                            }
                            onClick={handleResetSettings}
                        >
                            Сбросить
                        </Button>
                        <Button
                            variant="contained"
                            onClick={handleSaveSettings}
                            disabled={isSaveDisabled}
                        >
                            Применить
                        </Button>
                    </div>
                </div>
            </Drawer>
        </>
    );
};

export default React.memo(TableColumnSettings);
