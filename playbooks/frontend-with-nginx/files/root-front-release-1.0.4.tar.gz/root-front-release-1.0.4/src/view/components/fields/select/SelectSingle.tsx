import React, { useMemo } from 'react';

import {
    Checkbox,
    FormControl,
    FormHelperText,
    InputLabel,
    MenuItem,
    SelectChangeEvent,
    Select as SelectCore,
    SvgIcon,
} from '@mui/material';
import { useController } from 'react-hook-form';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';
import { SelectSingleProps } from './types';
import { defaultIsEqualValues } from './utils';

import styles from '../Fields.module.scss';

const SelectSingle = <T, Value>(props: SelectSingleProps<T, Value>) => {
    const {
        options,
        control,
        isEqualValues = defaultIsEqualValues,
        placeholder,
        clearable,
        id,
        labelId,
        className,
        withStaticHelperText,
        readOnly,
        disabled,
        ...rest
    } = props;

    const { field, fieldState } = useController({
        name: props.name,
        control: control,
        rules: props.rules,
        shouldUnregister: props.shouldUnregister,
    });

    const selected = useMemo(() => {
        return (
            options.find((option) => isEqualValues(option.value, field.value as Value))?.key || ''
        );
    }, [options, field.value]);

    const handleChange = (e: SelectChangeEvent<string | number>, child: React.ReactNode) => {
        const { value } = e.target;

        if (value === '') {
            field.onChange('');
            props.onChange?.(e, child, '' as Value);
            return;
        }

        const nextValue = options.find((option) => option.key.toString() === value?.toString?.())
            ?.value;

        if (isEqualValues(nextValue, field.value as Value)) {
            return;
        }

        field.onChange(nextValue);
        props.onChange?.(e, child, nextValue);
    };

    const renderValue = () =>
        options.find((option) => isEqualValues(option.value, field.value as Value))?.label ||
        field.value.toString();

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        field.onBlur();
        props.onBlur?.(e);
    };

    return (
        <FormControl
            size={props.size}
            error={!!fieldState.error}
            fullWidth={rest.fullWidth}
            className={className}
        >
            {props.label && <InputLabel id={id || labelId}>{props.label}</InputLabel>}
            <SelectCore
                {...rest}
                size={rest.size || 'small'}
                value={selected}
                onChange={handleChange}
                onBlur={handleBlur}
                inputRef={field.ref}
                inputProps={{ id: labelId || id }}
                labelId={labelId || id}
                renderValue={renderValue}
                IconComponent={(props) =>
                    !readOnly && !disabled ? (
                        <SvgIcon {...props}>
                            <Icons.ArrowDown />
                        </SvgIcon>
                    ) : null
                }
                sx={{
                    '& .MuiSelect-select .notranslate::after': placeholder
                        ? {
                              content: `"${placeholder}"`,
                              opacity: 0.42,
                          }
                        : {},
                }}
                placeholder={placeholder}
                autoComplete="off"
                disabled={disabled}
                readOnly={readOnly}
                multiple={false}
                native={false}
                MenuProps={{
                    sx: {
                        '& .MuiMenu-paper': {
                            maxWidth: 'min-content',
                        },
                    },
                }}
            >
                {clearable && (
                    <MenuItem key="@@CLEAR" value="">
                        Очистить
                    </MenuItem>
                )}

                {options.map((option) => (
                    <MenuItem key={option.key} value={option.key}>
                        {rest.multiple && (
                            <Checkbox
                                checked={selected === option.key}
                                size={rest.size || 'small'}
                            />
                        )}
                        {option.label}
                    </MenuItem>
                ))}
            </SelectCore>
            {fieldState.error ? (
                <FormHelperText className={withStaticHelperText && styles.helperText_static}>
                    <FormErrorHelper message={fieldState.error.message} />
                </FormHelperText>
            ) : null}
        </FormControl>
    );
};

export default typedMemo(SelectSingle);
