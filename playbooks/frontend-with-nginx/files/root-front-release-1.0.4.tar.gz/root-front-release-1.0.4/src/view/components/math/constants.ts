import * as Yup from 'yup';

import { randomUUID } from 'root-front/utils';

import { SelectOption } from '../fields';
import { Formula } from './types';

export enum ELEMENT_TYPE {
    OPERATOR = 'OPERATOR',
    ARGUMENT = 'ARGUMENT',
}

export enum OPERATOR_TYPE {
    PLUS = 'PLUS',
    MINUS = 'MINUS',
    MULTIPLY = 'MULTIPLY',
    DIVIDE = 'DIVIDE',
    POW = 'POW',
    SQRT = 'SQRT',
    MAX = 'MAX',
    MIN = 'MIN',
    DIV = 'DIV',
    MOD = 'MOD',
    FLOOR = 'FLOOR',
    CEIL = 'CEIL',
    ABS = 'ABS',
}

export enum ARGUMENT_TYPE {
    CONSTANT = 'CONSTANT',
    PARAMETER = 'PARAMETER',
    FORMULA = 'FORMULA',
    CUSTOMIZED_PARAMETER = 'CUSTOMIZED_PARAMETER',
    RESOURCE_FORMULA_B2B = 'RESOURCE_FORMULA_B2B',
    RESOURCE_FORMULA_OPT = 'RESOURCE_FORMULA_OPT',
}

export type ADDITIONAL_ARGUMENT_TYPE =
    | ARGUMENT_TYPE.RESOURCE_FORMULA_B2B
    | ARGUMENT_TYPE.RESOURCE_FORMULA_OPT;

export const ELEMENT_TYPE_OPTIONS: SelectOption<ELEMENT_TYPE>[] = [
    {
        key: ELEMENT_TYPE.OPERATOR,
        value: ELEMENT_TYPE.OPERATOR,
        label: 'Оператор',
    },
    {
        key: ELEMENT_TYPE.ARGUMENT,
        value: ELEMENT_TYPE.ARGUMENT,
        label: 'Аргумент',
    },
];

export const OPERATOR_OPTIONS: SelectOption<OPERATOR_TYPE>[] = [
    {
        key: OPERATOR_TYPE.PLUS,
        value: OPERATOR_TYPE.PLUS,
        label: 'Сумма (+)',
    },
    {
        key: OPERATOR_TYPE.MINUS,
        value: OPERATOR_TYPE.MINUS,
        label: 'Разность (–)',
    },
    {
        key: OPERATOR_TYPE.MULTIPLY,
        value: OPERATOR_TYPE.MULTIPLY,
        label: 'Произведение (⋅)',
    },
    {
        key: OPERATOR_TYPE.DIVIDE,
        value: OPERATOR_TYPE.DIVIDE,
        label: 'Частное (/)',
    },
    {
        key: OPERATOR_TYPE.POW,
        value: OPERATOR_TYPE.POW,
        label: 'Возведение в степень (^)',
    },
    {
        key: OPERATOR_TYPE.SQRT,
        value: OPERATOR_TYPE.SQRT,
        label: 'Квадратный корень (√)',
    },
    {
        key: OPERATOR_TYPE.MAX,
        value: OPERATOR_TYPE.MAX,
        label: 'Макс. значение (MAX)',
    },
    {
        key: OPERATOR_TYPE.MIN,
        value: OPERATOR_TYPE.MIN,
        label: 'Мин. значение (MIN)',
    },
    {
        key: OPERATOR_TYPE.DIV,
        value: OPERATOR_TYPE.DIV,
        label: 'Целочисленное деление (//)',
    },
    {
        key: OPERATOR_TYPE.MOD,
        value: OPERATOR_TYPE.MOD,
        label: 'Остаток от деления (%)',
    },
    {
        key: OPERATOR_TYPE.FLOOR,
        value: OPERATOR_TYPE.FLOOR,
        label: 'Округление вниз (⌊...⌋)',
    },
    {
        key: OPERATOR_TYPE.CEIL,
        value: OPERATOR_TYPE.CEIL,
        label: 'Округление вверх (⌈...⌉)',
    },
    {
        key: OPERATOR_TYPE.ABS,
        value: OPERATOR_TYPE.ABS,
        label: 'Модуль (|...|)',
    },
];

export const ARGUMENT_TYPE_OPTIONS: SelectOption<ARGUMENT_TYPE>[] = [
    {
        key: ARGUMENT_TYPE.CONSTANT,
        value: ARGUMENT_TYPE.CONSTANT,
        label: 'Константа',
    },
    {
        key: ARGUMENT_TYPE.PARAMETER,
        value: ARGUMENT_TYPE.PARAMETER,
        label: 'Параметр',
    },
    {
        key: ARGUMENT_TYPE.FORMULA,
        value: ARGUMENT_TYPE.FORMULA,
        label: 'Пользовательская формула',
    },
    {
        key: ARGUMENT_TYPE.CUSTOMIZED_PARAMETER,
        value: ARGUMENT_TYPE.CUSTOMIZED_PARAMETER,
        label: 'Настраиваемая переменная',
    },
];

export const ADDITIONAL_ARGUMENT_TYPE_OPTIONS: SelectOption<ADDITIONAL_ARGUMENT_TYPE>[] = [
    {
        key: ARGUMENT_TYPE.RESOURCE_FORMULA_OPT,
        value: ARGUMENT_TYPE.RESOURCE_FORMULA_OPT,
        label: 'Формула расчета ресурса ОО',
    },
    {
        key: ARGUMENT_TYPE.RESOURCE_FORMULA_B2B,
        value: ARGUMENT_TYPE.RESOURCE_FORMULA_B2B,
        label: 'Формула расчета ресурса B2B',
    },
];

export const OPERANDS_LENGTH_FROM_OPERATOR_MAP = {
    [OPERATOR_TYPE.PLUS]: {
        min: 2,
        max: Infinity,
    },
    [OPERATOR_TYPE.MINUS]: {
        min: 2,
        max: Infinity,
    },
    [OPERATOR_TYPE.MULTIPLY]: {
        min: 2,
        max: Infinity,
    },
    [OPERATOR_TYPE.DIVIDE]: {
        min: 2,
        max: 2,
    },
    [OPERATOR_TYPE.POW]: {
        min: 2,
        max: 2,
    },
    [OPERATOR_TYPE.SQRT]: {
        min: 1,
        max: 1,
    },
    [OPERATOR_TYPE.MAX]: {
        min: 2,
        max: Infinity,
    },
    [OPERATOR_TYPE.MIN]: {
        min: 2,
        max: Infinity,
    },
    [OPERATOR_TYPE.DIV]: {
        min: 2,
        max: 2,
    },
    [OPERATOR_TYPE.MOD]: {
        min: 2,
        max: 2,
    },
    [OPERATOR_TYPE.FLOOR]: {
        min: 1,
        max: 1,
    },
    [OPERATOR_TYPE.CEIL]: {
        min: 1,
        max: 1,
    },
    [OPERATOR_TYPE.ABS]: {
        min: 1,
        max: 1,
    },
};

export const formulaValidationSchema = Yup.object({
    type: Yup.string().nullable().oneOf(Object.keys(ELEMENT_TYPE)).required(),
    operator: Yup.string()
        .nullable()
        .when('type', {
            is: ELEMENT_TYPE.OPERATOR,
            then: (schema) => schema.required('Обязательно'),
        }),
    argumentType: Yup.string()
        .nullable()
        .oneOf(Object.keys(ARGUMENT_TYPE))
        .when('type', {
            is: ELEMENT_TYPE.ARGUMENT,
            then: (schema) => schema.required('Обязательно'),
        }),
    constant: Yup.number()
        .nullable()
        .when('argumentType', {
            is: ARGUMENT_TYPE.CONSTANT,
            then: (schema) => schema.required('Обязательно'),
        }),
    parameter: Yup.object()
        .nullable()
        .when('argumentType', {
            is: (argumentType) => {
                return (
                    argumentType === ARGUMENT_TYPE.FORMULA ||
                    argumentType === ARGUMENT_TYPE.PARAMETER ||
                    argumentType === ARGUMENT_TYPE.CUSTOMIZED_PARAMETER
                );
            },
            then: (schema) => {
                return schema.required('Обязательно');
            },
        }),

    operands: Yup.array()
        .nullable()
        .of(Yup.lazy(() => formulaValidationSchema.default(undefined))),
});

export const DEFAULT_VALUES: Formula = {
    uid: randomUUID(),
    type: ELEMENT_TYPE.OPERATOR,
    operands: [],
};
