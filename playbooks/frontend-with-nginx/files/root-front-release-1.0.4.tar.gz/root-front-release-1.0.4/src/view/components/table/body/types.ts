import { TableData } from '../types';
import { GROUP_ROW_DATA_SYMBOL, REST_ROWS_SYMBOL } from './constants';

export type GroupedRows<Data> = {
    [REST_ROWS_SYMBOL]: GroupedRows<Data> | TableData<Data>[];
    [GROUP_ROW_DATA_SYMBOL]: TableData<Data> | null;
    [key: string]: GroupedRows<Data> | TableData<Data>[];
};
