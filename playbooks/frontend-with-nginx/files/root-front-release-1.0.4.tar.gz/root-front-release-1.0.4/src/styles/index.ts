import styles from './styles.module.scss';

type DefaultStyles = {
    content: string;
    content_noFlex: string;
    header: string;
    header_onlyActions: string;
    header__actions: string;
    header__button: string;
    header__button_noFlex: string;
    table: string;
    contentForm: string;
    contentForm__inner: string;
    contentForm__list: string;
    contentForm__listHeader: string;
    contentForm__row: string;
    contentForm__row_boolean: string;
    contentForm__field: string;
    contentForm__info: string;
    modalForm: string;
    modalForm_column: string;
    modalForm__row: string;
    modalForm__row_boolean: string;
    modalForm__field: string;
    dialogTitle: string;
};

export const defaultStyles: DefaultStyles = styles;
