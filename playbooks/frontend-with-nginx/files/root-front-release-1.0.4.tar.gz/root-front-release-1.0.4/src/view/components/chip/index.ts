export { default as Chip, CHIP_COLORS } from './Chip';
