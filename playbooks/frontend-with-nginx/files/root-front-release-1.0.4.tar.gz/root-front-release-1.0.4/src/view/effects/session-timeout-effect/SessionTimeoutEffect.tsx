import { useEffect, useMemo, useRef } from 'react';

import { useAuthInfoState } from 'root-front/store';

import { logout } from '../../../utils/auth';

export const SessionTimeoutEffect = () => {
    const timeoutRef = useRef<NodeJS.Timeout>();

    const authInfoState = useAuthInfoState();

    const sessionTimeoutMs = useMemo(
        () => (authInfoState?.userSessionTimeOut ? authInfoState.userSessionTimeOut * 1000 : 0),
        [authInfoState]
    );

    useEffect(() => {
        if (!sessionTimeoutMs) return;

        const handleWindowEvent = () => {
            clearTimeout(timeoutRef.current);

            timeoutRef.current = setTimeout(() => {
                logout();
            }, sessionTimeoutMs);
        };

        handleWindowEvent();

        window.addEventListener('mousemove', handleWindowEvent);
        window.addEventListener('keydown', handleWindowEvent);
        window.addEventListener('touchstart', handleWindowEvent);
        window.addEventListener('scroll', handleWindowEvent);

        return () => {
            window.removeEventListener('mousemove', handleWindowEvent);
            window.removeEventListener('keydown', handleWindowEvent);
            window.removeEventListener('touchstart', handleWindowEvent);
            window.removeEventListener('scroll', handleWindowEvent);
        };
    }, [sessionTimeoutMs]);

    return null;
};
