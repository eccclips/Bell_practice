import { PathMatch } from 'react-router-dom';

export type Breadcrumb = {
    path: string;
    breadcrumb: string | ((match: PathMatch, searchParams: URLSearchParams) => string);
    withHistory?: boolean;
};

export type BreadcrumbsProps = {
    breadcrumbs: Breadcrumb[];
};
