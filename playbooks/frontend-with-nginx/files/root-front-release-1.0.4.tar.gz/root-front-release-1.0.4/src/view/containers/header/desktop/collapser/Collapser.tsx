import React, { useCallback } from 'react';

import { ButtonBase } from '@mui/material';
import cn from 'classnames';

import { Icons } from 'root-front/icons';

import { useIsMenuExpanded } from 'src/store/settings';

import styles from './Collapser.module.scss';

export const Collapser = React.memo(() => {
    const [isExpanded, setIsExpanded] = useIsMenuExpanded();

    const handleClick = useCallback(() => {
        setIsExpanded((val) => !val);
    }, []);

    return (
        <ButtonBase className={styles.collapser} onClick={handleClick} focusRipple>
            <Icons.ArrowLeft
                className={cn(styles.collapser__icon, {
                    [styles.collapser__icon_collapsed]: !isExpanded,
                })}
            />
            Скрыть меню
        </ButtonBase>
    );
});
