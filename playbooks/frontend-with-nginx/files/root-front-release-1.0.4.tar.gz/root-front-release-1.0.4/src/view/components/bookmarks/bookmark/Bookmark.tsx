import React, { useMemo } from 'react';

import { Checkbox, SvgIcon } from '@mui/material';
import { useLocation } from 'react-router-dom';

import { Icons } from 'root-front/icons';
import { useBookmarksState } from 'root-front/store';

type BookmarkProps = {
    name: string;
    className?: string;
};

const Bookmark = (props: BookmarkProps) => {
    const { name, className } = props;

    const location = useLocation();

    const [bookmarks, setBookmarks] = useBookmarksState();

    const checked = useMemo(
        () => bookmarks.some((bookmark) => bookmark.url === location.pathname),
        [bookmarks, location.pathname]
    );

    const handleChange = (e: any, checked: boolean) => {
        setBookmarks((prevBookmarks) => {
            if (checked) {
                return [{ name, url: location.pathname }, ...prevBookmarks];
            }

            return prevBookmarks.filter((bookmark) => bookmark.url !== location.pathname);
        });
    };

    return (
        <Checkbox
            aria-label="Добавить в закладки"
            checked={checked}
            icon={
                <SvgIcon>
                    <Icons.Bookmark />
                </SvgIcon>
            }
            checkedIcon={
                <SvgIcon>
                    <Icons.BookmarkFilled />
                </SvgIcon>
            }
            onChange={handleChange}
            className={className}
        />
    );
};

export default React.memo(Bookmark);
