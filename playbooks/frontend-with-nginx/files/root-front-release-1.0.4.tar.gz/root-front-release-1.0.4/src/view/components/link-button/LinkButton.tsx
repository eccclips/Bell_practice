import React from 'react';

import { Button, ButtonProps } from '@mui/material';
import { NavLink } from 'react-router-dom';

const LinkButton = (props: ButtonProps<React.ElementType, { to?: string }>) => {
    return <Button {...props} LinkComponent={NavLink} />;
};

export default React.memo(LinkButton);
