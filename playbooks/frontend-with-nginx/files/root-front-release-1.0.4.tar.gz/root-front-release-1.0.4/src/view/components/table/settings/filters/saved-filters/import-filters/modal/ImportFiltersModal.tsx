import React, { useMemo, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import {
    Button,
    ButtonBase,
    Checkbox,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControlLabel,
} from '@mui/material';
import cn from 'classnames';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';

import { UsersDTO } from 'root-front/dictionaries';
import { useEvent } from 'root-front/utils';

import {
    getSelectOptionFromUsers,
    useUsersDictionary,
} from '../../../../../../../../dictionaries/utils';
import { Fields } from '../../../../../../fields';
import { LoaderOverlay } from '../../../../../../loader-overlay';
import { SavedFilter, TableProps } from '../../../../../types';

import styles from './ImportFiltersModal.module.scss';

type ImportFiltersModalProps = Pick<TableProps<any>, 'savedFilters'> & {
    opened: boolean;
    onClose: () => void;
    onImport: (savedFilters: SavedFilter[]) => void;
    onApply: (savedFilter: SavedFilter) => void;
};

const DEFAULT_VALUES = { user: null as UsersDTO };

const VALIDATION_SCHEMA = Yup.object({
    user: Yup.object().nullable().required('Обязательно'),
});

const ImportFiltersModal = (props: ImportFiltersModalProps) => {
    const { opened, onClose, onImport, savedFilters, onApply } = props;

    const [selectedFilters, setSelectedFilters] = useState<SavedFilter[]>([]);

    const { control, handleSubmit, reset, watch } = useForm({
        defaultValues: DEFAULT_VALUES,
        resolver: yupResolver(VALIDATION_SCHEMA) as any,
        shouldFocusError: true,
        reValidateMode: 'onChange',
    });

    const user = watch('user');

    const { data: userFiltersData, isFetching } = savedFilters.useUserSavedFilters(user);

    const [isAllSelected, indeterminate] = useMemo(
        () => [
            !!selectedFilters.length,
            userFiltersData
                ? selectedFilters.length && userFiltersData.length !== selectedFilters.length
                : false,
        ],
        [selectedFilters, userFiltersData]
    );

    const handleChangeUser = useEvent((value: UsersDTO) => {
        if (value && user && value.id === user.id) {
            return;
        }
        setSelectedFilters([]);
    });

    const handleSelectAll = (_, checked: boolean) => {
        if (checked) {
            setSelectedFilters([...userFiltersData]);
        } else {
            setSelectedFilters([]);
        }
    };

    const submitHandler = () => {
        onImport(selectedFilters);
    };

    return (
        <Dialog
            open={opened}
            onClose={onClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="sm"
            fullWidth
            TransitionProps={{
                onExited: () => {
                    reset({ ...DEFAULT_VALUES });
                },
            }}
        >
            <DialogTitle>Фильтры пользователей</DialogTitle>
            <DialogContent>
                <Fields.QuerySelect
                    control={control}
                    name="user"
                    placeholder="Выберите пользователя для просмотра его фильтров"
                    query={useUsersDictionary}
                    getOptionFromData={getSelectOptionFromUsers}
                    onChange={handleChangeUser}
                />
                {user && (
                    <div className={cn(styles.container, isFetching && styles.container_prefilled)}>
                        <FormControlLabel
                            control={
                                <Checkbox checked={isAllSelected} indeterminate={indeterminate} />
                            }
                            label="Выбрать все"
                            className={styles.selectAll}
                            onChange={handleSelectAll}
                        />

                        {userFiltersData?.map((filter) => (
                            <ButtonBase
                                key={filter.uid}
                                className={styles.button}
                                onClick={() => {
                                    onApply(filter);
                                }}
                            >
                                <Checkbox
                                    value={filter}
                                    onChange={(e) => {
                                        if (e.target.checked) {
                                            setSelectedFilters((prev) => [...prev, filter]);
                                        } else {
                                            setSelectedFilters((prev) =>
                                                prev.filter((value) => value.uid !== filter.uid)
                                            );
                                        }
                                    }}
                                    onClick={(e) => {
                                        e.stopPropagation();
                                    }}
                                    checked={
                                        !!selectedFilters.find(
                                            (selectedFilter) => selectedFilter.uid === filter.uid
                                        )
                                    }
                                />
                                <div className={styles.button__text}>{filter.name}</div>
                            </ButtonBase>
                        ))}
                        {isFetching && <LoaderOverlay />}
                    </div>
                )}
            </DialogContent>
            <DialogActions>
                <Button variant="outlined" color="secondary" onClick={onClose}>
                    Отменить
                </Button>
                <Button
                    variant="contained"
                    type="button"
                    onClick={handleSubmit(submitHandler)}
                    disabled={!selectedFilters.length}
                >
                    Импортировать
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default React.memo(ImportFiltersModal);
