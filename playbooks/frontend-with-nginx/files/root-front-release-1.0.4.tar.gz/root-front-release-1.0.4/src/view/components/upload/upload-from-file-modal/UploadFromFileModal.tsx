import React, { useCallback, useMemo, useState } from 'react';

import { Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import cn from 'classnames';
import { useForm } from 'react-hook-form';

import { ResponseErrorDTO } from 'root-front/interfaces';
import { LAYOUT, useLayoutState } from 'root-front/store';
import { typedMemo, useAction, useEvent } from 'root-front/utils';

import { Dropzone } from '..';
import { Fields } from '../../fields';
import { LoadingButton } from '../../loading-button';
import { PageableTable } from '../../table';
import {
    DEFAULT_FORMATS,
    DEFAULT_VALUES,
    getColumnsWithError,
    TABLE_MODE_SELECT_OPTIONS,
} from './constants';
import { TABLE_MODE, UploadFromFileModalProps } from './types';

import styles from './UploadFromFileModal.module.scss';

const UploadFromFileModal = <Data, Error, MutationParams, SaveParams>(
    props: UploadFromFileModalProps<Data, Error, MutationParams, SaveParams>
) => {
    const {
        opened,
        title = 'Загрузка из Excel',
        successMessage = 'Данные из Excel были успешно загружены',
        useUploadFileMutation,
        useSaveDataMutation,
        uploadParams,
        saveParams,
        columns,
        getSearchFilter,
        onClose,
        onSuccess,
    } = props;

    const layout = useLayoutState();

    const [data, setData] = useState<Data[]>(null);
    const [errors, setErrors] = useState<ResponseErrorDTO[]>([]);
    const [file, setFile] = useState<File>(null);

    const { control, watch } = useForm({ defaultValues: DEFAULT_VALUES });

    const formData = watch();

    const parsedData = useMemo(
        () =>
            formData.viewMode === TABLE_MODE.ALL
                ? data?.map((row, index) => ({
                      ...row,
                      id: index,
                      index,
                      errors: errors?.filter((error) => error.code === index.toString()) || [],
                  })) || []
                : errors?.map((value) => ({
                      ...data[+value.code],
                      id: +value.code,
                      index: +value.code,
                      errors: [value],
                  })) || [],
        [data, errors, formData.viewMode]
    );

    const filteredData = useMemo(() => {
        if (!formData.search) {
            return parsedData;
        }

        return parsedData.filter(getSearchFilter(formData.search));
    }, [parsedData, formData.search]);

    const columnsWithError = useMemo(() => getColumnsWithError(columns), [columns]);

    const { submit: uploadFile, isLoading: isUploadingFile } = useAction({
        useMutation: useUploadFileMutation,
        onSuccess: (data) => {
            setData(data.data);
            setErrors(data.errors || []);
            return false;
        },
    });

    const { submit: saveData, isLoading: isSavingData } = useAction({
        useMutation: useSaveDataMutation,
        onSuccess: (...args) => {
            onSuccess?.(...args);
        },
        successMessage,
    });

    const handleDropAccepted = useEvent((files: File[]) => {
        uploadFile(({ mutate }) => {
            mutate({ file: files[0], params: uploadParams });
        });
        setFile(files[0]);
    });

    const handleDeleteFile = () => {
        setFile(null);
        setErrors([]);
        setData(null);
    };

    const handleSaveData = () => {
        saveData(({ mutate }) => {
            mutate({ data, params: saveParams });
        });
    };

    const getRowError = useCallback((row: Data) => !!(row as any)?.errors?.length, []);

    const isMobile = layout === LAYOUT.MOBILE;

    return (
        <Dialog
            open={opened}
            onClose={onClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={!data ? 'sm' : 'lg'}
            fullWidth
            PaperProps={{ className: cn(data && !isMobile && styles.modal_data) }}
            TransitionProps={{ onExited: handleDeleteFile }}
            fullScreen={data && isMobile}
        >
            <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
            <DialogContent className={styles.content}>
                {!data ? (
                    <Dropzone
                        name="upload"
                        formats={DEFAULT_FORMATS}
                        onDropAccepted={handleDropAccepted}
                        isLoading={isUploadingFile}
                    />
                ) : (
                    <div className={styles.table}>
                        <div className={styles.info}>
                            <Chip
                                label={file.name}
                                size="small"
                                color="info"
                                onDelete={handleDeleteFile}
                            />
                            <div className={styles.info__fileInfo}>
                                <div className={styles.info__infoBlock}>
                                    <span>Всего элементов: </span>
                                    <span>{data.length}</span>
                                </div>
                                <div className={styles.info__infoBlock}>
                                    <span>Успешно распознано: </span>
                                    <span>{Math.max(data.length - errors.length, 0)}</span>
                                </div>
                                <div className={styles.info__infoBlock}>
                                    <span>Ошибок: </span>
                                    <span>{errors.length}</span>
                                </div>
                            </div>

                            <div className={styles.info__filters}>
                                <Fields.Select
                                    control={control}
                                    name="viewMode"
                                    options={TABLE_MODE_SELECT_OPTIONS}
                                />
                                <Fields.TextField
                                    control={control}
                                    name="search"
                                    placeholder="Поиск"
                                    debounced
                                />
                            </div>
                        </div>
                        <PageableTable
                            data={filteredData}
                            columns={columnsWithError}
                            getRowError={getRowError}
                        />
                    </div>
                )}
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose} variant="outlined" color="secondary">
                    Отменить
                </Button>
                <LoadingButton
                    onClick={handleSaveData}
                    variant="contained"
                    disabled={!data || data.length === errors?.length}
                    isLoading={isSavingData}
                >
                    Загрузить
                </LoadingButton>
            </DialogActions>
        </Dialog>
    );
};

export default typedMemo(UploadFromFileModal);
