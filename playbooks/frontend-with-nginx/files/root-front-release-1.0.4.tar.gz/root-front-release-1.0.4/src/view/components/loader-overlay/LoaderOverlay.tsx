import React from 'react';

import { CircularProgress } from '@mui/material';

import styles from './LoaderOverlay.module.scss';

type LoaderOverlayProps = {
    size?: number;
};

const LoaderOverlay = (props: LoaderOverlayProps) => {
    const { size = 32 } = props;

    return (
        <div className={styles.loader}>
            <div className={styles.loader__inner}>
                <CircularProgress size={size} />
            </div>
        </div>
    );
};

export default React.memo(LoaderOverlay);
