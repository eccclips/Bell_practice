import React from 'react';

import { ButtonBase, ButtonBaseProps } from '@mui/material';
import { NavLink } from 'react-router-dom';

const LinkButtonBase = (props: ButtonBaseProps<React.ElementType, { to?: string }>) => {
    return <ButtonBase {...props} LinkComponent={NavLink} />;
};

export default React.memo(LinkButtonBase);
