import axios from 'axios';

export const api = axios.create({ baseURL: '/', headers: { 'Content-Type': 'application/json' } });

api.interceptors.request.use((config) => {
    if (!config.headers.Authorization) {
        config.headers.Authorization = `Bearer ${JSON.parse(
            localStorage.getItem('@root/accessToken')
        )}`;
    }

    return config;
});
