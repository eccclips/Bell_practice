import React from 'react';

import { Skeleton } from '@mui/material';

import styles from './NotificationItem.module.scss';

const NotificationListSkeleton = () => {
    return (
        <>
            {Array.from({ length: 10 }).map((_, index) => (
                <div className={styles.skeletonItem} key={index}>
                    <Skeleton width="50%" height="32px"></Skeleton>
                    <Skeleton width="80%" height="32px"></Skeleton>
                </div>
            ))}
        </>
    );
};

export default React.memo(NotificationListSkeleton);
