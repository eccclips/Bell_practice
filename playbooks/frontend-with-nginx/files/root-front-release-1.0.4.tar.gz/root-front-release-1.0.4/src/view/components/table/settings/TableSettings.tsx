import React from 'react';

import { Button, Chip, SvgIcon } from '@mui/material';

import { Icons } from 'root-front/icons';

import { TableProps } from '../types';
import { TableColumnSettings } from './column-settings';
import { TableFilters } from './filters';

import styles from './TableSettings.module.scss';

type TableSettingsProps<Data> = Pick<
    TableProps<Data>,
    | 'extendedColumns'
    | 'filters'
    | 'filterValues'
    | 'isColumnsChanged'
    | 'isFiltersChanged'
    | 'allowColumnSettings'
    | 'allowResetFiltersToDefault'
    | 'onFiltersChange'
    | 'onFiltersReset'
    | 'onColumnsSettingsChange'
    | 'onColumnsSettingsReset'
    | 'onRefresh'
    | 'savedFilters'
> & {
    settingsEndSlot?: JSX.Element;
    settingsStartSlot?: JSX.Element;
};

const TableSettings = <Data,>(props: TableSettingsProps<Data>) => {
    const {
        extendedColumns,
        filters,
        filterValues,
        allowColumnSettings,
        allowResetFiltersToDefault,
        onFiltersChange,
        onFiltersReset,
        onColumnsSettingsChange,
        onColumnsSettingsReset,
        onRefresh,
        isColumnsChanged,
        isFiltersChanged,
        savedFilters,
        settingsEndSlot,
        settingsStartSlot,
    } = props;

    const handleResetFilters = () => {
        onFiltersReset?.(false);
    };

    const handleResetColumnsSettings = () => {
        onColumnsSettingsReset?.();
    };

    if (!filters && !allowColumnSettings && !onRefresh) {
        return null;
    }

    return (
        <div className={styles.settings}>
            <div className={styles.settings__start}>
                {onRefresh ? (
                    <Button
                        startIcon={
                            <SvgIcon>
                                <Icons.Refresh />
                            </SvgIcon>
                        }
                        variant="outlined"
                        color="secondary"
                        size="small"
                        onClick={onRefresh}
                    >
                        Обновить
                    </Button>
                ) : null}
                {allowColumnSettings && (
                    <TableColumnSettings
                        columns={extendedColumns}
                        onColumnsSettingsChange={onColumnsSettingsChange}
                        onColumnsSettingsReset={onColumnsSettingsReset}
                    />
                )}
                {filters && (
                    <TableFilters
                        filters={filters}
                        filterValues={filterValues}
                        onFiltersChange={onFiltersChange}
                        onFiltersReset={onFiltersReset}
                        savedFilters={savedFilters}
                        allowResetFiltersToDefault={allowResetFiltersToDefault}
                    />
                )}
                {settingsStartSlot}

                {isFiltersChanged && (
                    <Chip
                        onDelete={handleResetFilters}
                        label={
                            savedFilters?.appliedFilter
                                ? `Применен фильтр «${savedFilters.appliedFilter.name}»`
                                : 'Применены фильтры'
                        }
                        size="small"
                    />
                )}
                {isColumnsChanged && (
                    <Chip
                        onDelete={handleResetColumnsSettings}
                        label="Применена настройка столбцов"
                        size="small"
                    />
                )}
            </div>
            {settingsEndSlot}
        </div>
    );
};

export default React.memo(TableSettings);
