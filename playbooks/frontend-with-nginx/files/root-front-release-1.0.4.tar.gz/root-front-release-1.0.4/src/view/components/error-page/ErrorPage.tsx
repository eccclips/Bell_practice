import React from 'react';

import cn from 'classnames';

import errorPageImageUrl from '../../../assets/error-page.svg?url';

import styles from './ErrorPage.module.scss';

interface Props {
    text?: string;
    className?: string;
    children?: React.ReactNode;
}

const ErrorPage = (props: Props) => {
    const {
        text = 'О нет! Кажется, что-то сломалось!\nПопробуйте вернуться позднее или повторите запрос.',
        className,
        children,
    } = props;

    return (
        <div className={cn(styles.page, className)}>
            <img src={errorPageImageUrl} alt={text} />
            <span>{text}</span>
            {children}
        </div>
    );
};

export default React.memo(ErrorPage);
