import React from 'react';

import cn from 'classnames';
import { Outlet } from 'react-router-dom';

import { LAYOUT, useLayoutState } from 'root-front/store';

import { Header } from '../../containers';

import styles from './Layout.module.scss';

const Layout = () => {
    const layout = useLayoutState();

    return (
        <div
            className={cn(styles.layout, {
                [styles.layout_mobile]: layout === LAYOUT.MOBILE,
            })}
        >
            <Header />
            <main className={styles.main}>
                <Outlet />
            </main>
        </div>
    );
};

export default React.memo(Layout);
