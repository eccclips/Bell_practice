import React from 'react';

import { createTheme, SvgIcon } from '@mui/material';
import { ruRU } from '@mui/x-date-pickers/locales';

import { Icons } from 'root-front/icons';

export const create = (mode: 'light' | 'dark') => {
    return createTheme(
        {
            typography: {
                fontFamily: `LADAPragmatica, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif`,
                button: {
                    textTransform: 'none',
                },
            },
            palette: {
                mode,
                ...(mode === 'light'
                    ? {
                          primary: {
                              main: '#FA6900',
                              contrastText: '#FFFFFF',
                          },
                          secondary: {
                              main: '#253237',
                              contrastText: '#FFFFFF',
                          },
                          error: {
                              main: '#E00000',
                              contrastText: '#FFFFFF',
                          },
                          text: {
                              primary: '#253237',
                              secondary: '#5B6770',
                              disabled: '#9ebabe',
                          },
                          action: {
                              active: '#5B6770',
                              disabled: '#DEE2E6',
                          },
                          grey: {
                              '500': '#DEE2E6',
                          },
                          info: {
                              main: '#0089FF',
                          },
                          background: {
                              default: '#FFFFFF',
                              paper: '#FFFFFF',
                          },
                      }
                    : {
                          primary: {
                              main: '#FA6900',
                              contrastText: '#FFFFFF',
                          },
                          secondary: {
                              main: '#FFFFFF',
                              contrastText: '#253237',
                          },
                          error: {
                              main: '#E00000',
                              contrastText: '#FFFFFF',
                          },
                          text: {
                              primary: '#FFFFFF',
                              secondary: '#b8c2ca',
                              disabled: '#7e8d8e',
                          },
                          action: {
                              active: '#b8c2ca',
                              disabled: '#7e8d8e',
                          },
                          info: {
                              main: '#0089FF',
                          },
                          background: {
                              default: '#101418',
                              paper: '#101418',
                          },
                      }),
            },
            components: {
                MuiButton: {
                    styleOverrides: {
                        root: {
                            textTransform: 'none',
                            fontSize: '1em',
                            lineHeight: '1.33em',
                            boxShadow: 'none',
                        },
                        contained: ({ theme }) => ({
                            '&.Mui-disabled': {
                                color: theme.palette.text.disabled,
                            },
                        }),
                        outlinedSecondary: ({ theme }) => ({
                            borderColor: theme.palette.action.disabled,
                        }),
                        startIcon: ({ ownerState }) => ({
                            ...(() => {
                                switch (ownerState.size) {
                                    case 'small':
                                        return {
                                            width: '16px',
                                            height: '16px',
                                            '&>*:nth-of-type(1)': { width: '16px', height: '16px' },
                                        };
                                    case 'medium':
                                        return { width: '20px', height: '20px' };
                                    case 'large':
                                        return { width: '24px', height: '24px' };
                                }
                            })(),
                        }),
                        endIcon: ({ ownerState }) => ({
                            ...(() => {
                                switch (ownerState.size) {
                                    case 'small':
                                        return { width: '18px', height: '18px' };
                                    case 'medium':
                                        return { width: '20px', height: '20px' };
                                    case 'large':
                                        return { width: '24px', height: '24px' };
                                }
                            })(),
                        }),
                        sizeMedium: {
                            minHeight: '36px',
                        },
                        sizeSmall: {
                            height: '24px',
                        },
                    },
                },
                MuiToggleButton: {
                    styleOverrides: {
                        root: {
                            fontSize: '1em',
                        },
                    },
                },
                MuiInputBase: {
                    styleOverrides: {
                        root: {
                            fontSize: '1em',
                            lineHeight: '1.33em',
                        },
                    },
                },
                MuiSelect: {
                    defaultProps: {
                        IconComponent: (props) => (
                            <SvgIcon {...props}>
                                <Icons.ArrowDown />
                            </SvgIcon>
                        ),
                    },
                },
                MuiFormHelperText: {
                    styleOverrides: {
                        root: {
                            position: 'absolute',
                            marginTop: '0',
                            marginLeft: '2px',
                            top: '100%',
                        },
                    },
                },
                MuiPaper: {
                    styleOverrides: {
                        root: {
                            backgroundImage: 'none',
                        },
                    },
                },
                MuiChip: {
                    styleOverrides: {
                        deleteIcon: {
                            color: 'inherit',
                        },
                    },
                    defaultProps: {
                        deleteIcon: (
                            <SvgIcon>
                                <Icons.Close />
                            </SvgIcon>
                        ),
                    },
                },
                MuiTab: {
                    styleOverrides: {
                        root: {
                            textTransform: 'none',
                            borderTopLeftRadius: '4px',
                            borderTopRightRadius: '4px',
                            '&.Mui-selected': {
                                backgroundColor: 'var(--primary-hover-transparent)',
                            },
                        },
                    },
                },
                MuiTabs: {
                    styleOverrides: {
                        root: {
                            boxShadow: 'inset 0 -1px 0px var(--system-divider)',
                        },
                        indicator: {
                            borderBottomLeftRadius: '4px',
                            borderBottomRightRadius: '4px',
                        },
                    },
                },
                MuiMenuItem: {
                    styleOverrides: {
                        root: {
                            textWrap: 'wrap',
                        },
                    },
                },
                MuiTableSortLabel: {
                    styleOverrides: {
                        icon: ({ ownerState }) => ({
                            transform: `${
                                ownerState.active ? 'scaleX(1) scaleY(1)' : 'scaleX(0) scaleY(0)'
                            } ${
                                ownerState.direction === 'asc' ? 'rotate(180deg)' : 'rotate(0deg)'
                            }`,
                        }),
                        root: ({ ownerState }) => ({
                            '&:hover .MuiTableSortLabel-icon': {
                                transform: `scaleX(1) scaleY(1) ${
                                    ownerState.direction === 'asc'
                                        ? 'rotate(180deg)'
                                        : 'rotate(0deg)'
                                }`,
                            },
                            '&:focus-visible .MuiTableSortLabel-icon': {
                                transform: `scaleX(1) scaleY(1) ${
                                    ownerState.direction === 'asc'
                                        ? 'rotate(180deg)'
                                        : 'rotate(0deg)'
                                }`,
                            },
                        }),
                    },
                },
            },
        },
        ruRU
    );
};
