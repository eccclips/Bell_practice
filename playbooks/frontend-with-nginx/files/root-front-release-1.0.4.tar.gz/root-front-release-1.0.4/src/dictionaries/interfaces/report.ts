import { BaseAuditedDTO, UserInfoUDB } from 'root-front/interfaces';

import { ORDER_TYPE, RESERVATION_OPERATION_TYPE, WAREHOUSE_DOCUMENT_TYPE } from '../constants';
import { ProductDTO } from './product';

export interface ReservationResultDTO extends BaseAuditedDTO {
    externalId: string;
    orderType: ORDER_TYPE;
    orderId: number;
    orderNumber: string;
    specificationMonth: string;
    productOriginal: ProductDTO;
    orderedQuantity: number;
    wsoPartyId: number;
    partyNum: number;
    product: ProductDTO;
    operationDate: string;
    operationType: RESERVATION_OPERATION_TYPE;
    quantity: number;
    responsible: UserInfoUDB;
    result: string;
    warehouseDocumentId: string;
    warehouseDocumentType: WAREHOUSE_DOCUMENT_TYPE;
    warehouseDocumentNumber: string;
    orderExpirationDate: string;
}
