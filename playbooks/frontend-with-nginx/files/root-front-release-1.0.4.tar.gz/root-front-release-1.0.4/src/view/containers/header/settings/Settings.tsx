import React from 'react';

import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Stack,
    SvgIcon,
    ToggleButton,
    ToggleButtonGroup,
} from '@mui/material';
import { useRecoilState } from 'recoil';

import { LAYOUT, THEME, themeState, useLayoutState } from 'root-front/store';

import ThemeDarkModeIcon from 'src/assets/icons/theme-dark-mode.svg';
import ThemeDefaultModeIcon from 'src/assets/icons/theme-default-mode.svg';
import ThemeLightModeIcon from 'src/assets/icons/theme-light-mode.svg';

import { ResetColumnSettings } from './reset-column-settings';

import styles from './Settings.module.scss';

type Props = {
    open: boolean;
    onClose: () => void;
};

const Settings = ({ open, onClose }: Props) => {
    const [theme, setTheme] = useRecoilState(themeState);

    const layout = useLayoutState();

    const handleChangeTheme = (_, value: THEME) => {
        if (value === null) {
            return;
        }
        setTheme(value);
    };

    const handleClose = () => {
        onClose?.();
    };

    return (
        <Dialog open={open} onClose={handleClose} fullScreen={layout === LAYOUT.MOBILE}>
            <DialogTitle>Настройки</DialogTitle>
            <DialogContent>
                <Stack gap="4px">
                    <div className={styles.settings__list}>
                        <div className={styles.settings__block}>
                            <label>Тема</label>

                            <ToggleButtonGroup
                                color="primary"
                                size="small"
                                value={theme}
                                exclusive
                                onChange={handleChangeTheme}
                            >
                                <ToggleButton
                                    value={THEME.LIGHT}
                                    className={styles.settings__button}
                                >
                                    <SvgIcon className={styles.settings__icon} fontSize="small">
                                        <ThemeLightModeIcon />
                                    </SvgIcon>
                                    Светлая
                                </ToggleButton>
                                <ToggleButton
                                    value={THEME.DEFAULT}
                                    className={styles.settings__button}
                                >
                                    <SvgIcon className={styles.settings__icon} fontSize="small">
                                        <ThemeDefaultModeIcon />
                                    </SvgIcon>
                                    Системная
                                </ToggleButton>
                                <ToggleButton
                                    value={THEME.DARK}
                                    className={styles.settings__button}
                                >
                                    <SvgIcon className={styles.settings__icon} fontSize="small">
                                        <ThemeDarkModeIcon />
                                    </SvgIcon>
                                    Темная
                                </ToggleButton>
                            </ToggleButtonGroup>
                        </div>
                        <div className={styles.settings__block}>
                            <ResetColumnSettings />
                        </div>
                    </div>
                </Stack>
            </DialogContent>
            <DialogActions>
                <Button variant="outlined" onClick={handleClose} color="secondary">
                    Закрыть
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default React.memo(Settings);
