import React, { useEffect, useId, useMemo, useState } from 'react';

import { ButtonProps, IconButton, Menu, MenuItem, SvgIcon } from '@mui/material';
import cn from 'classnames';

import { Icons } from 'root-front/icons';

import { LoadingButton } from '../loading-button';
import { MenuButtonOption } from './types';

import styles from './MenuButton.module.scss';

type MenuButtonProps = {
    menuOptions: MenuButtonOption[];
    menuBeforeContent?: JSX.Element;
    onMenuClose?: (closeMenu: () => void) => void;
    isLoading?: boolean;
    componentType?: 'button' | 'icon-button';
    stopPropagation?: boolean;
} & ButtonProps<React.ElementType>;

const MenuButton = (props: MenuButtonProps) => {
    const {
        menuOptions,
        menuBeforeContent,
        children,
        onMenuClose,
        isLoading,
        componentType = 'button',
        stopPropagation,
        ...buttonProps
    } = props;

    const buttonId = useId();
    const menuId = useId();

    const [anchorElement, setAnchorElement] = useState<null | HTMLElement>(null);

    const handleMenuClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        if (stopPropagation) {
            event.stopPropagation();
        }
        setAnchorElement(event.currentTarget);
    };

    const closeMenu = () => {
        setAnchorElement(null);
    };

    useEffect(() => {
        if (isLoading) {
            closeMenu();
        }
    }, [isLoading]);

    const handleMenuClose = () => {
        if (onMenuClose) {
            return onMenuClose(closeMenu);
        }

        closeMenu();
    };

    const isMenuOpen = !!anchorElement;

    const renderMenuItems = useMemo(() => {
        return menuOptions.map((option) => {
            const handleMenuItemClick = () => {
                if (option.onClick) {
                    return option.onClick(closeMenu);
                }

                closeMenu();
            };

            const renderContent = option.renderItem ? (
                option.renderItem(closeMenu)
            ) : (
                <>
                    {option.icon}
                    <span>{option.text}</span>
                </>
            );

            return (
                <MenuItem
                    key={option.text + menuId}
                    disableRipple
                    onClick={handleMenuItemClick}
                    className={cn(styles.menu__menuItem, {
                        [styles.menu__menuItem_danger]: option.type === 'danger',
                    })}
                >
                    {renderContent}
                </MenuItem>
            );
        });
    }, [menuOptions, stopPropagation]);

    if (!menuOptions.length) {
        return null;
    }

    return (
        <>
            {componentType === 'icon-button' ? (
                <IconButton
                    {...buttonProps}
                    id={buttonId}
                    aria-controls={isMenuOpen ? menuId : undefined}
                    aria-haspopup
                    aria-expanded={isMenuOpen ? 'true' : undefined}
                    onClick={handleMenuClick}
                    disabled={isLoading || buttonProps.disabled}
                >
                    {children}
                </IconButton>
            ) : (
                <LoadingButton
                    variant="outlined"
                    color="secondary"
                    endIcon={
                        <SvgIcon>
                            <Icons.ArrowDown />
                        </SvgIcon>
                    }
                    {...buttonProps}
                    id={buttonId}
                    aria-controls={isMenuOpen ? menuId : undefined}
                    aria-haspopup
                    aria-expanded={isMenuOpen ? 'true' : undefined}
                    onClick={handleMenuClick}
                    isLoading={isLoading}
                >
                    {children}
                </LoadingButton>
            )}

            <Menu
                id={menuId}
                open={isMenuOpen}
                onClose={handleMenuClose}
                MenuListProps={{
                    'aria-labelledby': buttonId,
                }}
                anchorEl={anchorElement}
                className={styles.menu}
                slotProps={{
                    paper: { className: styles.menu },
                    root: {
                        onClick: (e) => {
                            if (stopPropagation) {
                                e.stopPropagation();
                            }
                        },
                    },
                }}
            >
                {menuBeforeContent}
                {renderMenuItems}
            </Menu>
        </>
    );
};

export default React.memo(MenuButton);
