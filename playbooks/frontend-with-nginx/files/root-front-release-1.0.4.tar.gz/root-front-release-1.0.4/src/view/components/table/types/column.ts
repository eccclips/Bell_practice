import { CHIP_COLORS } from 'root-front/components';

export type ActionType<Data = any> = {
    name: string;
    Icon?: React.FC<React.SVGAttributes<SVGElement>>;
    action: (row: Data, cell: { rowIndex: number; colIndex: number }) => void;
    type?: 'danger';
};

type TableChipColumnType<Data> = {
    type: 'chip';
    chipColorGetter: (data: Data) => CHIP_COLORS;
};

type TableLinkColumnType<Data> = {
    type: 'link';
    linkGetter: (data: Data) => string;
};

type TableActionsColumnType<Data> = {
    type: 'menu' | 'icon-buttons';
    actions: ActionType<Data>[] | ((data: Data) => ActionType<Data>[]);
};

type TableDateColumnType = {
    type: 'date';
    ignoreTimezone?: boolean;
};

type TableBaseColumnType = {
    type?: 'text' | 'boolean';
};

type TableAmountColumnType = {
    type: 'amount';
};

type TableColumnType<Data> =
    | TableBaseColumnType
    | TableDateColumnType
    | TableActionsColumnType<Data>
    | TableLinkColumnType<Data>
    | TableChipColumnType<Data>
    | TableAmountColumnType;

export type TableColumn<Data = any> = {
    key: string;
    name: string;
    emptyValue?: string;
    resizeWidth?: number;
    initialWidth?: number;
    minWidth?: number;
    maxWidth?: number;
    noWrap?: boolean;
    align?: 'left' | 'center' | 'right';
    sortable?: boolean;
    resizable?: boolean;
    disabled?: boolean;
    permanent?: boolean;
    valueGetter?: (data: Data, cell: { rowIndex: number; colIndex: number }) => any;
    children?: TableColumn<Data>[];
} & TableColumnType<Data>;

export type TableHeadGrid<Data = any> = {
    rowSpan: number;
    colSpan: number;
    isGroup: boolean;
    column: TableColumn<Data>;
}[][];
