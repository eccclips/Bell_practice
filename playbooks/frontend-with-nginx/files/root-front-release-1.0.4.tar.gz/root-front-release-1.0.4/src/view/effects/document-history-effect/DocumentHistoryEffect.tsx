import React, { useEffect } from 'react';

import dayjs from 'dayjs';
import { useSearchParams } from 'react-router-dom';
import { useRecoilState } from 'recoil';

import { documentHistoryState } from 'root-front/store';

const DocumentHistoryEffect = () => {
    const [searchParams] = useSearchParams();

    const [, setHistoryRecord] = useRecoilState(documentHistoryState);

    const historyRecordString = searchParams.get('history_record');

    useEffect(() => {
        if (!historyRecordString) {
            return setHistoryRecord(null);
        }

        const [id, date] = historyRecordString.split('@');
        if (id && !Number.isNaN(+id)) {
            const isValidDate = dayjs(date).isValid();
            setHistoryRecord({
                id: +id,
                date: isValidDate ? date : null,
            });
        }
    }, [historyRecordString]);

    return null;
};

export default React.memo(DocumentHistoryEffect);
