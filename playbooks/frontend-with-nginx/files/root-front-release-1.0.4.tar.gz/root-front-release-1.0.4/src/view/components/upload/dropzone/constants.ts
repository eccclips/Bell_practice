import { Format } from './types';

export const acceptStyle = {
    borderColor: 'var(--typography-link)',
};

export const rejectStyle = {
    borderColor: 'var(--system-error-danger)',
};

export const disabledStyle = {
    borderColor: 'var(--typography-disabled-darker)',
    backgroundColor: 'var(--typography-disabled)',
    borderStyle: 'solid',
};

export const getStyles = (isDragAccept: boolean, isDragReject: boolean, disabled: boolean) => ({
    ...(isDragAccept ? acceptStyle : {}),
    ...(isDragReject ? rejectStyle : {}),
    ...(disabled ? disabledStyle : {}),
});

export const getAcceptFormats = (formats: Format[]) => ({
    ...(formats.includes('.png') ? { 'image/png': ['.png'] } : {}),
    ...(formats.includes('.jpg') || formats.includes('.jpeg')
        ? { 'image/jpeg': ['.jpeg', '.jpg'] }
        : {}),

    ...(formats.includes('.xls') ? { 'application/vnd.ms-excel': ['.xls'] } : {}),
    ...(formats.includes('.xlsx')
        ? { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] }
        : {}),
});
