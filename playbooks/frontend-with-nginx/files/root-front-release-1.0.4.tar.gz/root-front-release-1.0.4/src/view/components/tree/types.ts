export type TreeNode = {
    key: string | number;
    title: string;
    rightContent?: JSX.Element;
    link?: string;
    selected?: boolean;
    children?: TreeNode[];
};

export type TreeProps = {
    treeData: TreeNode[];
    collapsable?: boolean;
    defaultExpanded?: boolean;
};

export type TreeNodeProps = {
    node: TreeNode;
    collapsable: boolean;
    defaultExpanded: boolean;
    deep: number;
    last: boolean;
};
