import React, { useCallback, useId } from 'react';

import { Control, UseFormSetValue } from 'react-hook-form';

import { Fields, SelectOption } from '../../../../../fields';

type BooleanFieldProps<T> = {
    control: Control<T>;
    name: any;
    label: string;
    placeholder?: string;
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
    setValue: UseFormSetValue<Record<string, any>>;
};

const OPTIONS: SelectOption[] = [
    {
        key: 'true',
        value: true,
        label: 'Да',
    },
    {
        key: 'false',
        value: false,
        label: 'Нет',
    },
];

const BooleanField = <T,>(props: BooleanFieldProps<T>) => {
    const { control, name, label, placeholder, onChange, setValue } = props;

    const handleChange = useCallback(
        (_, __, value: boolean | null) => {
            onChange?.(value, setValue);
        },
        [onChange, setValue]
    );

    const id = useId();

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <Fields.Select
                labelId={id}
                control={control}
                name={name}
                placeholder={typeof placeholder === 'string' ? placeholder : 'Выберите значение'}
                options={OPTIONS}
                size="small"
                clearable
                onChange={handleChange}
            />
        </>
    );
};

export default React.memo(BooleanField);
