import React, { useEffect, useState } from 'react';

import { Checkbox, Collapse, IconButton, SvgIcon } from '@mui/material';
import cn from 'classnames';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { TableColumn, TableData, TableGroupModel } from '../../types';
import { TableCell } from '../cell';

import styles from './TableRow.module.scss';

export type TableRowProps<Data = any> = {
    row: TableData<Data>;
    rowIndex: number;
    columns: TableColumn<TableData<Data>>[];
    dataKey: string;
    checkboxSelection?: boolean;
    expandable?: boolean;
    grouped?: boolean;
    groupedDepth?: number;
    groupModel?: TableGroupModel<Data>;
    renderExpandedContent?: (row: TableData<Data>) => JSX.Element;
    onRowClick?: (row: TableData<Data>) => void;
    onSelectRow?: (row: TableData<Data>) => void;
    getRowSelectionDisabled?: (row: TableData<Data>) => boolean;
    getRowError?: (row: TableData<Data>) => boolean;
    getRowHighlight?: (row: TableData<Data>) => boolean;
    selected: boolean;
};

const TableRow = <Data,>(props: TableRowProps<Data>) => {
    const {
        row,
        rowIndex,
        dataKey,
        columns,
        checkboxSelection,
        expandable,
        grouped,
        groupedDepth,
        groupModel,
        renderExpandedContent,
        onRowClick,
        onSelectRow,
        getRowSelectionDisabled,
        getRowError,
        getRowHighlight,
        selected,
    } = props;

    const [expanded, setExpanded] = useState({ mounted: false, in: false });

    useEffect(() => {
        if (expanded.mounted) {
            setExpanded({ mounted: true, in: true });
        }
    }, [expanded.mounted]);

    return (
        <>
            <tr
                className={cn(styles.row, {
                    [styles.row_clickable]: !!onRowClick,
                    [styles.row_highlighted]: getRowHighlight?.(row),
                    [styles.row_error]: getRowError?.(row),
                })}
                tabIndex={onRowClick ? 0 : -1}
                onClick={() => onRowClick?.(row)}
                onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                        onRowClick?.(row);
                    }
                }}
            >
                {expandable && (
                    <td key={`${row[dataKey]}_@@EXPAND-ROW`}>
                        <div className={styles.row__expander}>
                            <IconButton
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setExpanded({ mounted: true, in: false });
                                }}
                            >
                                <SvgIcon
                                    className={cn(
                                        styles.row__expanderIcon,
                                        expanded.in && styles.row__expanderIcon_expanded
                                    )}
                                >
                                    <Icons.ArrowRight />
                                </SvgIcon>
                            </IconButton>
                        </div>
                    </td>
                )}

                {checkboxSelection && (
                    <td key={`${row[dataKey]}_@@SELECT-ROW`} className={styles.row__checkbox}>
                        <Checkbox
                            checked={selected}
                            onClick={(e) => {
                                e.stopPropagation();
                            }}
                            onKeyDown={(e) => {
                                e.stopPropagation();
                            }}
                            onChange={() => onSelectRow(row)}
                            disabled={getRowSelectionDisabled?.(row)}
                        />
                    </td>
                )}
                {grouped &&
                    (groupModel?.leafColumn ? (
                        <TableCell
                            key={`${row[dataKey]}_${groupModel.leafColumn.key}`}
                            row={row}
                            column={groupModel.leafColumn}
                            rowIndex={rowIndex}
                            colIndex={0}
                            paddingLeft={34 + groupedDepth * 10}
                        />
                    ) : (
                        <td key={`${row[dataKey]}_@@GROUPED`}></td>
                    ))}
                {columns.map((column, colIndex) => (
                    <TableCell
                        key={`${row[dataKey]}_${column.key}`}
                        row={row}
                        column={column}
                        rowIndex={rowIndex}
                        colIndex={!grouped ? colIndex : colIndex + 1}
                    />
                ))}
                <td key="@@RESIZE-FILLER"></td>
            </tr>
            {expandable && expanded.mounted && (
                <tr
                    key={`${row[dataKey]}_expand`}
                    className={cn(styles.row, styles.row_expandable)}
                >
                    <td colSpan={100} className={styles.expandedRow}>
                        <Collapse
                            key="expand"
                            in={expanded.in}
                            onExited={() => setExpanded({ mounted: false, in: false })}
                        >
                            {renderExpandedContent?.(row)}
                        </Collapse>
                    </td>
                </tr>
            )}
        </>
    );
};

export default typedMemo(TableRow);
