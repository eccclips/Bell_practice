import { TableData } from '../types';

export const ERROR_TEXT =
    'О нет! Что-то пошло не так.\nПопробуйте сбросить фильтры, настройки таблицы или сортировку, либо вернуться позднее.';

export const getFilteredData = (
    data: TableData<any>[],
    getRowSelectionDisabled: (row: TableData<any>) => boolean
) => {
    if (!data) {
        return [];
    }
    if (!getRowSelectionDisabled) {
        return data;
    }

    return data.filter((row) => !getRowSelectionDisabled(row));
};
