import dayjs from 'dayjs';
import { atom, useRecoilValue } from 'recoil';

type HistoryRecord = {
    id: number;
    date?: string;
};

export const documentHistoryState = atom<HistoryRecord | null>({
    key: '@root/documentHistoryState',
    default: null,
    effects: [
        ({ setSelf }) => {
            const historyRecordString = new URLSearchParams(location.search).get('history_record');

            if (historyRecordString) {
                const [id, date] = historyRecordString.split('@');
                if (id && !Number.isNaN(+id)) {
                    const isValidDate = dayjs(date).isValid();
                    setSelf({ id: +id, date: isValidDate ? date : null });
                }
            }
        },
    ],
});

export const useDocumentHistoryState = () => {
    return useRecoilValue(documentHistoryState);
};
