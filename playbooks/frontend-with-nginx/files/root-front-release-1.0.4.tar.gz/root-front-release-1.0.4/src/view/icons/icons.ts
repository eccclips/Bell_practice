import Alert from 'src/assets/icons/alert.svg';
import Archive from 'src/assets/icons/archive.svg';
import ArrowDown from 'src/assets/icons/arrow-down.svg';
import ArrowLeft from 'src/assets/icons/arrow-left.svg';
import ArrowRight from 'src/assets/icons/arrow-right.svg';
import ArrowUp from 'src/assets/icons/arrow-up.svg';
import Block from 'src/assets/icons/block.svg';
import BookOpen from 'src/assets/icons/book-open.svg';
import BookmarkFilled from 'src/assets/icons/bookmark-filled.svg';
import Bookmark from 'src/assets/icons/bookmark.svg';
import CalendarThin from 'src/assets/icons/calendar-thin.svg';
import Calendar from 'src/assets/icons/calendar.svg';
import Check from 'src/assets/icons/check.svg';
import Close from 'src/assets/icons/close.svg';
import Columns from 'src/assets/icons/columns.svg';
import Copy from 'src/assets/icons/copy.svg';
import Dictionary from 'src/assets/icons/dictionary.svg';
import Download from 'src/assets/icons/download.svg';
import Drag from 'src/assets/icons/drag.svg';
import Edit from 'src/assets/icons/edit.svg';
import Filter from 'src/assets/icons/filter.svg';
import Filters from 'src/assets/icons/filters.svg';
import Group from 'src/assets/icons/group.svg';
import Inventory2Icon from 'src/assets/icons/inventory-2.svg';
import List from 'src/assets/icons/list.svg';
import Minus from 'src/assets/icons/minus.svg';
import MoreVertical from 'src/assets/icons/more-vertical.svg';
import Notifications from 'src/assets/icons/notifications.svg';
import Pen from 'src/assets/icons/pen.svg';
import Play from 'src/assets/icons/play.svg';
import Plus from 'src/assets/icons/plus.svg';
import ReadMail from 'src/assets/icons/read-mail.svg';
import Refresh from 'src/assets/icons/refresh.svg';
import Restart from 'src/assets/icons/restart.svg';
import Search from 'src/assets/icons/search.svg';
import Settings from 'src/assets/icons/settings.svg';
import Stop from 'src/assets/icons/stop.svg';
import Trash from 'src/assets/icons/Trash.svg';
import Unarchive from 'src/assets/icons/unarchive.svg';
import UnreadMail from 'src/assets/icons/unread-mail.svg';
import Upload from 'src/assets/icons/upload.svg';
import User from 'src/assets/icons/user.svg';
import VisibilityOff from 'src/assets/icons/visibility-off.svg';
import VisibilityOn from 'src/assets/icons/visibility-on.svg';

export const Icons = {
    Alert,
    Archive,
    ArrowDown,
    ArrowLeft,
    ArrowRight,
    ArrowUp,
    BookOpen,
    Bookmark,
    BookmarkFilled,
    Calendar,
    CalendarThin,
    Close,
    Columns,
    Copy,
    Dictionary,
    Download,
    Drag,
    Filter,
    Filters,
    Group,
    Inventory2Icon,
    List,
    ReadMail,
    Refresh,
    Restart,
    Search,
    Settings,
    Stop,
    Unarchive,
    Upload,
    User,
    VisibilityOff,
    VisibilityOn,
    Check,
    Minus,
    MoreVertical,
    Notifications,
    Pen,
    Play,
    Plus,
    Edit,
    Trash,
    UnreadMail,
    Block,
};
