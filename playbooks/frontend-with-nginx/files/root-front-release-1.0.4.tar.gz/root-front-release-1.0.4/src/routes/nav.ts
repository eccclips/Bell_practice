import { useMemo } from 'react';

import { PERMISSIONS, useUserPermissionsState } from 'root-front/store';
import { hasPermissions } from 'root-front/utils';

import ActivityZoneIcon from 'src/assets/icons/activity-zone.svg';
import BarChartIcon from 'src/assets/icons/bar_chart.svg';
import BoxIcon from 'src/assets/icons/box.svg';
import BusinessIcon from 'src/assets/icons/business.svg';
import CalculateIcon from 'src/assets/icons/calculate.svg';
import CalendarClockIcon from 'src/assets/icons/calendar-clock.svg';
import CalendarMonthIcon from 'src/assets/icons/calendar-month.svg';
import CategoryIcon from 'src/assets/icons/category.svg';
import ContractDeleteIcon from 'src/assets/icons/contract-delete.svg';
import CustomerOrderIcon from 'src/assets/icons/customer-order.svg';
import DescriptionIcon from 'src/assets/icons/description.svg';
import DictionaryIcon from 'src/assets/icons/dictionary.svg';
import FactCheckIcon from 'src/assets/icons/fact-check.svg';
import Inventory2Icon from 'src/assets/icons/inventory-2.svg';
import InventoryIcon from 'src/assets/icons/inventory.svg';
import ListAltIcon from 'src/assets/icons/list-alt.svg';
import ListIcon from 'src/assets/icons/list.svg';
import OrderIcon from 'src/assets/icons/order.svg';
import OverviewIcon from 'src/assets/icons/overview.svg';
import PackageIcon from 'src/assets/icons/package.svg';
import PaperTabletIcon from 'src/assets/icons/paper-tablet.svg';
import ParameterIcon from 'src/assets/icons/parameter.svg';
import PathIcon from 'src/assets/icons/path.svg';
import PenIcon from 'src/assets/icons/pen.svg';
import PercentIcon from 'src/assets/icons/percent.svg';
import QuickReferenceIcon from 'src/assets/icons/quick-reference.svg';
import ReceiptIcon from 'src/assets/icons/receipt.svg';
import ReportIcon from 'src/assets/icons/report.svg';
import RouteIcon from 'src/assets/icons/route.svg';
import RubleIcon from 'src/assets/icons/ruble.svg';
import ScaleIcon from 'src/assets/icons/scale.svg';
import SettingsApplicationsIcon from 'src/assets/icons/settings-applications.svg';
import ShelveIcon from 'src/assets/icons/shelve.svg';
import ShippingIcon from 'src/assets/icons/shipping.svg';
import ShoppingBagIcon from 'src/assets/icons/shopping-bag.svg';
import StackedBarIcon from 'src/assets/icons/stacked-bar.svg';
import StockIcon from 'src/assets/icons/stock.svg';
import StoreIcon from 'src/assets/icons/store.svg';
import TableChartViewIcon from 'src/assets/icons/table-chart-view.svg';
import UserManagementIcon from 'src/assets/icons/user-management.svg';
import UsersIcon from 'src/assets/icons/users.svg';

export type NavTab = {
    name: string;
    path?: string;
    Icon?: React.FC<{ [key: string]: any }>;
    children?: NavTab[];
};

type NavTabWithPermissions = {
    name: string;
    path?: string;
    Icon?: React.FC<{ [key: string]: any }>;
    children?: NavTabWithPermissions[];
    permissions?: PERMISSIONS[];
};

const NAVIGATION_TABS: NavTabWithPermissions[] = [
    {
        name: 'Склады',
        Icon: StoreIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_WAREHOUSES],
                name: 'Справочник складов',
                Icon: DictionaryIcon,
                path: '/warehouse/warehouses',
            },
            {
                permissions: [PERMISSIONS.VIEW_WAREHOUSE_ORDER_TYPES],
                name: 'Типы складских заказов',
                Icon: ListAltIcon,
                path: '/warehouse/order-type',
            },
        ],
    },
    {
        name: 'Остатки и запасы',
        Icon: StockIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_WAREHOUSE_STOCK_BALANCE],
                name: 'Складские запасы',
                Icon: ShelveIcon,
                path: '/warehouse/stock-balance',
            },
            {
                permissions: [PERMISSIONS.VIEW_NORMATIVE_STOCK_RESERVE],
                name: 'Нормативный запас',
                Icon: QuickReferenceIcon,
                path: '/warehouse/normative-stock-reserve',
            },
            {
                permissions: [PERMISSIONS.VIEW_ASSEMBLY_PLAN_REMAINDER],
                name: 'Остатки по планам сборки РК и потребности в КИ',
                Icon: BoxIcon,
                path: '/warehouse/assembly-plan-remainder',
            },
        ],
    },
    {
        name: 'Расчет ресурса В2В',
        Icon: BarChartIcon,
        children: [
            {
                name: 'Задания на расчет',
                Icon: PaperTabletIcon,
                path: '/availability/calc-task-b2b',
            },
            {
                name: 'Настройка расчета',
                Icon: ParameterIcon,
                path: '/availability/b2b-resource-calc-params',
            },
            {
                name: 'Коэффициенты запаса',
                Icon: PenIcon,
                path: '/availability/stock-balance-coef',
            },
            {
                name: 'Исключения из ресурса B2B',
                Icon: ContractDeleteIcon,
                path: 'availability/resources-exclude-b2b',
            },
            {
                name: 'Отчет ресурса В2В',
                Icon: ReportIcon,
                path: '/availability/calc-task-b2b-report',
            },
        ],
    },
    {
        name: 'Доступность',
        Icon: InventoryIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_DOCUMENT_RESOURCE_WAREHOUSE],
                name: 'Документы «Склады расчета ресурса/запаса»',
                path: '/availability/documents',
                Icon: PaperTabletIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_AVAILABILITY_CATEGORIES],
                name: 'Категории доступности запасов/ресурсов',
                Icon: ListAltIcon,
                path: '/availability/categories',
            },
            {
                permissions: [PERMISSIONS.VIEW_SALES_FORECAST],
                name: 'Прогнозы продаж',
                Icon: TableChartViewIcon,
                path: '/availability/sales-forecast',
            },
            {
                permissions: [PERMISSIONS.VIEW_AVAILABILITY_SCHEDULE],
                name: 'График доступности ресурса',
                Icon: BoxIcon,
                path: `/availability/availability-schedule/resource`,
            },
            {
                permissions: [PERMISSIONS.VIEW_AVAILABILITY_SCHEDULE],
                name: 'График доступности запаса',
                Icon: ShelveIcon,
                path: `/availability/availability-schedule/reserve`,
            },
            {
                permissions: [PERMISSIONS.VIEW_AVAILABILITY_SCHEDULE],
                name: 'История графиков запаса и ресурса',
                Icon: DictionaryIcon,
                path: '/availability/calc-task-availability-schedule',
            },
        ],
    },
    {
        name: 'Ресурс ОО',
        Icon: Inventory2Icon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_RESOURCE_OPT],
                name: 'Документы «Доступный ресурс ОО»',
                Icon: PaperTabletIcon,
                path: '/availability/calc-params-opt',
            },
            {
                permissions: [PERMISSIONS.VIEW_RESOURCE_OPT],
                name: 'Задания на расчет',
                Icon: ListAltIcon,
                path: '/availability/calc-task-opt',
            },
            {
                permissions: [PERMISSIONS.VIEW_RESOURCE_OPT],
                name: 'Формулы расчета ресурса ОО',
                Icon: PercentIcon,
                path: '/availability/opt-formula',
            },
            {
                permissions: [PERMISSIONS.VIEW_RESOURCE_OPT],
                name: 'Корректирующие документы «Изменения ресурса склада»',
                Icon: DictionaryIcon,
                path: '/availability/document-warehouse-change',
            },
            {
                permissions: [PERMISSIONS.VIEW_WHOLESALE_DEMAND],
                name: 'Сводная потребность ОО',
                Icon: ParameterIcon,
                path: '/availability/wholesale-demand',
            },
            {
                permissions: [PERMISSIONS.VIEW_RESOURCE_OPT],
                name: 'Исключения из ресурса ОО',
                Icon: ContractDeleteIcon,
                path: '/availability/wholesale-exclude',
            },
        ],
    },
    {
        name: 'Номенклатура',
        Icon: CategoryIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_PRODUCT],
                name: 'Каталог номенклатуры',
                path: '/product/positions',
                Icon: PaperTabletIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_SIGN_DELIVERY],
                name: 'Признаки поставки номенклатуры',
                path: '/product/delivery-attribute',
                Icon: FactCheckIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_SUBCONTRACT_MODEL],
                name: 'Справочник субподрядных моделей',
                path: '/product/models',
                Icon: DictionaryIcon,
            },
        ],
    },
    {
        name: 'Справочники',
        Icon: DictionaryIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_UNIT_OFF_MEASUREMENT],
                name: 'Единицы измерений',
                path: '/reference/references',
                Icon: ScaleIcon,
            },
            {
                name: 'Валюты',
                path: '/reference/currency',
                Icon: RubleIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_FORMULA],
                name: 'Параметры формул',
                path: '/reference/formula-parameter',
                Icon: PercentIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_FORMULA],
                name: 'Пользовательские формулы и переменные',
                path: '/reference/formula',
                Icon: CalculateIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_SPECIFICATION_TYPE],
                name: 'Типы спецификации',
                path: '/reference/specification-type',
                Icon: ListAltIcon,
            },
            {
                permissions: [PERMISSIONS.VIEW_ORDER_GROUP],
                name: 'Группы заказов покупателей',
                path: '/warehouse/order-group',
                Icon: PaperTabletIcon,
            },
        ],
    },
    {
        name: 'Контрагенты',
        Icon: BusinessIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_COUNTERPARTY],
                name: 'Справочник контрагентов',
                Icon: ListIcon,
                path: '/counterparty/counterparties',
            },
            {
                permissions: [PERMISSIONS.VIEW_BUSINESS_DOMAIN],
                name: 'Справочник направлений деятельности',
                Icon: ListAltIcon,
                path: '/counterparty/activities',
            },
            {
                permissions: [PERMISSIONS.VIEW_AGREEMENT_TYPE],
                name: 'Виды соглашения',
                Icon: FactCheckIcon,
                path: '/counterparty/agreement-type',
            },
            {
                permissions: [PERMISSIONS.VIEW_AGREEMENT],
                name: 'Соглашения контрагентов',
                Icon: PaperTabletIcon,
                path: '/counterparty/contractor-agreement',
            },
            {
                permissions: [PERMISSIONS.VIEW_FINANCIAL_LIMIT],
                name: 'Управление финансовыми лимитами и ограничениями',
                Icon: StackedBarIcon,
                path: '/counterparty/financial-limit',
            },
        ],
    },
    {
        name: 'Цепочки обеспечения',
        Icon: PathIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_SUPPLY_CHAIN],
                name: 'Цепочки обеспечения',
                Icon: RouteIcon,
                path: '/supply-chain/supply-chain',
            },
            {
                permissions: [PERMISSIONS.VIEW_LOGISTIC_ZONE],
                name: 'Логистические зоны',
                Icon: ActivityZoneIcon,
                path: '/supply-chain/logistic-zone',
            },
        ],
    },
    {
        name: 'Логистика',
        Icon: ShippingIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_LOGISTIC],
                name: 'Управление логистическим стандартом',
                Icon: ParameterIcon,
                path: '/logistic/routes',
            },
            {
                permissions: [PERMISSIONS.VIEW_WAREHOUSE_ROUTE_TIME],
                name: 'Справочник времени в пути между складами',
                Icon: OverviewIcon,
                path: '/logistic/warehouse-route-time',
            },
        ],
    },
    {
        name: 'Поставки',
        Icon: PackageIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_SUPPLY_SCHEDULE],
                name: 'Графики поставок',
                Icon: CalendarMonthIcon,
                path: '/supply/schedule',
            },
            {
                permissions: [PERMISSIONS.VIEW_SUPPLY_SHIPMENT],
                name: 'Документы ПУО',
                Icon: DictionaryIcon,
                path: '/supply/shipment',
            },
        ],
    },
    {
        name: 'Заказы',
        Icon: OrderIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_ORDER_MOVEMENT],
                name: 'Заказы на перемещение',
                Icon: CustomerOrderIcon,
                path: '/order/movement',
            },
            {
                name: 'Заказы на продажу',
                Icon: ShoppingBagIcon,
                path: '/order/sale',
            },
            {
                name: 'Заявки',
                Icon: PaperTabletIcon,
                path: '/order/request',
            },
            {
                name: 'Планы продаж',
                Icon: ReceiptIcon,
                path: '/order/sales-plan',
            },
            {
                permissions: [PERMISSIONS.VIEW_SUPPLY_CHAIN_REPROCESSING_TASK],
                name: 'Задания переподбора ЦО',
                Icon: RouteIcon,
                path: '/order/supply-chain-reprocessing-task',
            },
            {
                permissions: [PERMISSIONS.VIEW_SUPPLY_CHAIN_REPROCESSING_HISTORY],
                name: 'История переподбора обеспечения по Заказам покупателя',
                Icon: InventoryIcon,
                path: '/order/reprocessing-history',
            },
            {
                name: 'Задания на реприоретизацию заказов',
                Icon: ListAltIcon,
                path: '/order/order-reprioritizing-task',
            },
            {
                name: 'Задания на формирование партий НГО',
                Icon: DictionaryIcon,
                path: '/order/calc-task-wso-party',
            },
            {
                name: 'Партии НГО',
                Icon: PaperTabletIcon,
                path: '/order/wso-parties',
            },
            {
                name: 'Отчет НГО',
                Icon: CalendarMonthIcon,
                path: '/order/wso-parties-report',
            },
        ],
    },
    {
        name: 'Складские документы',
        Icon: DescriptionIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_WAREHOUSE_DOCUMENT],
                name: 'Складские документы',
                Icon: PaperTabletIcon,
                path: '/warehouse-document/warehouse-document',
            },
            {
                permissions: [PERMISSIONS.VIEW_WAREHOUSE_DOCUMENT_TYPE],
                name: 'Типы складских документов',
                Icon: ListAltIcon,
                path: '/warehouse-document/warehouse-document-type',
            },
            {
                permissions: [PERMISSIONS.VIEW_TASK],
                name: 'Задания на формирование Заявок на ЗнО',
                Icon: DictionaryIcon,
                path: '/warehouse-document/zno-request-task',
            },
        ],
    },
    {
        name: 'Отчеты',
        Icon: ReceiptIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_RESERVATION_RESULT],
                name: 'Результаты резервирования',
                Icon: PaperTabletIcon,
                path: '/report/reservation-result',
            },
        ],
    },
    {
        name: 'Администрирование',
        Icon: SettingsApplicationsIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_JOB_SETTING],
                name: 'Регламентные задачи',
                Icon: CalendarClockIcon,
                path: '/admin-panel/standard-task',
            },
            {
                permissions: [PERMISSIONS.VIEW_SYSTEM_SETTINGS],
                name: 'Системные переменные',
                Icon: FactCheckIcon,
                path: '/reference/system-params',
            },
            {
                permissions: [PERMISSIONS.VIEW_NOTIFICATION_TEMPLATE],
                name: 'Шаблоны уведомлений',
                Icon: DictionaryIcon,
                path: '/admin-panel/notification-template',
            },
        ],
    },
    {
        name: 'Пользователи',
        Icon: UsersIcon,
        children: [
            {
                permissions: [PERMISSIONS.VIEW_USER],
                name: 'Управление пользователями',
                Icon: UserManagementIcon,
                path: '/user/users',
            },
            {
                permissions: [PERMISSIONS.VIEW_ROLE],
                name: 'Управление ролями',
                Icon: ListAltIcon,
                path: '/user/roles',
            },
        ],
    },
];

export const useNavigationTabs = (): NavTab[] => {
    const userPermissions = useUserPermissionsState();

    const allowedTabs = useMemo(() => {
        const check = (tabs: NavTabWithPermissions[]): NavTab[] => {
            const allowedTabs: NavTab[] = [];
            tabs.forEach((tab) => {
                if (tab.permissions) {
                    if (!hasPermissions(userPermissions, tab.permissions)) {
                        return;
                    }
                }
                if (tab.children?.length) {
                    const children = check(tab.children);
                    if (children.length === 0) {
                        return;
                    }
                    allowedTabs.push({ ...tab, children });
                    return;
                }

                allowedTabs.push(tab);
            });

            return allowedTabs;
        };

        return check(NAVIGATION_TABS);
    }, [userPermissions]);

    return allowedTabs;
};
