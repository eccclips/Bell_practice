import React, { useEffect, useMemo } from 'react';

import { DateView } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { Control, UseFormSetValue, useWatch } from 'react-hook-form';

import { typedMemo, useEvent } from 'root-front/utils';

import { Fields } from '../../../../../fields';
import { getViews } from '../date';

type DateFieldRangeProps<T> = {
    control: Control<T>;
    setValue: UseFormSetValue<Record<string, any>>;
    name: any;
    label: string;
    datePickerView: DateView;
    onChange?: (value: any, setValue: UseFormSetValue<Record<string, any>>) => void;
};

const DateFieldRange = <T,>(props: DateFieldRangeProps<T>) => {
    const { control, setValue, name, label, datePickerView, onChange } = props;

    const nameFrom = `${name}.from`;
    const nameTo = `${name}.to`;

    const valueFrom = useWatch({ control, name: nameFrom as any }) as dayjs.Dayjs;
    const valueTo = useWatch({ control, name: nameTo as any }) as dayjs.Dayjs;

    const labelFrom = `${label} с`;
    const labelTo = `${label} по`;

    const handleChange = useEvent(() => {
        onChange?.({ from: valueFrom, to: valueTo }, setValue);
    });

    useEffect(() => {
        if (valueFrom && valueTo && dayjs(valueFrom).isAfter(valueTo)) {
            setValue(nameFrom, valueTo);
        }
    }, [valueFrom]);

    useEffect(() => {
        if (valueTo && valueFrom && dayjs(valueTo).isBefore(valueFrom)) {
            setValue(nameTo, valueFrom);
        }
    }, [valueTo]);

    const views = useMemo(() => getViews(datePickerView), [datePickerView]);

    return (
        <>
            <label htmlFor={nameFrom}>{labelFrom}</label>
            <Fields.DatePicker
                control={control}
                name={nameFrom as any}
                id={nameFrom}
                views={views}
                openTo={datePickerView || 'day'}
                onChange={handleChange}
            />
            <label htmlFor={nameTo}>{labelTo}</label>
            <Fields.DatePicker
                control={control}
                name={nameTo as any}
                id={nameTo}
                views={views}
                openTo={datePickerView || 'day'}
                onChange={handleChange}
            />
        </>
    );
};

export default typedMemo(DateFieldRange);
