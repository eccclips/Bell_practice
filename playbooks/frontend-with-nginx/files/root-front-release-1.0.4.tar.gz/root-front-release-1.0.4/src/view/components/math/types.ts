import { Control, UseFormGetValues, UseFormSetValue } from 'react-hook-form';

import { CustomFormulaDTO, FormulaParameterDTO, FormulaVariableDTO } from 'root-front/dictionaries';

import { ARGUMENT_TYPE, ELEMENT_TYPE, OPERATOR_TYPE } from './constants';

export type Formula = {
    uid: string;
} & (
    | { type: ELEMENT_TYPE.OPERATOR; operator?: OPERATOR_TYPE; operands: Formula[] }
    | ({
          type: ELEMENT_TYPE.ARGUMENT;
      } & (
          | { argumentType: ARGUMENT_TYPE.CONSTANT; constant: number }
          | {
                argumentType: ARGUMENT_TYPE.PARAMETER;
                parameter: FormulaParameterDTO;
                negative: boolean;
            }
          | {
                argumentType: ARGUMENT_TYPE.FORMULA;
                parameter: CustomFormulaDTO;
                negative: boolean;
            }
          | {
                argumentType: ARGUMENT_TYPE.CUSTOMIZED_PARAMETER;
                parameter: CustomFormulaDTO;
                negative: boolean;
            }
          | {
                argumentType: ARGUMENT_TYPE.RESOURCE_FORMULA_B2B;
                parameter: FormulaVariableDTO;
                negative: boolean;
            }
          | {
                argumentType: ARGUMENT_TYPE.RESOURCE_FORMULA_OPT;
                parameter: FormulaVariableDTO;
                negative: boolean;
            }
      ))
);

export type FormulaViewerProps = {
    formula: Formula;
    hoveredOperand?: string;
    onHover?: (uid: string | null) => void;
    size?: 'small' | 'medium' | 'large';
    error?: string;
};

export type FormulaConstructorFormProps = {
    defaultValues?: Formula;
    onSubmit?: (formula: Formula) => void;
    onClose?: () => void;
};

export type AdditionalArgument =
    | {
          type: ARGUMENT_TYPE.RESOURCE_FORMULA_OPT;
          requestData?: Record<string, any>;
      }
    | {
          type: ARGUMENT_TYPE.RESOURCE_FORMULA_B2B;
          requestData: { calcParamsB2bId: number } & Record<string, any>;
      };

export type FormulaConstructorProps = {
    name: string;
    control: Control<any>;
    setValue: UseFormSetValue<any>;
    getValues: UseFormGetValues<any>;
    additionalArguments?: AdditionalArgument[];
    children?: React.ReactNode;
};

export type FormulaConstructorOperandProps = {
    prefixName: string;
    control: Control<{ formula: Formula }>;
    hoveredOperand?: string;
    title?: string;
    handleChangeElementType: (
        prefixName: string
    ) => (e: any, child: any, value: ELEMENT_TYPE) => void;
    handleChangeOperatorType: (
        prefixName: string,
        operands: Formula[]
    ) => (e: any, child: any, value: OPERATOR_TYPE) => void;
    handleChangeArgumentType: (
        prefixName: string
    ) => (e: any, child: any, value: ARGUMENT_TYPE) => void;
    handleAppendOperand: (prefixName: string, operands: Formula[]) => () => void;
    handleRemoveOperand: (prefixName: string) => () => void;
    additionalArguments?: AdditionalArgument[];
    deletable?: boolean;
    children?: React.ReactNode;
};
