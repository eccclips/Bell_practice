export interface UserInfoUDB {
    clientId: string;
    employeeId: string;
    fullName: string;
    username: string;
}
