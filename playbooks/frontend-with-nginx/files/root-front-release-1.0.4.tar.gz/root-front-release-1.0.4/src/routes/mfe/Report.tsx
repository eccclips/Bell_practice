import React from 'react';

import { ErrorBoundary, PageLoader } from 'root-front/components';

import { loadModule } from 'src/utils';

const ReportMFE = React.lazy(() => loadModule(process.env.MFE_REPORT_HOST, './Report'));

export function ReportRoute() {
    return (
        <ErrorBoundary>
            <React.Suspense fallback={<PageLoader />}>
                <ReportMFE />
            </React.Suspense>
        </ErrorBoundary>
    );
}
