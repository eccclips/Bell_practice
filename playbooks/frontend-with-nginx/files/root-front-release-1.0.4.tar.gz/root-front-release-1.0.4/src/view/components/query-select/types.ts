import { UseInfiniteQueryResult } from '@tanstack/react-query';

import { SelectOption } from 'root-front/components';
import { ResponseDTO } from 'root-front/interfaces';

export type QuerySelectFetchParams<T = Record<string, any>> = T & {
    search: string;
    enabled: boolean;
};

export type QuerySelectProps<Data, Value = Data, Multiple extends boolean | undefined = false> = {
    value: Multiple extends true ? Value[] : Value;
    loadingText?: string;
    noOptionsText?: string;
    placeholder?: string;
    label?: string;
    helperText?: React.ReactNode;
    error?: boolean;
    id?: string;
    inputRef?: React.Ref<any>;
    query: (params: QuerySelectFetchParams) => UseInfiniteQueryResult<ResponseDTO<Data[]>>;
    getOptionFromData: (value: Data) => SelectOption<Value>;
    getOptionFromValue?: (value: Value) => SelectOption<Value>;
    getOptionDisabled?: (option: SelectOption<Value>) => boolean;
    groupBy?: (option: SelectOption<Value>) => string;
    onChange?: (value: Multiple extends true ? Value[] : Value) => void;
    onBlur?: React.FocusEventHandler<HTMLDivElement>;
    multiple?: Multiple;
    disabled?: boolean;
    disableCloseOnSelect?: boolean;
    readOnly?: boolean;
    sortableMode?: boolean;
    className?: string;
    withStaticHelperText?: boolean;
    limitTags?: number;
    loading?: boolean;
    saveSearchInputValue?: boolean;
};
