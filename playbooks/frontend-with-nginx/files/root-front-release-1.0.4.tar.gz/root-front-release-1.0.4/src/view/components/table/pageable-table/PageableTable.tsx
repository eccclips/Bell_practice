import React, { useCallback, useEffect, useMemo, useState } from 'react';

import { typedMemo, useEvent } from 'root-front/utils';

import { DEFAULT_ITEMS_PER_PAGE } from '../constants';
import { TableFooter } from '../footer';
import { SimpleTable } from '../simple-table';
import { PageableTableProps, TABLE_VIEW_MODE } from '../types';

import styles from '../Table.module.scss';

const PageableTable = <Data,>(props: PageableTableProps<Data>) => {
    const {
        data,
        itemsPerPage = DEFAULT_ITEMS_PER_PAGE,
        viewMode = TABLE_VIEW_MODE.INNER_SCROLL,
        isEmpty: isEmptyProp,
        ...rest
    } = props;

    const [page, setPage] = useState(0);
    const [size, setSize] = useState(itemsPerPage[0]);

    const totalElements = data?.length;

    const totalPages = useMemo(
        () => (data?.length ? Math.ceil(data.length / size) : 0),
        [data, size]
    );

    const onPageChange = useCallback((page: number) => {
        setPage(page);
    }, []);

    const onSizeChange = useEvent((size: number) => {
        setSize(size);
        if (page + 1 >= Math.ceil(data.length / size)) {
            setPage(0);
        }
    });

    const pageableData = useMemo(() => {
        if (!data?.length) {
            return [];
        }

        return data.slice(page * size, (page + 1) * size);
    }, [data, page, size]);

    const isEmpty = !pageableData?.length;

    useEffect(() => {
        setPage(0);
    }, [data]);

    return (
        <div className={styles.container}>
            <SimpleTable
                {...rest}
                data={pageableData}
                viewMode={viewMode}
                isEmpty={isEmptyProp || isEmpty}
            />
            <TableFooter
                page={page}
                size={size}
                totalElements={totalElements}
                totalPages={totalPages}
                itemsPerPage={itemsPerPage}
                onPageChange={onPageChange}
                onSizeChange={onSizeChange}
            />
        </div>
    );
};

export default typedMemo(PageableTable);
