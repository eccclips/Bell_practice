export const defaultIsEqualValues = (a: any, b: any) => a === b;
