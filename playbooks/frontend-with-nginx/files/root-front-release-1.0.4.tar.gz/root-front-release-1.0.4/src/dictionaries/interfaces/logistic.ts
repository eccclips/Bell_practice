import { COUNTERPARTY_ROUTE_TIME_STATUS } from 'root-front/dictionaries';
import { BaseAuditedDTO, UserInfoUDB } from 'root-front/interfaces';

import {
    BASE_STATUS,
    CounterpartyDTO,
    ROUTE_RECEIVER_TYPE,
    ROUTE_STATUS,
    ROUTE_TYPE,
    TIMETABLE_STATUS,
    WAREHOUSE_ROUTE_TIME_STATUS,
    WarehouseDTO,
} from '../';

export interface TimetableDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: number;
    createdBy: UserInfoUDB;
    lastModifiedDate: number;
    lastModifiedBy: UserInfoUDB;
    year: number;
    timetableExternalId: string;
    cutOffDateTime: number;
    pikingDateTime: string;
    loadDateTime: number;
    departureDateTime: string;
    responsible: string;
    status: TIMETABLE_STATUS;
}

export interface TimetableCalendarDTO {
    departureDateTime: string;
    loadDateTime: string;
    pikingDateTime: string;
    cutOffDateTime: string;
}

export interface RouteConsigneeDTO extends BaseAuditedDTO {
    externalId: string;
    consignee: CounterpartyDTO;
    warehouse: WarehouseDTO;
    routeType: ROUTE_TYPE;
    status: BASE_STATUS;
    receiverType: ROUTE_RECEIVER_TYPE;
}

export interface RouteDTO extends BaseAuditedDTO {
    externalId: string;
    routeId: string;
    code: string;
    name: string;
    status: ROUTE_STATUS;
    warehouse: WarehouseDTO;
    responsible: string;
    consignees: RouteConsigneeDTO[];
}

export interface WarehouseRouteTimeDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: number;
    createdBy: UserInfoUDB;
    lastModifiedDate: number;
    lastModifiedBy: UserInfoUDB;
    fromWarehouse: WarehouseDTO;
    toWarehouse: WarehouseDTO;
    time: number;
    responsible: string;
    status: WAREHOUSE_ROUTE_TIME_STATUS;
}

export interface CounterpartyRouteTimeDTO {
    id: number;
    externalId: string;
    isDeleted: boolean;
    createdDate: number;
    createdBy: UserInfoUDB;
    lastModifiedDate: number;
    lastModifiedBy: UserInfoUDB;
    counterparty: CounterpartyDTO;
    warehouse: WarehouseDTO;
    timeDelivery: number;
    status: COUNTERPARTY_ROUTE_TIME_STATUS;
}
