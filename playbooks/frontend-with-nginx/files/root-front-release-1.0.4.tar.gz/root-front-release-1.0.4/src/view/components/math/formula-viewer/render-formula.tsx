import React from 'react';

import cn from 'classnames';

import { ARGUMENT_TYPE, ELEMENT_TYPE, OPERATOR_TYPE } from '../constants';
import { Formula } from '../types';

import styles from './FormulaViewer.module.scss';

type RenderFormulaConfig = {
    formula: Formula;
    depth: number;
    hoveredOperand: string;
    onHover: (e: React.MouseEvent<HTMLSpanElement> | React.MouseEvent<HTMLSpanElement>) => void;
};

const OPERANDS_WITH_INNER_BRACKETS = [
    OPERATOR_TYPE.SQRT,
    OPERATOR_TYPE.MAX,
    OPERATOR_TYPE.MIN,
    OPERATOR_TYPE.FLOOR,
    OPERATOR_TYPE.CEIL,
    OPERATOR_TYPE.ABS,
];

export const renderFormula = (config: RenderFormulaConfig): JSX.Element => {
    const { formula, depth, hoveredOperand, onHover } = config;

    let result: JSX.Element = null;

    const renderOperands = (operands: Formula[]) =>
        operands?.map((operand) =>
            renderFormula({ formula: operand, depth: depth + 1, hoveredOperand, onHover })
        );
    const renderOperandsWithoutDepth = (operands: Formula[]) =>
        operands?.map((operand) =>
            renderFormula({ formula: operand, depth: 0, hoveredOperand, onHover })
        );

    const concatWithSign = (sign: string, operands: JSX.Element[]) =>
        operands?.flatMap((operand: JSX.Element, index: number, array: JSX.Element[]) => [
            operand,
            ...(index < array.length - 1
                ? [
                      <span
                          className={styles.formula__sign}
                          data-uid={formula.uid}
                          key={`${formula.uid}_${index}`}
                      >
                          {sign}
                      </span>,
                  ]
                : []),
        ]);
    const concatWithComma = (operands: JSX.Element[]) =>
        operands?.flatMap((operand: JSX.Element, index: number, array: JSX.Element[]) => [
            operand,
            ...(index < array.length - 1
                ? [
                      <span
                          className={styles.formula__comma}
                          data-uid={formula.uid}
                          key={`${formula.uid}_${index}`}
                      >
                          ,
                      </span>,
                  ]
                : []),
        ]);

    const wrapWithBrackets = (
        operands: JSX.Element[],
        leftBracket: string = '(',
        rightBracket: string = ')'
    ) => {
        operands.unshift(
            <span key={`${formula.uid}_${leftBracket}_left`} data-uid={formula.uid}>
                {leftBracket}
            </span>
        );

        operands.push(
            <span key={`${formula.uid}_${rightBracket}_right`} data-uid={formula.uid}>
                {rightBracket}
            </span>
        );
    };

    const wrapWithOperator = (operands: JSX.Element[], operator: string) => {
        wrapWithBrackets(operands);

        operands.unshift(
            <span
                key={`${formula.uid}_${operator}`}
                data-uid={formula.uid}
                className={styles.formula__operator}
            >
                {operator}
            </span>
        );
    };

    if (formula?.type === ELEMENT_TYPE.OPERATOR) {
        let operands: JSX.Element[] = null;

        switch (formula.operator) {
            case OPERATOR_TYPE.PLUS:
                operands = concatWithSign('+', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.MINUS:
                operands = concatWithSign('–', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.MULTIPLY:
                operands = concatWithSign('⋅', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.DIVIDE:
                operands = concatWithSign('/', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.POW:
                operands = concatWithSign('^', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.SQRT:
                operands = concatWithComma(renderOperandsWithoutDepth(formula.operands));
                wrapWithOperator(operands, '√');
                break;
            case OPERATOR_TYPE.MAX:
                operands = concatWithComma(renderOperandsWithoutDepth(formula.operands));
                wrapWithOperator(operands, 'MAX');
                break;
            case OPERATOR_TYPE.MIN:
                operands = concatWithComma(renderOperandsWithoutDepth(formula.operands));
                wrapWithOperator(operands, 'MIN');
                break;
            case OPERATOR_TYPE.DIV:
                operands = concatWithSign('//', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.MOD:
                operands = concatWithSign('%', renderOperands(formula.operands));
                break;
            case OPERATOR_TYPE.FLOOR:
                operands = concatWithComma(renderOperandsWithoutDepth(formula.operands));
                wrapWithBrackets(operands, '⌊', '⌋');
                break;
            case OPERATOR_TYPE.CEIL:
                operands = concatWithComma(renderOperandsWithoutDepth(formula.operands));
                wrapWithBrackets(operands, '⌈', '⌉');
                break;
            case OPERATOR_TYPE.ABS:
                operands = concatWithComma(renderOperandsWithoutDepth(formula.operands));
                wrapWithBrackets(operands, '|', '|');
                break;
            default:
                operands = [<React.Fragment key={formula.uid}>?</React.Fragment>];
        }

        if (depth !== 0 && !OPERANDS_WITH_INNER_BRACKETS.includes(formula.operator)) {
            result = <React.Fragment key={`${formula.uid}`}>({operands})</React.Fragment>;
        } else {
            result = <React.Fragment>{operands}</React.Fragment>;
        }
    } else {
        switch (formula?.argumentType) {
            case ARGUMENT_TYPE.CONSTANT:
                result = <>{formula.constant || '?'}</>;
                break;
            case ARGUMENT_TYPE.PARAMETER:
            case ARGUMENT_TYPE.CUSTOMIZED_PARAMETER:
                result = (
                    <span data-uid={formula.uid} className={styles.formula__parameter}>
                        {`${formula.negative ? '-' : ''}${formula.parameter?.name || '?'}`}
                    </span>
                );
                break;
            case ARGUMENT_TYPE.FORMULA:
                result = (
                    <span data-uid={formula.uid} className={styles.formula__formula}>
                        <span data-uid={formula.uid} className={styles.formula__formulaSign}>
                            {formula.negative ? '-' : ''}ƒ
                        </span>
                        <span data-uid={formula.uid} className={styles.formula__formulaName}>
                            {formula.parameter?.name || '?'}
                        </span>
                    </span>
                );
                break;
            case ARGUMENT_TYPE.RESOURCE_FORMULA_B2B:
                result = (
                    <span data-uid={formula.uid} className={styles.formula__formula}>
                        <span data-uid={formula.uid} className={styles.formula__formulaSign}>
                            {formula.negative ? '-' : ''}ƒ
                        </span>
                        <span data-uid={formula.uid} className={styles.formula__formulaName}>
                            {formula.parameter?.name || '?'}
                        </span>
                    </span>
                );
                break;
            case ARGUMENT_TYPE.RESOURCE_FORMULA_OPT:
                result = (
                    <span data-uid={formula.uid} className={styles.formula__formula}>
                        <span data-uid={formula.uid} className={styles.formula__formulaSign}>
                            {formula.negative ? '-' : ''}ƒ
                        </span>
                        <span data-uid={formula.uid} className={styles.formula__formulaName}>
                            {formula.parameter?.name || '?'}
                        </span>
                    </span>
                );
                break;
        }
    }

    return (
        <span
            key={formula?.uid}
            data-uid={formula?.uid}
            className={cn(
                styles.formula__element,
                formula?.uid &&
                    hoveredOperand &&
                    hoveredOperand === formula.uid &&
                    styles.formula__element_hovered
            )}
            onMouseOver={onHover}
            onClick={onHover}
        >
            {result}
        </span>
    );
};
