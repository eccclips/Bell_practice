import React, { useCallback } from 'react';

import { ButtonBase, IconButton, SvgIcon } from '@mui/material';
import cn from 'classnames';

import { Icons } from 'root-front/icons';

import emptyListUrl from '../../../../../../assets/icons/empty-list.svg?url';
import { LoaderOverlay } from '../../../../loader-overlay';
import { SavedFilter, TableProps } from '../../../types';
import { ImportFilters } from './import-filters';

import styles from './TableSavedFilters.module.scss';

type TableSavedFiltersProps = Pick<TableProps<any>, 'savedFilters'> & {
    setOpenedFilterModal: React.Dispatch<React.SetStateAction<boolean>>;
};

const TableSavedFilters = (props: TableSavedFiltersProps) => {
    const { savedFilters, setOpenedFilterModal } = props;

    const { data, isLoading } = savedFilters.useSavedFilters();

    const handleApplyFilter = (savedFilter: SavedFilter) => {
        setOpenedFilterModal(false);
        savedFilters.onApplyFilter?.(savedFilter);
    };

    const handleCloseFilterModal = useCallback(() => {
        setOpenedFilterModal(false);
    }, []);

    return (
        <>
            <div className={styles.container}>
                <div className={styles.container__inner}>
                    {data?.map((value) => (
                        <ButtonBase
                            key={value.uid}
                            focusRipple
                            className={cn(
                                styles.filter,
                                value.uid === savedFilters.appliedFilter?.uid &&
                                    styles.filter_applied
                            )}
                            onClick={() => handleApplyFilter(value)}
                        >
                            <span className={styles.filter__name}>{value.name}</span>
                            <IconButton
                                size="small"
                                className={styles.filter__iconButton}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    savedFilters.onDeleteFilter?.(value.uid);
                                }}
                                component="div"
                            >
                                <SvgIcon fontSize="small">
                                    <Icons.Close />
                                </SvgIcon>
                            </IconButton>
                        </ButtonBase>
                    ))}
                    {!isLoading && !data?.length && (
                        <div className={styles.container__empty}>
                            <img src={emptyListUrl} />
                            <span>Здесь пока ничего нет</span>
                        </div>
                    )}
                </div>
                {isLoading && <LoaderOverlay />}
            </div>
            {savedFilters.useUserSavedFilters && savedFilters.onImportUserFilters && (
                <div className={styles.footer}>
                    <ImportFilters
                        savedFilters={savedFilters}
                        closeFilterModal={handleCloseFilterModal}
                    />
                </div>
            )}
        </>
    );
};

export default React.memo(TableSavedFilters);
