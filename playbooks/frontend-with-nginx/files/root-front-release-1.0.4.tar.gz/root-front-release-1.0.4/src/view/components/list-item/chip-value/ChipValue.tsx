import React, { memo } from 'react';

import { Chip, CHIP_COLORS } from '../../chip';

type ChipValueProps = {
    value: string;
    color: CHIP_COLORS;
};

const ChipValue = (props: ChipValueProps) => {
    const { value, color } = props;

    return <Chip label={value} color={color} size="small" />;
};

export default memo(ChipValue);
