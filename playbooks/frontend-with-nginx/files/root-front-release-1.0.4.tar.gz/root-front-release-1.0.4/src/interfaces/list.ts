import { SORT_DIRECTION } from 'root-front/constants';

export interface SortInstructionDTO {
    direction: SORT_DIRECTION;
    field: string;
}

export interface ListPageInfoDTO {
    page: number;
    size: number;
    sort: SortInstructionDTO[];
}

export type ListRequestDTO<T = Record<string, any>> = T & {
    pageInfo: ListPageInfoDTO;
};
