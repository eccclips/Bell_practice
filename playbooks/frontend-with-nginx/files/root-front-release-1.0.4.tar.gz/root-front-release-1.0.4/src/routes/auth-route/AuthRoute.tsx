import React from 'react';

import { Navigate } from 'react-router-dom';

import { useAccessTokenState, useUserPermissionsState } from 'root-front/store';

import { Auth } from 'src/view/pages/auth';

export const AuthRoute = () => {
    const token = useAccessTokenState();
    const permissions = useUserPermissionsState();

    if (token && Array.isArray(permissions)) {
        return <Navigate to="/" />;
    }

    return <Auth />;
};
