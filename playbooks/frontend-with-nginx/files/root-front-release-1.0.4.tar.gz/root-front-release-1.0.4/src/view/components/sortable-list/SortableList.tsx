import React from 'react';

import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';

import { typedMemo } from 'root-front/utils';

export type SortableListProps<T> = {
    list: T[];
    listClassName?: string;
    getItemKey: (item: T) => string;
    renderItem: (item: T, draggable: any, snapshot: any, index: number) => JSX.Element;
    onChange: (list: T[]) => void;
};

const SortableList = <T,>(props: SortableListProps<T>) => {
    const { list, getItemKey, listClassName, renderItem, onChange } = props;

    const onDragEnd = (result) => {
        const { destination, source } = result;

        if (!destination) {
            return;
        }

        if (destination.droppableId === source.droppableId && destination.index === source.index) {
            return;
        }

        const newList = [...list];
        const [column] = newList.splice(source.index, 1);
        newList.splice(destination.index, 0, column);

        onChange(newList);
    };

    return (
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="columns">
                {(provided) => (
                    <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={listClassName}
                    >
                        {list.map((item, index) => {
                            const key = getItemKey(item);

                            return (
                                <Draggable key={key} draggableId={key} index={index}>
                                    {(draggable, snapshot) =>
                                        renderItem(item, draggable, snapshot, index)
                                    }
                                </Draggable>
                            );
                        })}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </DragDropContext>
    );
};

export default typedMemo(SortableList);
