import React from 'react';

import { Button, ButtonProps, CircularProgress } from '@mui/material';
import cn from 'classnames';

import styles from './LoadingButton.module.scss';

type LoadingButtonProps = ButtonProps & {
    isLoading?: boolean;
};

const SIZES_MAP = {
    small: 16,
    medium: 20,
    large: 24,
};

const LoadingButton = (props: LoadingButtonProps) => {
    const { children, isLoading, size, disabled, ...rest } = props;

    return (
        <Button {...rest} size={size} disabled={disabled || isLoading}>
            <>
                {children}
                {isLoading && (
                    <div className={cn(styles.loader)}>
                        <CircularProgress size={SIZES_MAP[size] || SIZES_MAP.medium} />
                    </div>
                )}
            </>
        </Button>
    );
};

export default React.memo(LoadingButton);
