import React, { useState } from 'react';

import { Collapse, IconButton, SvgIcon } from '@mui/material';
import cn from 'classnames';
import { Link } from 'react-router-dom';

import { Icons } from 'root-front/icons';

import { TreeNodeProps } from '../types';

import styles from './TreeNode.module.scss';

const TreeNode = (props: TreeNodeProps) => {
    const { node, collapsable, defaultExpanded, deep, last } = props;

    const [expanded, setExpanded] = useState(!collapsable ? true : defaultExpanded);

    const hasChildren = !!node.children?.length;

    return (
        <div className={styles.node}>
            <div
                className={cn(
                    styles.node__element,
                    (!hasChildren || (!collapsable && deep > 0)) && styles.node__element_noChildren,
                    last && styles.node__element_last,
                    node.selected && styles.node__element_selected
                )}
            >
                {collapsable && hasChildren && (
                    <IconButton
                        size="small"
                        className={styles.node__expandButton}
                        onClick={() => setExpanded((v) => !v)}
                    >
                        <SvgIcon
                            fontSize="small"
                            className={cn(
                                styles.node__icon,
                                expanded && styles.node__icon_expanded
                            )}
                        >
                            <Icons.ArrowRight />
                        </SvgIcon>
                    </IconButton>
                )}
                {typeof node.link === 'string' ? (
                    <Link
                        to={node.link}
                        className={cn(styles.node__title, styles.node__title_link)}
                    >
                        {node.title}
                    </Link>
                ) : (
                    <span className={styles.node__title}>{node.title}</span>
                )}
                {node.rightContent}
            </div>
            {hasChildren && (
                <Collapse in={expanded} mountOnEnter unmountOnExit>
                    <div className={styles.node__children}>
                        {node.children.map((child, index) => (
                            <TreeNode
                                key={child.key}
                                node={child}
                                collapsable={collapsable}
                                defaultExpanded={defaultExpanded}
                                deep={deep + 1}
                                last={index === node.children.length - 1}
                            />
                        ))}
                    </div>
                </Collapse>
            )}
        </div>
    );
};

export default React.memo(TreeNode);
