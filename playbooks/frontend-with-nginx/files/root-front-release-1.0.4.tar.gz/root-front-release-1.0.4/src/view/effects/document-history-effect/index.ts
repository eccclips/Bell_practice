export { default as DocumentHistoryEffect } from './DocumentHistoryEffect';
