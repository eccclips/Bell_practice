import { TableColumn, TableHeadGrid } from '../types';

export const getFlatColumns = (columns: TableColumn[]) => {
    const result: TableColumn[] = [];

    columns.forEach((col) => {
        if (!col.children?.length) {
            result.push(col);
            return;
        }
        result.push(...getFlatColumns(col.children));
    });

    return result;
};

export const getColumnDepth = (column: TableColumn, deep = 0) => {
    if (!column.children?.length) {
        return deep + 1;
    }

    return Math.max(...column.children.map((col) => getColumnDepth(col, deep + 1)));
};

export const getMaxColumnsDepth = (columns: TableColumn[]) => {
    return Math.max(...columns.map((column) => getColumnDepth(column)));
};

export const getColumnLength = (column: TableColumn) => {
    if (!column.children?.length) {
        return 1;
    }

    return column.children.reduce((acc, next) => acc + getColumnLength(next), 0);
};

export const getColumnsGrid = <Data>(columns: TableColumn<Data>[]) => {
    const maxDepth = getMaxColumnsDepth(columns);

    const result: TableHeadGrid<Data> = Array.from({
        length: maxDepth,
    }).map(() => []);

    const calculateGrid = (columns: TableColumn[], depth = 0) => {
        columns.forEach((column) => {
            const colDepth = getColumnDepth(column);
            const colLength = getColumnLength(column);

            result[depth].push({
                colSpan: colLength,
                rowSpan: colDepth > 1 ? 1 : maxDepth - depth - colDepth + 1,
                isGroup: !!column.children?.length,
                column,
            });

            if (column.children?.length) {
                calculateGrid(column.children, depth + 1);
            }
        });
    };

    calculateGrid(columns);

    return result;
};
