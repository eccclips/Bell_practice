import { useCallback, useMemo } from 'react';

import { useTableSettingsState } from 'root-front/store';
import { TableSettings } from 'root-front/types';
import { useEvent } from 'root-front/utils';

import { TableColumn } from '../../table';
import { getDefaultSettings, getMinifiedColumns, getResizedColumns } from '../utils';

type Config = {
    name: string;
    columns: TableColumn[];
};

export const useSettings = (config: Config) => {
    const { name, columns } = config;

    const [tableSettings, setTableSettings] = useTableSettingsState(name);

    const settings: TableSettings = useMemo(
        () => ({ ...getDefaultSettings({ columns }), ...(tableSettings || {}) }),
        [tableSettings, columns]
    );

    const onColumnsSettingsChange = useCallback(
        (nextColumns: TableColumn[]) => {
            setTableSettings((prevSettings) => ({
                ...(prevSettings || {}),
                columns: getMinifiedColumns(nextColumns),
            }));
        },
        [setTableSettings]
    );

    const onColumnsSettingsReset = useEvent(() => {
        setTableSettings((prevSettings) => ({
            ...(prevSettings || {}),
            columns: getMinifiedColumns(columns),
        }));
    });

    const onColumnResize = useEvent((key: string, width: number) => {
        setTableSettings((prevSettings) => {
            return {
                ...(prevSettings || {}),
                columns: getMinifiedColumns(
                    getResizedColumns(prevSettings?.columns || columns, key, width)
                ),
            };
        });
    });

    return { settings, onColumnsSettingsChange, onColumnsSettingsReset, onColumnResize } as const;
};
