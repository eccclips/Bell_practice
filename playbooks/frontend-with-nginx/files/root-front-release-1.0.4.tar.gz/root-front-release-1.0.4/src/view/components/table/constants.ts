export const DEFAULT_ITEMS_PER_PAGE = [20, 50, 100];
