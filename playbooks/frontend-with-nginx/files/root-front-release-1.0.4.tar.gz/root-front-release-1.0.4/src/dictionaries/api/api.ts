const NODE_ENV = process.env.NODE_ENV;
const BASE_URL = NODE_ENV === 'development' ? process.env.DEV_API_HOST : '';

export const MS_AVAILABILITY_URL = `${BASE_URL}/ms-availability`;
export const MS_COUNTERPARTY_URL = `${BASE_URL}/ms-counterparty`;
export const MS_ORDER_URL = `${BASE_URL}/ms-order`;
export const MS_LOGISTIC_URL = `${BASE_URL}/ms-logistic`;
export const MS_PRODUCT_URL = `${BASE_URL}/ms-product`;
export const MS_REFERENCE_URL = `${BASE_URL}/ms-reference`;
export const MS_SCHEDULER_URL = `${BASE_URL}/ms-scheduler`;
export const MS_SUPPLY_URL = `${BASE_URL}/ms-supply`;
export const MS_SUPPLY_CHAIN_URL = `${BASE_URL}/ms-supply-chain`;
export const MS_WAREHOUSE_URL = `${BASE_URL}/ms-warehouse`;
export const MS_WAREHOUSE_DOCUMENT_URL = `${BASE_URL}/ms-warehouse-document`;
export const MS_USER_URL = `${BASE_URL}/ms-user`;
export const MS_NOTIFICATION_URL = `${BASE_URL}/ms-notification`;
export const MS_REPORT_URL = `${BASE_URL}/ms-report`;
