import React, { useMemo } from 'react';

import { useDropzone } from 'react-dropzone';

import { Icons } from 'root-front/icons';

import { LoaderOverlay } from '../../loader-overlay';
import { getAcceptFormats, getStyles } from './constants';
import { DropzoneProps } from './types';

import styles from './Dropzone.module.scss';

const Dropzone = (props: DropzoneProps) => {
    const { name, maxFileSize = 5, formats, disabled, isLoading, multiple, onDropAccepted } = props;

    const accept = useMemo(() => (formats ? getAcceptFormats(formats) : undefined), [formats]);

    const { getRootProps, getInputProps, isDragAccept, isDragReject } = useDropzone({
        accept: accept,
        maxSize: maxFileSize ? maxFileSize * 1024 * 1024 : undefined,
        disabled: disabled || isLoading,
        multiple,
        onDropAccepted,
    });

    const style = useMemo(
        () => getStyles(isDragAccept, isDragReject, disabled),
        [isDragAccept, isDragReject, disabled]
    );

    const hintText = useMemo(
        () =>
            [
                `${formats?.length ? `Доступные форматы: ${formats.join(', ')}` : ''}`,
                `${maxFileSize ? `Максимальный размер файла: ${maxFileSize} мб` : ''}`,
            ]
                .filter(Boolean)
                .join('\n'),
        [formats, maxFileSize]
    );

    return (
        <div {...getRootProps({ style })} className={styles.root}>
            <div className={styles.container}>
                <Icons.Archive className={styles.container__icon} />
                <div className={styles.container__text}>
                    <label>Нажмите или перетащите файл в эту область</label>
                    <input {...getInputProps({ name })} />
                </div>
                {hintText && <div className={styles.container__hint}>{hintText}</div>}
            </div>
            {isLoading && <LoaderOverlay />}
        </div>
    );
};

export default React.memo(Dropzone);
