import { BASE_STATUS, PRIVILEGE_TYPE } from 'root-front/dictionaries';
import { BaseAuditedDTO } from 'root-front/interfaces';

export interface UsersDTO extends BaseAuditedDTO {
    login: string;
    fio: string;
    contact: string;
    email: string;
    employeeNumber: string;
    status: BASE_STATUS;
    responsible: string;
}

export interface RoleDTO extends BaseAuditedDTO {
    name: string;
    status: BASE_STATUS;
    description: string;
    responsible: string;
    hidden: boolean;
}

export interface PrivilegeDTO extends BaseAuditedDTO {
    code: string;
    name: string;
    description: string;
    status: BASE_STATUS;
    type: PRIVILEGE_TYPE;
}

export interface UsersRolesDTO extends BaseAuditedDTO {
    status: BASE_STATUS;
    user: UsersDTO;
    role: RoleDTO;
}

export interface RolesPrivilegesDTO extends BaseAuditedDTO {
    status: BASE_STATUS;
    role: RoleDTO;
    privilege: PrivilegeDTO;
}

export interface KeycloakUserDTO {
    externalId: string;
    isDeleted: boolean;
    login: string;
    fio: string;
    email: string;
}
