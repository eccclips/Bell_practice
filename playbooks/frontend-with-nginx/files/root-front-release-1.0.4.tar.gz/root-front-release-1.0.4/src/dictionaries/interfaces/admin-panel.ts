import { BaseAuditedDTO } from 'root-front/interfaces';

import { STANDARD_TASK_INTERVAL_UNIT, STANDARD_TASK_STATUS } from '../constants';

export interface StandardTaskDTO extends BaseAuditedDTO {
    name: string;
    code: string;
    description?: string;
    intervalUnit: STANDARD_TASK_INTERVAL_UNIT;
    interval?: number;
    timeToRun?: [string];
    status: STANDARD_TASK_STATUS;
    taskType: StandardTaskTypeDTO;
}

export interface StandardTaskTypeDTO {
    id: number;
    code: string;
    name: string;
    description: string;
    method: string;
    service: string;
    url: string;
}
