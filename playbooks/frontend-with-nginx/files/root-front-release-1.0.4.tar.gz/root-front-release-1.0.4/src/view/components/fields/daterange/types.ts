import {
    DatePickerProps,
    DateValidationError,
    PickerChangeHandlerContext,
} from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { UseControllerProps } from 'react-hook-form';

export type DateRangeValue = { from: string | null; to: string | null };

export type DateRangeProps<T> = UseControllerProps<T> &
    Omit<DatePickerProps<dayjs.Dayjs>, 'onChange'> & {
        idFrom?: string;
        idTo?: string;
        withStaticHelperText?: boolean;
        onChange?: (
            value: DateRangeValue,
            ctx: PickerChangeHandlerContext<DateValidationError>
        ) => void;
    };
