export const pluralize = (count: number, variants: [zero: string, one: string, two: string]) => {
    const value = Math.abs(count) % 100;
    const number = value % 10;

    if (value > 10 && value < 20) {
        return variants[0];
    }

    if (number > 1 && number < 5) {
        return variants[2];
    }

    if (number == 1) {
        return variants[1];
    }

    return variants[0];
};
