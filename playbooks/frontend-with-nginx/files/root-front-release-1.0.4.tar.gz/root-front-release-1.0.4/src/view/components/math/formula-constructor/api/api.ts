import { useInfiniteQuery } from '@tanstack/react-query';
import { AxiosResponse } from 'axios';

import { api } from 'root-front/api';
import { SORT_DIRECTION } from 'root-front/constants';
import { CustomFormulaDTO, FormulaParameterDTO, FormulaVariableDTO } from 'root-front/dictionaries';
import { ListRequestDTO, ResponseDTO } from 'root-front/interfaces';
import { getDictionaryQuery } from 'root-front/utils';

import { MS_AVAILABILITY_URL } from '../../../../../dictionaries/api';
import { QuerySelectFetchParams } from '../../../query-select';

export const useFormulaParameterDictionary = getDictionaryQuery<FormulaParameterDTO>({
    url: `${MS_AVAILABILITY_URL}/formula-calc-param/page`,
    queryKey: ['@root/dictionary/formula-parameter'],
    searchKey: 'name',
    additionalParams: { parameterizable: false },
    sort: {
        direction: SORT_DIRECTION.ASC,
        field: 'name',
    },
});

export const useCustomFormulaDictionary = getDictionaryQuery<CustomFormulaDTO>({
    url: `${MS_AVAILABILITY_URL}/formula-variable/page`,
    queryKey: ['@root/dictionary/custom-formula'],
    additionalParams: { parametrized: false },
    searchKey: 'name',
    sort: {
        direction: SORT_DIRECTION.ASC,
        field: 'name',
    },
});

export const useParametrizedDictionary = getDictionaryQuery<CustomFormulaDTO>({
    url: `${MS_AVAILABILITY_URL}/formula-variable/page`,
    queryKey: ['@root/dictionary/custom-formula-parametrized'],
    additionalParams: { parametrized: true },
    searchKey: 'name',
    sort: {
        direction: SORT_DIRECTION.ASC,
        field: 'name',
    },
});

export const useSettingFormulaCalcOptDictionary = getDictionaryQuery<FormulaVariableDTO>({
    url: `${MS_AVAILABILITY_URL}/setting-formula-calc-opt/resource-formula/page`,
    queryKey: ['@root/dictionary/setting-formula-calc-opt/resource-formula/page'],
    searchKey: 'name',
});

export const useSettingFormulaCalcB2BDictionaryById =
    (additionalParams?: Record<string, any>) => (params: QuerySelectFetchParams) => {
        return useInfiniteQuery({
            queryKey: [
                '@root/dictionary/setting-formula-calc-b2b/id/resource-formula/page',
                params.search,
            ],
            queryFn: async ({ pageParam }) => {
                const result = await api.post<
                    ResponseDTO<FormulaVariableDTO[]>,
                    AxiosResponse<ResponseDTO<FormulaVariableDTO[]>>,
                    ListRequestDTO
                >(`${MS_AVAILABILITY_URL}/setting-formula-calc-b2b/resource-formula/page`, {
                    pageInfo: {
                        page: pageParam || 0,
                        size: 10,
                        sort: [
                            {
                                field: 'id',
                                direction: SORT_DIRECTION.ASC,
                            },
                        ],
                    },
                    ...(additionalParams || {}),
                    name: params.search,
                });

                return result.data;
            },
            enabled: params.enabled,
            getNextPageParam: (lastPage) =>
                lastPage.page + 1 < lastPage.totalPages ? lastPage.page + 1 : undefined,
            staleTime: 1 * 60 * 1000,
        });
    };
