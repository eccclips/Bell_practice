import { useCallback, useMemo } from 'react';

import { SetterOrUpdater } from 'recoil';

import { TableFiltersState } from 'root-front/store';
import { randomUUID, useAction } from 'root-front/utils';

import { SavedFilter } from '../../table';
import {
    getUseDeleteFilterMutation,
    getUseImportUserSavedFilters,
    getUseSaveFilterMutation,
    getUseUserSavedFilters,
    useSavedFilters as useSavedFiltersHook,
} from '../api/saved-filters';

type UseSavedFiltersConfig = {
    tableName: string;
    allowSavedFilters: boolean;
    appliedFilter?: { name: string; uid: string };
    setFilterValues: SetterOrUpdater<TableFiltersState>;
};

export const useSavedFilters = (config: UseSavedFiltersConfig) => {
    const { tableName, allowSavedFilters, appliedFilter, setFilterValues } = config;

    const useSaveFilterMutation = useMemo(() => getUseSaveFilterMutation(tableName), [tableName]);
    const { submit: submitSave } = useAction({
        useMutation: useSaveFilterMutation,
        successMessage: 'Фильтр был успешно сохранен и применен',
    });

    const useDeleteFilterMutation = useMemo(
        () => getUseDeleteFilterMutation(tableName),
        [tableName]
    );
    const { submit: submitDelete } = useAction({
        useMutation: useDeleteFilterMutation,
        onSuccess: () => {
            return false;
        },
    });

    const useImportUserSavedFilters = useMemo(
        () => getUseImportUserSavedFilters(tableName),
        [tableName]
    );
    const { submit: submitImport } = useAction({
        useMutation: useImportUserSavedFilters,
        successMessage: 'Фильтры были успешно импортированы',
    });

    const useSavedFiltersQuery = useCallback(() => useSavedFiltersHook(tableName), [tableName]);
    const useUserSavedFiltersQuery = useMemo(() => getUseUserSavedFilters(tableName), [tableName]);

    const onApplyFilter = useCallback((filter: SavedFilter) => {
        setFilterValues({
            isDefault: false,
            filters: filter.values,
            appliedFilter: {
                name: filter.name,
                uid: filter.uid,
            },
        });
    }, []);

    const onSaveFilter = useCallback((filter: SavedFilter) => {
        const filterWithId = { ...filter, uid: randomUUID() };

        submitSave(({ mutate }) => {
            mutate({ filter: filterWithId });
        });
        setFilterValues({
            isDefault: false,
            filters: filterWithId.values,
            appliedFilter: {
                name: filterWithId.name,
                uid: filterWithId.uid,
            },
        });
    }, []);

    const onDeleteFilter = useCallback((filterUid: string) => {
        submitDelete(({ mutate }) => {
            mutate({ filterUid });
        });
    }, []);

    const onImportUserFilters = useCallback((filters: SavedFilter[]) => {
        submitImport(({ mutate }) => {
            mutate({ filters });
        });
    }, []);

    const savedFilters = useMemo(
        () => ({
            appliedFilter,
            useSavedFilters: useSavedFiltersQuery,
            useUserSavedFilters: useUserSavedFiltersQuery,
            onApplyFilter,
            onSaveFilter,
            onDeleteFilter,
            onImportUserFilters,
        }),
        [tableName, appliedFilter]
    );

    return allowSavedFilters ? savedFilters : null;
};
