import { CHIP_COLORS } from 'root-front/components';

export enum WAREHOUSE_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
}

export const WAREHOUSE_STATUS_MAP = {
    [WAREHOUSE_STATUS.ACTIVE]: {
        text: 'Активный',
        color: CHIP_COLORS.SUCCESS,
    },
    [WAREHOUSE_STATUS.DELETED]: {
        text: 'Удален',
        color: CHIP_COLORS.ERROR,
    },
};

export enum WAREHOUSE_ORDER_TYPE_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
}

export const WAREHOUSE_ORDER_TYPE_STATUS_MAP = {
    [WAREHOUSE_ORDER_TYPE_STATUS.ACTIVE]: {
        text: 'Активный',
        color: CHIP_COLORS.SUCCESS,
    },
    [WAREHOUSE_ORDER_TYPE_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
    [WAREHOUSE_ORDER_TYPE_STATUS.DELETED]: {
        text: 'Удален',
        color: CHIP_COLORS.ERROR,
    },
};

export enum WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO {
    NO = 'NO',
    LOGSTANDARD = 'LOGSTANDARD',
    BY_RESERVE = 'BY_RESERVE',
}

export const WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO_MAP = {
    [WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO.NO]: {
        text: 'Нет',
    },
    [WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO.LOGSTANDARD]: {
        text: 'По логстандарту',
    },
    [WAREHOUSE_ORDER_TYPE_AUTOMATIC_ZNO.BY_RESERVE]: {
        text: 'При резервировании',
    },
};

export enum ASSEMBLY_PLAN_REMAINDER_TYPE {
    REPAIR_KIT = 'REPAIR_KIT',
    COMPONENT_ITEM = 'COMPONENT_ITEM',
}

export const ASSEMBLY_PLAN_REMAINDER_TYPE_MAP = {
    [ASSEMBLY_PLAN_REMAINDER_TYPE.REPAIR_KIT]: {
        text: 'Ремкомплект',
    },
    [ASSEMBLY_PLAN_REMAINDER_TYPE.COMPONENT_ITEM]: {
        text: 'Комплектующее изделие',
    },
};

export enum ASSEMBLY_PLAN_REMAINDER_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DELETED = 'DELETED',
    DRAFT = 'DRAFT',
}

export const ASSEMBLY_PLAN_REMAINDER_STATUS_MAP = {
    [ASSEMBLY_PLAN_REMAINDER_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [ASSEMBLY_PLAN_REMAINDER_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
    [ASSEMBLY_PLAN_REMAINDER_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [ASSEMBLY_PLAN_REMAINDER_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
};

export enum GUARANTEED_RESERVE_TYPE {
    DEALER = 'DEALER',
    WHOLESALE_OPERATOR = 'WHOLESALE_OPERATOR',
}

export const GUARANTEED_RESERVE_TYPE_MAP = {
    [GUARANTEED_RESERVE_TYPE.DEALER]: {
        text: 'Дилер',
    },
    [GUARANTEED_RESERVE_TYPE.WHOLESALE_OPERATOR]: {
        text: 'Оптовый дилер',
    },
};

export enum GUARANTEED_RESERVE_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
    DRAFT = 'DRAFT',
    CLOSED = 'CLOSED',
}

export const GUARANTEED_RESERVE_STATUS_MAP = {
    [GUARANTEED_RESERVE_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [GUARANTEED_RESERVE_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
    [GUARANTEED_RESERVE_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [GUARANTEED_RESERVE_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
};

export enum GUARANTEED_STORAGE_CALC_STATUS {
    VALID = 'VALID',
    DELETED = 'DELETED',
    PROCESSING_ERROR = 'PROCESSING_ERROR',
    CLOSED = 'CLOSED',
}

export const GUARANTEED_STORAGE_CALC_STATUS_MAP = {
    [GUARANTEED_STORAGE_CALC_STATUS.VALID]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [GUARANTEED_STORAGE_CALC_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
    [GUARANTEED_STORAGE_CALC_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [GUARANTEED_STORAGE_CALC_STATUS.PROCESSING_ERROR]: {
        text: 'Ошибка обработки',
        color: CHIP_COLORS.NEUTRAL,
    },
};

export enum DELIVERY_ATTRIBUTE {
    ONE = 1,
    TWO = 2,
    THREE = 3,
    FOUR = 4,
}

export const DELIVERY_ATTRIBUTE_MAP = {
    [DELIVERY_ATTRIBUTE.ONE]: { text: 'Не поставляемая' },
    [DELIVERY_ATTRIBUTE.TWO]: { text: '?' },
    [DELIVERY_ATTRIBUTE.THREE]: { text: 'Поставляемая с ограничениями' },
    [DELIVERY_ATTRIBUTE.FOUR]: { text: 'Поставляемая без ограничений' },
};

export enum WARRANTY_SERVICE_STATISTICS_STATUS {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED',
    DRAFT = 'DRAFT',
    CLOSED = 'CLOSED',
}

export const WARRANTY_SERVICE_STATISTICS_STATUS_MAP = {
    [WARRANTY_SERVICE_STATISTICS_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [WARRANTY_SERVICE_STATISTICS_STATUS.DELETED]: {
        text: 'Удалён',
        color: CHIP_COLORS.ERROR,
    },
    [WARRANTY_SERVICE_STATISTICS_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.NEUTRAL,
    },
    [WARRANTY_SERVICE_STATISTICS_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
};

export enum NORMATIVE_STOCK_RESERVE_TYPE {
    DEALER = 'DEALER',
    WHOLESALE_OPERATOR = 'WHOLESALE_OPERATOR',
    WHOLESALE_OPERATOR_ADJUSTMENT = 'WHOLESALE_OPERATOR_ADJUSTMENT',
    SAFETY_STOCK = 'SAFETY_STOCK',
}

export const NORMATIVE_STOCK_RESERVE_TYPE_MAP = {
    [NORMATIVE_STOCK_RESERVE_TYPE.DEALER]: {
        text: 'Дилера',
    },
    [NORMATIVE_STOCK_RESERVE_TYPE.WHOLESALE_OPERATOR]: {
        text: 'Оптового оператора',
    },
    [NORMATIVE_STOCK_RESERVE_TYPE.WHOLESALE_OPERATOR_ADJUSTMENT]: {
        text: 'Оптового оператора (корректировка)',
    },
    [NORMATIVE_STOCK_RESERVE_TYPE.SAFETY_STOCK]: {
        text: 'Страховой запас',
    },
};

export enum WAREHOUSE_DOCUMENT_ITEM_STATUS {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
}

export const WAREHOUSE_DOCUMENT_ITEM_STATUS_MAP = {
    [WAREHOUSE_DOCUMENT_ITEM_STATUS.ACTIVE]: {
        text: 'Действует',
        color: CHIP_COLORS.SUCCESS,
    },
    [WAREHOUSE_DOCUMENT_ITEM_STATUS.CLOSED]: {
        text: 'Не действует',
        color: CHIP_COLORS.DRAFT,
    },
};

export enum WAREHOUSE_DOCUMENT_STATUS {
    ACTIVE = 'ACTIVE',
    DRAFT = 'DRAFT',
    DELETED = 'DELETED',
}

export const WAREHOUSE_DOCUMENT_STATUS_MAP = {
    [WAREHOUSE_DOCUMENT_STATUS.ACTIVE]: {
        text: 'Активный',
        color: CHIP_COLORS.SUCCESS,
    },
    [WAREHOUSE_DOCUMENT_STATUS.DRAFT]: {
        text: 'Черновик',
        color: CHIP_COLORS.DRAFT,
    },
    [WAREHOUSE_DOCUMENT_STATUS.DELETED]: {
        text: 'Удален',
        color: CHIP_COLORS.ERROR,
    },
};

export enum WAREHOUSE_DOCUMENT_TYPE {
    WAREHOUSE_ORDER = 'WAREHOUSE_ORDER',
    RESERVATION = 'RESERVATION',
    RESERVATION_CANCEL = 'RESERVATION_CANCEL',
    ZNO_REQUEST = 'ZNO_REQUEST',
    ZNO = 'ZNO',
    MOVEMENT = 'MOVEMENT',
    SALE = 'SALE',
    DISASSEMBLY = 'DISASSEMBLY',
    RECEIPT = 'RECEIPT',
}

export const WAREHOUSE_DOCUMENT_TYPE_MAP = {
    [WAREHOUSE_DOCUMENT_TYPE.WAREHOUSE_ORDER]: {
        text: 'Складской заказ',
    },
    [WAREHOUSE_DOCUMENT_TYPE.RESERVATION]: {
        text: 'Резервирование',
    },
    [WAREHOUSE_DOCUMENT_TYPE.RESERVATION_CANCEL]: {
        text: 'Отмена резервирования',
    },
    [WAREHOUSE_DOCUMENT_TYPE.ZNO_REQUEST]: {
        text: 'Заявка на ЗнО',
    },
    [WAREHOUSE_DOCUMENT_TYPE.ZNO]: {
        text: 'Задание на отгрузку',
    },
    [WAREHOUSE_DOCUMENT_TYPE.MOVEMENT]: {
        text: 'Перемещение',
    },
    [WAREHOUSE_DOCUMENT_TYPE.SALE]: {
        text: 'Реализация',
    },
    [WAREHOUSE_DOCUMENT_TYPE.DISASSEMBLY]: {
        text: 'Разукомплектация',
    },
    [WAREHOUSE_DOCUMENT_TYPE.RECEIPT]: {
        text: 'Поступление',
    },
};

export enum WAREHOUSE_DOCUMENT_ACTION_TYPE {
    SHIPMENT = 'SHIPMENT',
    MOVEMENT = 'MOVEMENT',
}

export const WAREHOUSE_DOCUMENT_ACTION_TYPE_MAP = {
    [WAREHOUSE_DOCUMENT_ACTION_TYPE.SHIPMENT]: {
        text: 'Отгрузка',
    },
    [WAREHOUSE_DOCUMENT_ACTION_TYPE.MOVEMENT]: {
        text: 'Перемещение',
    },
};

export enum PROCESSING_TYPE {
    DO_NOT_PROCESS = 'DO_NOT_PROCESS',
    ONCE = 'ONCE',
    MULTIPLE = 'MULTIPLE',
}

export const PROCESSING_TYPE_MAP = {
    [PROCESSING_TYPE.DO_NOT_PROCESS]: {
        text: 'Не обрабатывать',
    },
    [PROCESSING_TYPE.ONCE]: {
        text: 'Однократно',
    },
    [PROCESSING_TYPE.MULTIPLE]: {
        text: 'Многократно',
    },
};
