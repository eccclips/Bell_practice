import { UseMutationOptions, UseMutationResult } from '@tanstack/react-query';

import { TableColumn } from 'root-front/components';
import { ResponseDTO, ResponseErrorDTO } from 'root-front/interfaces';
import { SaveDataFromFileParams, UploadFromFileParams } from 'root-front/types';

export type UploadFromFileModalProps<Data, Error, UploadParams, SaveParams> = {
    opened: boolean;
    title?: string;
    successMessage?: string;
    useUploadFileMutation: (
        config: UseMutationOptions<ResponseDTO<Data[]>, Error, UploadFromFileParams<UploadParams>>
    ) => UseMutationResult<ResponseDTO<Data[]>, Error, UploadFromFileParams<UploadParams>>;
    useSaveDataMutation: (
        config: UseMutationOptions<
            ResponseDTO<Data[]>,
            Error,
            SaveDataFromFileParams<Data[], SaveParams>
        >
    ) => UseMutationResult<ResponseDTO<Data[]>, Error, SaveDataFromFileParams<Data[], SaveParams>>;
    uploadParams?: UploadParams;
    saveParams?: SaveParams;
    columns: TableColumn<Data>[];
    getSearchFilter: (
        search: string
    ) => (
        row: Data & { errors: ResponseErrorDTO[]; index: number },
        index: number,
        array: Array<Data & { errors: ResponseErrorDTO[]; index: number }>
    ) => boolean;
    onClose?: () => void;
    onSuccess?: (
        data: ResponseDTO<Data[]>,
        variables: SaveDataFromFileParams<Data[], SaveParams>,
        ctx: any
    ) => void;
};

export enum TABLE_MODE {
    ALL = 'ALL',
    ERRORS = 'ERRORS',
}

export type FormData = {
    viewMode: TABLE_MODE;
    search: string;
};
