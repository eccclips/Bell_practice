import React, { useMemo } from 'react';

import { Button, SvgIcon } from '@mui/material';
import {
    Control,
    FormState,
    UseFormGetValues,
    UseFormSetValue,
    UseFormTrigger,
} from 'react-hook-form';

import { Icons } from 'root-front/icons';

import { MenuButton, MenuButtonOption } from '../../../../menu-button';
import { TableProps } from '../../../types';
import {
    BooleanField,
    DateField,
    DateRangeField,
    QuerySelectField,
    QuerySelectWithModalField,
    SelectField,
    TextField,
} from '../fields';
import NumberRangeField from '../fields/number-range/NumberRangeField';
import { SaveFilter } from './save-filters';

import styles from '../TableFilters.module.scss';

type TableFiltersFormProps = Pick<
    TableProps<any>,
    'filters' | 'allowResetFiltersToDefault' | 'savedFilters'
> & {
    control: Control<Record<string, any>, any>;
    formState: FormState<Record<string, any>>;
    setValue: UseFormSetValue<Record<string, any>>;
    trigger: UseFormTrigger<Record<string, any>>;
    onResetFilters: () => void;
    onResetFiltersToDefault: () => void;
    getValues: UseFormGetValues<Record<string, any>>;
    setOpenedFilterModal: React.Dispatch<React.SetStateAction<boolean>>;
    hasFilters: boolean;
};

const TableFiltersForm = (props: TableFiltersFormProps) => {
    const {
        filters,
        control,
        formState,
        setValue,
        trigger,
        allowResetFiltersToDefault,
        savedFilters,
        onResetFilters,
        onResetFiltersToDefault,
        getValues,
        setOpenedFilterModal,
        hasFilters,
    } = props;

    const getFields = () => {
        return filters.map((filter) => {
            switch (filter.type) {
                case 'text':
                    return (
                        <TextField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            placeholder={filter.placeholder}
                            inputMode={filter.inputMode}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                case 'select':
                    return (
                        <SelectField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            options={filter.options}
                            placeholder={filter.placeholder}
                            multiple={filter.multiple}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                case 'date':
                    return (
                        <DateField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            datePickerView={filter.datePickerView}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                case 'date-range':
                    return (
                        <DateRangeField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            datePickerView={filter.datePickerView}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                case 'boolean':
                    return (
                        <BooleanField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            placeholder={filter.placeholder}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                case 'query-select':
                    return (
                        <QuerySelectField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            placeholder={filter.placeholder}
                            multiple={filter.multiple}
                            query={filter.query}
                            getOptionFromData={filter.getOptionFromData}
                            getOptionFromValue={filter.getOptionFromValue}
                            getOptionDisabled={filter.getOptionDisabled}
                            groupBy={filter.groupBy}
                            onChange={filter.onChange}
                            setValue={setValue}
                            saveSearchInputValue={filter.saveSearchInputValue}
                        />
                    );
                case 'query-select-with-modal':
                    return (
                        <QuerySelectWithModalField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            placeholder={filter.placeholder}
                            multiple={filter.multiple}
                            columns={filter.columns}
                            mode={filter.mode}
                            modalTableName={filter.modalTableName}
                            queryParams={filter.queryParams}
                            defaultParams={filter.defaultParams}
                            slots={filter.slots}
                            query={filter.query}
                            searchable={filter.searchable}
                            getOptionFromData={filter.getOptionFromData}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                case 'number-range':
                    return (
                        <NumberRangeField
                            key={filter.name}
                            control={control}
                            name={filter.name}
                            label={filter.label}
                            placeholder={filter.placeholder}
                            trigger={trigger}
                            inputMode={filter.inputMode}
                            onChange={filter.onChange}
                            setValue={setValue}
                        />
                    );
                default:
                    return null;
            }
        });
    };

    const menuOptions: MenuButtonOption[] = useMemo(
        () => [
            {
                text: 'Очистить',
                icon: <Icons.Close />,
                onClick: onResetFilters,
            },
            {
                text: 'Вернуть по умолчанию',
                icon: <Icons.Filters />,
                onClick: onResetFiltersToDefault,
            },
        ],
        []
    );

    return (
        <>
            <div className={styles.container__inner}>
                <div className={styles.container__form}>{getFields()}</div>
            </div>

            <div className={styles.container__footer}>
                {allowResetFiltersToDefault ? (
                    <MenuButton menuOptions={menuOptions}>Сбросить</MenuButton>
                ) : (
                    <Button
                        variant="outlined"
                        color="secondary"
                        onClick={onResetFilters}
                        startIcon={
                            <SvgIcon>
                                <Icons.Close />
                            </SvgIcon>
                        }
                    >
                        Сбросить
                    </Button>
                )}

                <div className={styles.container__buttons}>
                    {!!savedFilters && (
                        <SaveFilter
                            savedFilters={savedFilters}
                            getValues={getValues}
                            setOpenedFilterModal={setOpenedFilterModal}
                            hasFilters={hasFilters}
                        />
                    )}
                    <Button type="submit" variant="contained" disabled={formState.isSubmitting}>
                        Применить
                    </Button>
                </div>
            </div>
        </>
    );
};

export default React.memo(TableFiltersForm);
