import React, { memo, useEffect, useMemo } from 'react';

import { Tab, Tabs } from '@mui/material';
import { useSearchParams } from 'react-router-dom';

import { HorizontalTabsProps } from './types';

const HorizontalTabs = (props: HorizontalTabsProps) => {
    const { tabs, defaultTabKey, activeTab, onChange } = props;

    const [urlSearchParams, setUrlSearchParams] = useSearchParams(
        new URLSearchParams([['tab', defaultTabKey.toString()]])
    );

    const formattedDefaultTabKey = useMemo(
        () => defaultTabKey || tabs[0].key,
        [defaultTabKey, tabs]
    );

    const currentTab = useMemo(
        () => urlSearchParams.get('tab') || formattedDefaultTabKey,
        [urlSearchParams]
    );

    const handleChange = (_, value: string, isManual = false) => {
        const newSearchParams = new URLSearchParams();

        newSearchParams.set('tab', value);
        const historyRecord = urlSearchParams.get('history_record');
        if (historyRecord) {
            newSearchParams.set('history_record', historyRecord);
        }
        setUrlSearchParams(newSearchParams, { replace: true });

        if (!isManual) {
            onChange?.(value);
        }
    };

    const renderPage = useMemo(() => {
        const tabConfig = tabs.find(({ key }) => key === currentTab);

        if (tabConfig) {
            return tabConfig.renderPage;
        }

        return null;
    }, [currentTab, tabs]);

    useEffect(() => {
        if (activeTab) {
            handleChange(null, activeTab, true);
        }
    }, [activeTab]);

    useEffect(() => {
        if (!tabs.find(({ key }) => key === currentTab)) {
            handleChange(null, defaultTabKey);
        }
    }, [currentTab]);

    return (
        <>
            <Tabs
                value={currentTab}
                onChange={handleChange}
                variant="scrollable"
                scrollButtons="auto"
                aria-label="nav tabs"
            >
                {tabs.map(({ key, label, icon }) => (
                    <Tab icon={icon} iconPosition="start" key={key} label={label} value={key} />
                ))}
            </Tabs>
            {renderPage}
        </>
    );
};

export default memo(HorizontalTabs);
