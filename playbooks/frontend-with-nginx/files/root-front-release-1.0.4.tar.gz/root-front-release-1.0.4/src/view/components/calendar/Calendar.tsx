import React from 'react';

import { LoaderOverlay } from '../loader-overlay';
import { Month } from './month';
import { CalendarProps } from './types';

import styles from './Calendar.module.scss';

const Calendar = (props: CalendarProps) => {
    const { year, selectedDays, isLoading } = props;

    return (
        <div className={styles.container}>
            {Array.from({ length: 12 }).map((_, index) => (
                <div key={`${year}-${index}`} className={styles.month}>
                    <Month year={year} month={index + 1} selectedDays={selectedDays} />
                </div>
            ))}
            {isLoading && <LoaderOverlay />}
        </div>
    );
};

export default React.memo(Calendar);
