import React, { useMemo } from 'react';

import { SvgIcon } from '@mui/material';
import {
    PickerChangeHandlerContext,
    TimePicker as TimePickerCore,
    TimePickerProps as TimePickerCoreProps,
    TimeValidationError,
} from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { useController, UseControllerProps } from 'react-hook-form';

import { Icons } from 'root-front/icons';
import { typedMemo } from 'root-front/utils';

import { FormErrorHelper } from '../../form-error-helper';

export type TimePickerProps<T> = UseControllerProps<T> &
    TimePickerCoreProps<dayjs.Dayjs> & {
        id?: string;
    };

const TimePicker = <T,>(props: TimePickerProps<T>) => {
    const { field, fieldState } = useController(props);

    const handleChange = (
        value: dayjs.Dayjs,
        ctx: PickerChangeHandlerContext<TimeValidationError>
    ) => {
        if (ctx.validationError) {
            return;
        }

        field.onChange(value && value?.isValid() ? value.format('HH:mm:ss') : null);
        props.onChange?.(value, ctx);
    };

    const handleBlur = () => {
        field.onBlur();
    };

    const value = useMemo(
        () => (field.value ? dayjs(`${dayjs().format('YYYY-MM-DD')}T${field.value}`) : null),
        [field.value]
    );

    return (
        <TimePickerCore
            {...props}
            slotProps={{
                textField: {
                    helperText: fieldState.error ? (
                        <FormErrorHelper message={fieldState.error.message} />
                    ) : null,
                    onBlur: handleBlur,
                    error: !!fieldState.error,
                    id: props.id,
                    size: 'small',
                },
                actionBar: {
                    actions: ['clear'],
                },
            }}
            slots={{
                rightArrowIcon: () => (
                    <SvgIcon>
                        <Icons.ArrowRight />
                    </SvgIcon>
                ),
                leftArrowIcon: () => (
                    <SvgIcon>
                        <Icons.ArrowLeft />
                    </SvgIcon>
                ),
            }}
            onChange={handleChange}
            value={value}
            inputRef={field.ref}
        />
    );
};

export default typedMemo(TimePicker);
